create PROCEDURE EXH_REQ_ORDER(PI_ORDDATE     IN CHAR,      -- 委托日期
                                          PI_SYSORDID    IN NUMBER,    -- 系统内部委托号
                                          PI_LS         IN CHAR,       -- 多空标识
                                          PI_IS_CHECK    IN NUMBER,    -- 是否验资验券（0,1）
                                          PI_FREEZE_AMT  IN NUMBER,    -- 冻结金额（正数）
                                          PI_FREEZE_FEE  IN NUMBER,    -- 冻结费用（正数）
                                          PI_RESERVE_AMT IN NUMBER,    -- 最小保留资金数（正数）
                                          PO_ERRCODE     OUT NUMBER,   -- 返回错误号
                                          PO_ERRINFO     OUT VARCHAR2  -- 返回错误信息
                                         ) AS
/*
   1） 检查委托状态是否为“正报”，如果不是“正报”，则丢弃该笔委托，不处理，给出警告信息；
   2） 检查撤单标志是否为“待撤”，如果是“待撤”，则丢弃该笔委托，不处理，在撤单环节中处理，给出警告信息；
   3） 检查资金证券可用数是否满足，检查不通过，修改委托状态为“废单”，错误信息为资金或证券余额不足，给出错误信息；
   4） 冻结外部资金或股份余额，修改委托状态为已报
   5） 发送委托至外部接口，如果发送失败、通讯不通以及外部接口返回错误信息等，把委托置为废单，填写错误信息，解冻外部资金或股份余额
   6） 发送委托状态信息到MQ，通知应用服务
*/

/*
  错误号定义：（负号表示错误，正号表示警告，0表示正确），委托请求以“11”开头
     +11001 = 非正报委托，不处理
     +11002 = 待撤委托，不处理
     -11003 = 委托不存在
     -11011 = 资金余额不存在
     -11012 = 资金不足
     -11013 = 股份余额不存在
     -11014 = 股份不足
  */

  -- 冻结数
  V_FREEZE_CNT       NUMBER;
  V_FREEZE_AMT       NUMBER;
  V_FREEZE_FEE       NUMBER;

  -- 定义委托表光标集
  CURSOR CUR_ORDER(P_ORDDATE IN CHAR, P_SYSORDID IN NUMBER) IS
     SELECT *
     FROM TTRD_EXH_ORDER
     WHERE SYSORDID = P_SYSORDID
     FOR UPDATE;

  -- 定义委托表记录集
  REC_ORDER TTRD_EXH_ORDER%ROWTYPE;

BEGIN
   PO_ERRCODE := 0;
   PO_ERRINFO := '';

   -- 打开委托表光标集
   OPEN CUR_ORDER(PI_ORDDATE, PI_SYSORDID);
   FETCH CUR_ORDER INTO REC_ORDER;
   IF CUR_ORDER%NOTFOUND THEN
      PO_ERRCODE := -11003;
      PO_ERRINFO := '委托不存在，委托日期=' || PI_ORDDATE || '，委托号=' || TO_CHAR(PI_SYSORDID);
      GOTO LABLE_QUIT;
   END IF;

   -- 检查委托状态是否为“正报”，如果不是“正报=1”，则丢弃该笔委托，不处理，给出警告信息；
   IF REC_ORDER.ORDSTATUS <> 1 THEN
      PO_ERRCODE := +11001;
      PO_ERRINFO := '非正报委托，不处理，委托状态=' || TO_CHAR(REC_ORDER.ORDSTATUS);
      GOTO LABLE_QUIT;
   END IF;

   -- 检查撤单标志是否为“待撤”，如果是“待撤”，则丢弃该笔委托，不处理，在撤单环节中处理，给出警告信息；
   IF REC_ORDER.WTHFLAG = 1 THEN
      PO_ERRCODE := +11002;
      PO_ERRINFO := '待撤委托，不处理';
      GOTO LABLE_QUIT;
   END IF;

   -- 验资验券
   IF PI_IS_CHECK <> 0 THEN
      V_FREEZE_AMT := ABS(REC_ORDER.ORDFROZENAMT);
      V_FREEZE_FEE := ABS(REC_ORDER.ORDFROZENFEE);
      V_FREEZE_CNT := 0;
      IF REC_ORDER.OCFLAG = 'C' THEN
         V_FREEZE_CNT := ABS(REC_ORDER.ORDCOUNT);
      END IF;

      EXH_FREEZE_CASH_SECU(REC_ORDER.CASH_EXT_ACCID, REC_ORDER.SECU_EXT_ACCID, REC_ORDER.I_CODE, REC_ORDER.A_TYPE, REC_ORDER.M_TYPE,
                           PI_LS, V_FREEZE_CNT, V_FREEZE_AMT, V_FREEZE_FEE, PI_RESERVE_AMT, PO_ERRCODE, PO_ERRINFO);

      IF PO_ERRCODE < 0 THEN
         PO_ERRCODE := PO_ERRCODE - 1000;
      END IF;
   END IF;

   IF PO_ERRCODE < 0 THEN
      -- 验资验券失败，把委托置成废单
      UPDATE TTRD_EXH_ORDER SET ORDSTATUS = 2, ERRCODE = PO_ERRCODE, ERRINFO = PO_ERRINFO WHERE CURRENT OF CUR_ORDER;
   ELSE
      -- 更新委托状态（5=已报）、冻结金额、冻结费用
      UPDATE TTRD_EXH_ORDER SET ORDSTATUS = 5 WHERE CURRENT OF CUR_ORDER;
   END IF;

   -- 退出标签
   <<LABLE_QUIT>>

   -- 关闭游标
   IF CUR_ORDER%ISOPEN THEN
      CLOSE CUR_ORDER;
   END IF;

END;
/

