create view TEMP_UNIT_OBJ as
  select t1.beg_date,t1.unit_code,t1.asset_amount,t1.prft_1 as asset_prft1,t1.prft_2 as asset_prft2,t2.unit_nav_fv,t2.unit_nav_cp,t3.wmps_amount,t3.wmps_volume,t3.wmps_prft,
t2.unit_nav_fv/t3.wmps_volume as nav,t1.unit_name from
(select beg_date,unit_code,unit_name,sum(prft_1) as prft_1,sum(prft_2) as prft_2,sum(asset_amount) asset_amount
from temp_act_obj  where (a_type != 'SPT_NWM' or extra_dim = 'L') and a_type != 'SPT_NWMPORT' group by beg_date,unit_code,unit_name) t1,
(select beg_date,unit_code, (PRFT_TRD+PRFT_IR+PRFT_FV) as unit_nav_fv,(PRFT_TRD+PRFT_IR) as unit_nav_cp from temp_act_obj  where  a_type = 'SPT_NWMPORT' ) t2,
(select beg_date,unit_code, (PRFT_TRD+PRFT_IR+PRFT_FV) as wmps_amount,REAL_AMOUNT as wmps_volume,(PRFT_IR+PRFT_FV) as wmps_prft
 from temp_act_obj  where  a_type = 'SPT_NWM' and extra_dim = 'S' ) t3
where t1.unit_code = t2.unit_code and t1.unit_code = t3.unit_code and t1.beg_date = t2.beg_date and t1.beg_date = t3.beg_date



/

