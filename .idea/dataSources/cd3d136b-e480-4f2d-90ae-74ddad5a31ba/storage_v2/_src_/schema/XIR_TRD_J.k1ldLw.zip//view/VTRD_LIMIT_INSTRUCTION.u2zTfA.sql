create view VTRD_LIMIT_INSTRUCTION as
  select
           ins.inst_id,
           se.secu_inst_id,
           'Y' as IS_freeze,
           'N' as IS_occupy,
           'N' as IS_freeze2occupy,
           se.i_code,
           se.a_type,
           se.m_type,
           inst.p_class,
           se.biz_type,
           inst.party_id as party_id,
           se.CANCEL_FLAG,
           ord.remain_amount/ord.total_amount*se.amount as amount,
           null as ma1,
           null as ma2,
           null as ma3,
           null as ma4,
           null as ma5,
           se.CURRENCY,
           null as CANCEL_AMOUNT,
           1 as ORDSOURCE,
           CASE
               WHEN ins.STATE = '99999'
               THEN tr.orddate
               ELSE se.set_finish_date
           END as business_date,
           se.secu_acct_id,
           se.ext_secu_acct_id
     from ttrd_set_instruction_secu se
      inner join ttrd_set_instruction ins on se.inst_id = ins.inst_id
      inner join ttrd_instrument inst on se.i_code = inst.i_code and se.a_type = inst.a_type and se.m_type = inst.m_type
      inner join ttrd_otc_trade tr on ins.trade_id = tr.intordid and tr.ordstatus < 0
      inner join ttrd_otc_order ord on tr.ord_id = ord.ord_id
     where Ins.STATE = '99999' AND Se.cl_status = -20
     and (se.CANCEL_FLAG is null or se.CANCEL_FLAG = 0)

      -- 成交确认的交易单，如果在日终做初始化/刷新动作，不需要这段。
     union all
	 select
           ins.inst_id,
           se.secu_inst_id,
           'N' as IS_freeze,
           'Y' as IS_occupy,
           'N' as IS_freeze2occupy,
           se.i_code,
           se.a_type,
           se.m_type,
           inst.p_class,
           se.biz_type,
           inst.party_id as party_id,
           se.CANCEL_FLAG,
           se.amount as amount,
           null as ma1,
           null as ma2,
           null as ma3,
           null as ma4,
           null as ma5,
           se.CURRENCY,
           null as CANCEL_AMOUNT,
           1 as ORDSOURCE,
           null as business_date,
           se.secu_acct_id,
           se.ext_secu_acct_id
     from ttrd_set_instruction_secu se
      inner join ttrd_set_instruction ins on se.inst_id = ins.inst_id
      inner join ttrd_instrument inst on se.i_code = inst.i_code and se.a_type = inst.a_type and se.m_type = inst.m_type
      inner join ttrd_otc_trade tr on ins.trade_id = tr.intordid and tr.ordstatus >= 0
     where Ins.STATE = '99999' AND Se.cl_status = -20
     and (se.CANCEL_FLAG is null or se.CANCEL_FLAG = 0)

      -- 影响了审批单剩余额度，但未体现到额度模块（未成交确认）的交易单，如果在日终做初始化/刷新动作，不需要这段。
    union all
    select
           se.ord_inst_id,
           se.ord_secu_inst_id,
           'Y',
           'N',
           'N',
           se.i_code,
           se.a_type,
           se.m_type,
           se.p_class,
           se.biz_type,
           inst.party_id as party_id,
           se.CANCEL_FLAG,
           se.amount,
           null,
           null,
           null,
           null,
           null,
           inst.CURRENCY,
           null as CANCEL_AMOUNT,
           1 as ORDSOURCE,
           null as business_date,
           se.secu_acct_id,
           se.ext_secu_acct_id
     from vtrd_limit_secu_inst se
      inner join ttrd_set_instruction ins on se.inst_id = ins.inst_id
      inner join ttrd_instrument inst on se.i_code = inst.i_code and se.a_type = inst.a_type and se.m_type = inst.m_type
     where Ins.STATE = '99999' AND Se.cl_status = 0 and se.src_type = 2

    -- 当前实收付业务余额
    union all
      select
           so.obj_id*-1,
           so.obj_id*-1,
            'N',
            'Y',
            'N',
           so.I_CODE,
           so.A_TYPE,
           so.M_TYPE,
           IT.p_class,
           null as biz_type,
           it.party_id as party_id,
           '0',
          so.volume*nvl(tbsi.mk_par_value,it.par_value),
          null,
          null,
          null,
          null,
          null,
           IT.CURRENCY,
           null as CANCEL_AMOUNT,
           1 as ORDSOURCE,
           null as business_date,
           null as secu_acct_id,
           null as ext_secu_acct_id
     from (select i_code,a_type,m_type,max(obj_id) obj_id,sum(volume)volume
             from ttrd_blc_secu_obj
             where set_date='1900-01-01'
             group by i_code,a_type,m_type) so
      inner join ttrd_instrument IT  on so.i_code = IT.i_code and so.a_type = IT.a_type  and so.m_type = IT.m_type
      left join TBSI_IR tbsi  on so.i_code = tbsi.i_code and so.a_type = tbsi.a_type and so.m_type = tbsi.m_type
/

