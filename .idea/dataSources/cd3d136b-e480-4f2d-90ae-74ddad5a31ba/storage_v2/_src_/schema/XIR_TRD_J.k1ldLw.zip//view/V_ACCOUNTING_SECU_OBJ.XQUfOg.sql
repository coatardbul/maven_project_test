create view V_ACCOUNTING_SECU_OBJ as
  SELECT
    A.OBJ_ID,
    A.TSK_ID,
    A.BEG_DATE,
    A.END_DATE,
    A.EXT_SECU_ACCT_ID,
    A.SECU_ACCT_ID,
    A.TRADE_GRP_ID,
    A.I_CODE,
    A.A_TYPE,
    A.M_TYPE,
    A.TRADE_ID,
    A.REAL_VOLUME + COALESCE(B.REAL_AMOUNT, 0) AS REAL_VOLUME,
    A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) AS REAL_AMOUNT,
    A.REAL_CP + COALESCE(B.REAL_AMOUNT, 0)     AS REAL_CP,
    AI,
    AI_COST,
    CHG_FV,
    DUE_AMOUNT,
    CASE
        WHEN A.SET_DATE = '2100-12-31'
        THEN 0
        ELSE DUE_CP
    END AS DUE_CP,
    CASE
        WHEN A.SET_DATE = '2100-12-31'
        THEN 0
        ELSE DUE_AI
    END AS DUE_AI,
    DUE_FEE,
    AMRT_DATE,
    AMRT_YTM,
    AMRT_IR,
    IMPAIR,
    PRFT_FV,
    PRFT_TRD,
    PRFT_IR,
    PRFT_FEE,
    A.OPEN_TIME,
    C.I_NAME,
    C.P_CLASS,
    C.P_TYPE,
    C.MTR_DATE,
    D.P_TYPE_NAME,
    E.CASH_ACCID,
    E.ACCOUNTNAME,
    E.ACCNAME,
    AMRT_COST_CP + AMRT_COST_AI AS AMRT_COST,
    A.DUE_FEE + A.REAL_CP + (
        CASE
            WHEN A.SET_DATE = '2100-12-31'
            THEN 0
            ELSE A.DUE_CP
        END) + A.AMRT_IR + A.CHG_FV + A.AI + (
        CASE
            WHEN A.SET_DATE = '2100-12-31'
            THEN 0
            ELSE A.DUE_AI
        END) + COALESCE(B.REAL_AMOUNT, 0)                     AS ASSET_AMOUNT,
    A.DUE_AMOUNT + A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) AS ALL_AMOUNT,
    A.DUE_AI + A.AI                                           AS ALL_AI,
    A.DUE_CP + A.REAL_CP + COALESCE(B.REAL_AMOUNT, 0)         AS ALL_CP,
    A.AMRT_COST_CP,
    A.OPEN_YTM,
    A.SET_DATE
FROM
    TTRD_ACCOUNTING_SECU_OBJ A
LEFT JOIN
    TTRD_ACCOUNTING_CASH_OBJ B
ON
    A.TSK_ID = B.TSK_ID
AND A.BEG_DATE = B.BEG_DATE
AND A.EXT_SECU_ACCT_ID = B.EXT_CASH_ACCT_ID
AND A.SECU_ACCT_ID = B.CASH_ACCT_ID
LEFT JOIN
    TTRD_INSTRUMENT C
ON
    A.I_CODE = C.I_CODE
AND A.A_TYPE = C.A_TYPE
AND A.M_TYPE = C.M_TYPE
LEFT JOIN
    TTRD_P_CLASS D
ON
    C.P_TYPE = D.P_TYPE
AND C.A_TYPE = D.A_TYPE
AND C.P_CLASS = D.P_CLASS
INNER JOIN
    (
        SELECT
            A.ACCID,
            A.CASH_ACCID,
            A.ACCNAME                      AS ACCOUNTNAME,
            COALESCE(B.ACCNAME, A.ACCNAME) AS ACCNAME
        FROM
            TTRD_ACC_SECU A
        INNER JOIN
            TTRD_ACC_SECU B
        ON
            A.PS2 = B.ACCID
        UNION ALL
        SELECT
            ACCID,
            ACCID   AS CASH_ACCID,
            ACCNAME AS ACCOUNTNAME,
            '业务单元'  AS ACCNAME
        FROM
            TTRD_ACC_CASH) E
ON
    A.SECU_ACCT_ID = E.ACCID
LEFT JOIN
    TTRD_ACC_SECU_EXT F
ON
    A.EXT_SECU_ACCT_ID = F.ACCID
WHERE
    A.A_TYPE != 'SPT_NWMPORT'
AND (
        F.ACCTYPE IS NULL
    OR  F.ACCTYPE != '2') -- 排除 标准券账户
UNION ALL
SELECT
    A.OBJ_ID,
    A.TSK_ID,
    A.BEG_DATE,
    A.END_DATE,
    A.EXT_SECU_ACCT_ID,
    A.SECU_ACCT_ID,
    A.TRADE_GRP_ID,
    A.I_CODE,
    A.A_TYPE,
    A.M_TYPE,
    A.TRADE_ID,
    A.REAL_VOLUME + COALESCE(B.REAL_AMOUNT, 0) AS REAL_VOLUME,
    A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) AS REAL_AMOUNT,
    A.REAL_CP + COALESCE(B.REAL_AMOUNT, 0)     AS REAL_CP,
    AI,
    AI_COST,
    CHG_FV,
    DUE_AMOUNT,
    CASE
        WHEN A.SET_DATE = '2100-12-31'
        THEN 0
        ELSE DUE_CP
    END AS DUE_CP,
    CASE
        WHEN A.SET_DATE = '2100-12-31'
        THEN 0
        ELSE DUE_AI
    END AS DUE_AI,
    DUE_FEE,
    AMRT_DATE,
    AMRT_YTM,
    AMRT_IR,
    IMPAIR,
    PRFT_FV,
    PRFT_TRD,
    PRFT_IR,
    PRFT_FEE,
    A.OPEN_TIME,
    C.I_NAME,
    C.P_CLASS,
    C.P_TYPE,
    C.MTR_DATE,
    D.P_TYPE_NAME,
    E.CASH_ACCID,
    E.ACCOUNTNAME,
    E.ACCNAME,
    AMRT_COST_CP + AMRT_COST_AI AS AMRT_COST,
    A.DUE_FEE + A.REAL_CP + (
        CASE
            WHEN A.SET_DATE = '2100-12-31'
            THEN 0
            ELSE A.DUE_CP
        END) + A.AMRT_IR + A.CHG_FV + A.AI + (
        CASE
            WHEN A.SET_DATE = '2100-12-31'
            THEN 0
            ELSE A.DUE_AI
        END) + COALESCE(B.REAL_AMOUNT, 0)                     AS ASSET_AMOUNT,
    A.DUE_AMOUNT + A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) AS ALL_AMOUNT,
    A.DUE_AI + A.AI                                           AS ALL_AI,
    A.DUE_CP + A.REAL_CP + COALESCE(B.REAL_AMOUNT, 0)         AS ALL_CP,
    A.AMRT_COST_CP,
    A.OPEN_YTM,
    A.SET_DATE
FROM
    TTRD_ACCOUNTING_SECU_OBJ_HIS A
LEFT JOIN
    TTRD_ACCOUNTING_CASH_OBJ_HIS B
ON
    A.TSK_ID = B.TSK_ID
AND A.BEG_DATE = B.BEG_DATE
AND A.EXT_SECU_ACCT_ID = B.EXT_CASH_ACCT_ID
AND A.SECU_ACCT_ID = B.CASH_ACCT_ID
LEFT JOIN
    TTRD_INSTRUMENT C
ON
    A.I_CODE = C.I_CODE
AND A.A_TYPE = C.A_TYPE
AND A.M_TYPE = C.M_TYPE
LEFT JOIN
    TTRD_P_CLASS D
ON
    C.P_TYPE = D.P_TYPE
AND C.A_TYPE = D.A_TYPE
AND C.P_CLASS = D.P_CLASS
INNER JOIN
    (
        SELECT
            A.ACCID,
            A.CASH_ACCID,
            A.ACCNAME                      AS ACCOUNTNAME,
            COALESCE(B.ACCNAME, A.ACCNAME) AS ACCNAME
        FROM
            TTRD_ACC_SECU A
        INNER JOIN
            TTRD_ACC_SECU B
        ON
            A.PS2 = B.ACCID
        UNION ALL
        SELECT
            ACCID,
            ACCID   AS CASH_ACCID,
            ACCNAME AS ACCOUNTNAME,
            '业务单元'  AS ACCNAME
        FROM
            TTRD_ACC_CASH) E
ON
    A.SECU_ACCT_ID = E.ACCID
LEFT JOIN
    TTRD_ACC_SECU_EXT F
ON
    A.EXT_SECU_ACCT_ID = F.ACCID
WHERE
    A.A_TYPE != 'SPT_NWMPORT'
AND (
        F.ACCTYPE IS NULL
    OR  F.ACCTYPE != '2') -- 排除 标准券账户
UNION ALL
SELECT
    OBJ_ID,
    TSK_ID,
    G.BEG_DATE,
    G.END_DATE,
    EXT_SECU_ACCT_ID,
    SECU_ACCT_ID,
    '' AS TRADE_GRP_ID,
    G.I_CODE,
    G.A_TYPE,
    G.M_TYPE,
    ''     AS TRADE_ID,
    0      AS REAL_VOLUME,
    0      AS REAL_AMOUNT,
    0      AS REAL_CP,
    0      AS AI,
    0      AS AI_COST,
    0      AS CHG_FV,
    DUE_CP AS DUE_AMOUNT,
    DUE_CP,
    0  AS DUE_AI,
    0  AS DUE_FEE,
    '' AS AMRT_DATE,
    0  AS AMRT_YTM,
    0  AS AMRT_IR,
    0  AS IMPAIR,
    0  AS PRFT_FV,
    0  AS PRFT_TRD,
    0  AS PRFT_IR,
    0  AS PRFT_FEE,
    '' AS OPEN_TIME,
    G.I_NAME,
    G.P_CLASS,
    G.P_TYPE,
    G.MTR_DATE,
    P_TYPE_NAME,
    CASH_ACCT_ID AS CASH_ACCID,
    ACCOUNTNAME,
    ACCNAME,
    0            AS AMRT_COST,
    DUE_CP       AS ASSET_AMOUNT,
    DUE_CP       AS ALL_AMOUNT,
    0            AS ALL_AI,
    DUE_CP       AS ALL_CP,
    0            AS AMRT_COST_CP,
    0            AS OPEN_YTM,
    '1900-01-01' AS SET_DATE
FROM
    (
        SELECT
            A.OBJ_ID,
            A.TSK_ID,
            A.BEG_DATE,
            A.END_DATE,
            A.PAY_AMOUNT + A.RECEIVE_AMOUNT AS DUE_CP,
            A.INST_EXT_ACCT_ID              AS EXT_SECU_ACCT_ID,
            A.INST_INT_ACCT_ID              AS SECU_ACCT_ID,
            B.CASH_ACCID                    AS CASH_ACCT_ID,
            D.P_TYPE_NAME,
            C.MTR_DATE,
            C.I_NAME,
            C.P_TYPE,
            C.P_CLASS,
            A.INST_I_CODE AS I_CODE,
            A.INST_A_TYPE AS A_TYPE,
            A.INST_M_TYPE AS M_TYPE
        FROM
            TTRD_ACCOUNTING_DUE_OBJ A,
            TTRD_ACC_SECU B,
            TTRD_INSTRUMENT C,
            TTRD_P_CLASS D
        WHERE
            A.INST_INT_ACCT_ID = B.ACCID
        AND A.INST_I_CODE = C.I_CODE
        AND A.INST_A_TYPE = C.A_TYPE
        AND A.INST_M_TYPE = C.M_TYPE
        AND C.P_TYPE = D.P_TYPE
        AND C.A_TYPE = D.A_TYPE
        AND C.P_CLASS = D.P_CLASS
        UNION ALL
        SELECT
            A.OBJ_ID,
            A.TSK_ID,
            A.BEG_DATE,
            A.END_DATE,
            A.PAY_AMOUNT + A.RECEIVE_AMOUNT AS DUE_CP,
            A.INST_EXT_ACCT_ID              AS EXT_SECU_ACCT_ID,
            A.INST_INT_ACCT_ID              AS SECU_ACCT_ID,
            B.CASH_ACCID                    AS CASH_ACCT_ID,
            D.P_TYPE_NAME,
            C.MTR_DATE,
            C.I_NAME,
            C.P_TYPE,
            C.P_CLASS,
            A.INST_I_CODE AS I_CODE,
            A.INST_A_TYPE AS A_TYPE,
            A.INST_M_TYPE AS M_TYPE
        FROM
            TTRD_ACCOUNTING_DUE_OBJ_HIS A,
            TTRD_ACC_SECU B,
            TTRD_INSTRUMENT C,
            TTRD_P_CLASS D
        WHERE
            A.INST_INT_ACCT_ID = B.ACCID
        AND A.INST_I_CODE = C.I_CODE
        AND A.INST_A_TYPE = C.A_TYPE
        AND A.INST_M_TYPE = C.M_TYPE
        AND C.P_TYPE = D.P_TYPE
        AND C.A_TYPE = D.A_TYPE
        AND C.P_CLASS = D.P_CLASS
     ) G
INNER JOIN
    (
        SELECT
            H1.ACCID,
            H1.ACCNAME                       AS ACCOUNTNAME,
            COALESCE(H2.ACCNAME, H1.ACCNAME) AS ACCNAME
        FROM
            TTRD_ACC_SECU H1
        LEFT JOIN
            TTRD_ACC_SECU H2
        ON
            H1.PS2 = H2.ACCID
    ) H
ON
    G.SECU_ACCT_ID = H.ACCID
LEFT JOIN TTRD_CASHLB CB
ON G.I_CODE = CB.I_CODE
AND G.A_TYPE = CB.A_TYPE
AND G.M_TYPE = CB.M_TYPE
WHERE CB.P_CLASS NOT IN ('标准券质押式逆回购', '标准券质押式正回购')
UNION ALL
-- 当日余额表内未开仓利息数据
SELECT
    NULL AS OBJ_ID,
    A.TSK_ID,
    A.BEG_DATE,
    A.END_DATE,
    A.EXT_CASH_ACCT_ID AS EXT_SECU_ACCT_ID,
    A.CASH_ACCT_ID     AS SECU_ACCT_ID,
    NULL               AS TRADE_GRP_ID,
    C.I_CODE,
    C.A_TYPE,
    C.M_TYPE,
    NULL                                       AS TRADE_ID,
    0                                          AS REAL_VOLUME,
    A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) AS REAL_AMOUNT,
    A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) AS REAL_CP,
    0                                          AS AI,
    0                                          AS AI_COST,
    0                                          AS CHG_FV,
    0                                          AS DUE_AMOUNT,
    0                                          AS DUE_CP,
    0                                          AS DUE_AI,
    0                                          AS DUE_FEE,
    ''                                         AS AMRT_DATE,
    0                                          AS AMRT_YTM,
    0                                          AS AMRT_IR,
    0                                          AS IMPAIR,
    0                                          AS PRFT_FV,
    0                                          AS PRFT_TRD,
    0                                          AS PRFT_IR,
    0                                          AS PRFT_FEE,
    A.OPEN_TIME,
    C.I_NAME,
    C.P_CLASS,
    C.P_TYPE,
    C.MTR_DATE,
    D.P_TYPE_NAME,
    E.CASH_ACCID,
    E.ACCOUNTNAME,
    E.ACCNAME,
    0                                          AS AMRT_COST,
    A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) AS ASSET_AMOUNT,
    0                                          AS ALL_AMOUNT,
    0                                          AS ALL_AI,
    0                                          AS ALL_CP,
    0                                          AS AMRT_COST_CP,
    0                                          AS OPEN_YTM,
    '1900-01-01'                               AS SET_DATE
FROM
    TTRD_ACCOUNTING_CASH_OBJ A
LEFT JOIN
    TTRD_PENETRATE_CASH_OBJ B
ON
    A.OBJ_ID = B.OBJ_ID
INNER JOIN
    VDED_INFO VDED
ON
    A.EXT_CASH_ACCT_ID = VDED.EXT_CASH_ACCT_ID
LEFT JOIN
    TTRD_INSTRUMENT C
ON
    VDED.I_CODE = C.I_CODE
AND VDED.A_TYPE = C.A_TYPE
AND VDED.M_TYPE = C.M_TYPE
LEFT JOIN
    TTRD_P_CLASS D
ON
    C.P_TYPE = D.P_TYPE
AND C.A_TYPE = D.A_TYPE
AND C.P_CLASS = D.P_CLASS
INNER JOIN
    (
        SELECT
            ACCID,
            ACCID   AS CASH_ACCID,
            ACCNAME AS ACCOUNTNAME,
            '业务单元'  AS ACCNAME
        FROM
            TTRD_ACC_CASH ) E
ON
    A.CASH_ACCT_ID = E.ACCID
WHERE
    NOT EXISTS
    (
        SELECT
            1
        FROM
            TTRD_ACCOUNTING_SECU_OBJ
        WHERE
            A.CASH_ACCT_ID = SECU_ACCT_ID
        AND A.EXT_CASH_ACCT_ID = EXT_SECU_ACCT_ID )
/

