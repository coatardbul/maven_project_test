create PROCEDURE EXH_ADJUST_SECU(PI_ACCID      IN VARCHAR2,
                                            PI_I_CODE     IN VARCHAR2,
                                            PI_A_TYPE     IN VARCHAR2,
                                            PI_M_TYPE     IN VARCHAR2,
                                            PI_LS         IN CHAR,
                                            PI_BIZTYPE    IN VARCHAR2,
                                            PI_OCFLAG     IN VARCHAR2,
                                            PI_OCCUR_SECU IN NUMBER,
                                            PO_ERRCODE    OUT NUMBER,
                                            PO_ERRINFO    OUT VARCHAR2) AS
  -- 股份总余额、可卖数、买入冻结数变化值
  V_OCCUR_AMOUNT        NUMBER(38);
  V_OCCUR_AVAAMOUNT     NUMBER(38);
  V_OCCUR_BUY_FREAMOUNT NUMBER(38);

BEGIN
  PO_ERRCODE := 0;
  PO_ERRINFO := '';

  -- 根据业务类型确定调整方式
  IF PI_BIZTYPE = '???' THEN
    PO_ERRCODE := -303;
    PO_ERRINFO := '业务类型不支持：' || PI_BIZTYPE;
    RETURN;
  ELSE
    -- 确定股份总余额数、可卖余额数、买入冻结数发生额
    V_OCCUR_AMOUNT := PI_OCCUR_SECU;
    IF PI_OCFLAG = 'O' THEN
      -- 股指期货、债券、国债期货（T+0）
      IF PI_A_TYPE = 'FUT_IDX_S' OR PI_A_TYPE = 'SPT_BD' OR PI_A_TYPE = 'FUT_BD' THEN
        V_OCCUR_AVAAMOUNT := PI_OCCUR_SECU;
        V_OCCUR_BUY_FREAMOUNT := 0;
      -- 沪深A股等其他（T+1）
      ELSE
        V_OCCUR_AVAAMOUNT := 0;
        V_OCCUR_BUY_FREAMOUNT := PI_OCCUR_SECU;
      END IF;
    ELSE
      V_OCCUR_AVAAMOUNT := PI_OCCUR_SECU;
      V_OCCUR_BUY_FREAMOUNT := 0;
    END IF;
    -- 调整股份余额
    UPDATE TTRD_EXH_ACC_BALANCE_SECU_EXT
       SET RT_AMOUNT          = RT_AMOUNT + V_OCCUR_AMOUNT,
           RT_AVAAMOUNT       = RT_AVAAMOUNT + V_OCCUR_AVAAMOUNT,
           RT_BUY_FREAMOUNT   = RT_BUY_FREAMOUNT + V_OCCUR_BUY_FREAMOUNT,
           RT_UPDATETIME      = CURRENT_DATE
     WHERE ACCID = PI_ACCID
       AND I_CODE = PI_I_CODE
       AND A_TYPE = PI_A_TYPE
       AND M_TYPE = PI_M_TYPE
       AND LS = PI_LS;
  END IF;

  -- 不存在，则新插入一条
  IF SQL%ROWCOUNT < 1 THEN
      EXH_INSERT_SECU(TO_CHAR(CURRENT_DATE, 'YYYY-MM-DD'),PI_ACCID,PI_I_CODE,PI_A_TYPE,PI_M_TYPE,PI_LS,0,0,0,V_OCCUR_AMOUNT,V_OCCUR_AVAAMOUNT,0,V_OCCUR_BUY_FREAMOUNT);
  END IF;

END;
/

