create view V_TP_LBS_FEE as
  SELECT NULL AS I_CODE,
    NULL    AS A_TYPE,
    NULL    AS M_TYPE,
    NULL    AS FEE_I_CODE,
    NULL    AS FEE_A_TYPE,
    NULL    AS FEE_M_TYPE
FROM dual




/

