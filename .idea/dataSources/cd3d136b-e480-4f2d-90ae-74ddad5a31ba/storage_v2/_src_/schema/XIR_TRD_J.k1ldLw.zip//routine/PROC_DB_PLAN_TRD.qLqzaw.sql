create PROCEDURE             "PROC_DB_PLAN_TRD" AS
  CURSOR IDX_CUR IS
    SELECT TABLE_OWNER, INDEX_NAME
    FROM   USER_INDEXES
    WHERE  TABLE_OWNER = 'XIR_TRD_J';
  V_SQL        VARCHAR2(100);
  V_OWNER      VARCHAR2(20);
  V_INDEX_NAME VARCHAR2(50);
BEGIN
  /*对XIR_TRD_J用户做统计*/
  DBMS_STATS.GATHER_SCHEMA_STATS(OWNNAME => 'XIR_TRD_J',
                                 OPTIONS => 'GATHER AUTO',
                                 ESTIMATE_PERCENT => DBMS_STATS.AUTO_SAMPLE_SIZE,
                                 METHOD_OPT => 'for all columns size repeat',
                                 DEGREE => 15);
  /*重建索引*/
  OPEN IDX_CUR;
  LOOP
    BEGIN
      FETCH IDX_CUR
        INTO V_OWNER, V_INDEX_NAME;
      V_SQL := 'alter index ' || V_OWNER || '.' || V_INDEX_NAME ||
               ' REBUILD TABLESPACE XIR_TRD_IDX';
      EXECUTE IMMEDIATE V_SQL;
      --DBMS_OUTPUT.PUT_LINE(V_SQL);
      EXCEPTION
       WHEN OTHERS THEN
         DBMS_OUTPUT.PUT_LINE(V_SQL);
      END;
      EXIT WHEN IDX_CUR%NOTFOUND;
  END LOOP;
  CLOSE IDX_CUR;
END PROC_DB_PLAN_TRD;




/

