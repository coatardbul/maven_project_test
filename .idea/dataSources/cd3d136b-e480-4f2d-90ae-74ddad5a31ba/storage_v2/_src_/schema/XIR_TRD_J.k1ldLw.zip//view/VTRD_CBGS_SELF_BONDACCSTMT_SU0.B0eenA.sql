create view VTRD_CBGS_SELF_BONDACCSTMT_SU0 as
  SELECT B.TXFLOWID AS TXFLOWID,
    A.ACCID, --账户编号
    A.ACCNAME, --账户名称
    A.DTLD_DATE, --托管总对账单日期
    A.I_CODE, --债券代码、
    A.I_NAME, --债券简称、
    SUM(
        CASE A.LDG_TYPE
            WHEN 'AL02'
            THEN A.LDG_BALANCE
            ELSE 0
        END) AS AL02_LDG_BALANCE, ---可用
    SUM(
        CASE A.LDG_TYPE
            WHEN 'AL03'
            THEN A.LDG_BALANCE
            ELSE 0
        END) AS AL03_LDG_BALANCE, ---待付
    SUM(
        CASE A.LDG_TYPE
            WHEN 'AL04'
            THEN A.LDG_BALANCE
            ELSE 0
        END) AS AL04_LDG_BALANCE, ---质押式待回购
    SUM(
        CASE A.LDG_TYPE
            WHEN 'AL05'
            THEN A.LDG_BALANCE
            ELSE 0
        END) AS AL05_LDG_BALANCE, ---冻结
    SUM(
        CASE A.LDG_TYPE
            WHEN 'AL06'
            THEN A.LDG_BALANCE
            ELSE 0
        END) AS AL06_LDG_BALANCE, --质押
    A.ACCSTAT_TYPE, --账户对账单类型
    A.START_DATE AS START_DATE, --开始日期
    A.END_DATE   AS END_DATE, --结束日期
    B.UPDATETIME AS UPDATETIME --更新时间
FROM TTRD_CBGS_BONDACCSTMT_SUM A, ---总对账单
    TTRD_CBGS_BONDACCSTMT_QUERY B ---债券账户对账单查询
WHERE A.CID = B.CID
AND A.ACCSTAT_TYPE = 'AS00'
GROUP BY TXFLOWID,
    A.ACCID,
    A.ACCNAME,
    A.DTLD_DATE,
    A.I_CODE,
    A.I_NAME,
    A.ACCSTAT_TYPE,
    A.START_DATE,
    A.END_DATE,
    B.UPDATETIME




/

