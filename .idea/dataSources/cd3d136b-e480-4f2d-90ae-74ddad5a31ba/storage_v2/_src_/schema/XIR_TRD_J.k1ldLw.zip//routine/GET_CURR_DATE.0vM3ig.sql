create function "GET_CURR_DATE"
RETURN VARCHAR2
IS
  return_date varchar2(10);
begin
  select CURR_DATE into return_date from
      TTRD_TSK_CURRDATE;
  return return_date;
end;
/

