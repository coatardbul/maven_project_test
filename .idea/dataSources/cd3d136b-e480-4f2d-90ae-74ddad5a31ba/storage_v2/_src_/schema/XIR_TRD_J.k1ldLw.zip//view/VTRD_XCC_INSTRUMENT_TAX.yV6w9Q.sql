create view VTRD_XCC_INSTRUMENT_TAX as
  SELECT INS.I_CODE, INS.A_TYPE, INS.M_TYPE
  FROM TTRD_INSTRUMENT INS
 INNER JOIN TBND T
    ON INS.I_CODE = T.A_TYPE
   AND INS.A_TYPE = T.A_TYPE
   AND INS.M_TYPE = T.M_TYPE
 INNER JOIN TCOMPANY C
    ON T.B_ISSUER_CODE = C.COMP_CODE
 WHERE T.B_P_CLASS IN ('凭证式国债',
                       '记账式国债',
                       '储蓄国债',
                       '地方政府债',
                       '政策性银行债',
                       '央行票据',
                       '商业银行债',
                       '二级资本工具',
                       '保险公司金融债',
                       '证券公司债',
                       '证券公司次级债',
                       '证券公司短期融资券',
                       '非银行金融机构债')
   AND T.COUNTRY = 'CN'
UNION ALL --使用P_CLASS过滤资产,主要适用中行项目点
SELECT INS.I_CODE, INS.A_TYPE, INS.M_TYPE
  FROM TTRD_INSTRUMENT INS
 INNER JOIN TBND T
    ON INS.I_CODE = T.A_TYPE
   AND INS.A_TYPE = T.A_TYPE
   AND INS.M_TYPE = T.M_TYPE
 INNER JOIN TCOMPANY C
    ON T.B_ISSUER_CODE = C.COMP_CODE
 WHERE T.P_CLASS IN ('国债（境外）',
                     '政策性金融债（境外）',
                     '金融机构债券（境外）',
                     '地方政府债（境外）',
                     '点心债')
UNION ALL
SELECT INS.I_CODE, INS.A_TYPE, INS.M_TYPE
  FROM TTRD_INSTRUMENT INS
 INNER JOIN TTRD_INSTITUTION I
    ON INS.PARTY_ID = I.I_ID
 WHERE INS.P_CLASS = '债券借出'
   AND I.IS_GROUP = 1




/

