create view VTRD_CFETS_B_TRADE_MEMBER as
  SELECT A.MEMBER_ID, -- 交易成员ID
    A.ORGCODE, -- 机构代码
    A.CH_NAME, -- 中文全称
    A.CH_SHORT_NAME -- 中文简称
FROM TTRD_CFETS_B_TRADE_MEMBER A




/

