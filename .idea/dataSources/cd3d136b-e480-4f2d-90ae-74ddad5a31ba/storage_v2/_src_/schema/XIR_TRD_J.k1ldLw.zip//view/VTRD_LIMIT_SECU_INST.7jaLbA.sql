create view VTRD_LIMIT_SECU_INST as
  select
    s.secu_inst_id,
    s.inst_id,
    case when t.ordstatus<0 then s.secu_inst_id else s2.secu_inst_id end,
    case when t.ordstatus<0 then s.inst_id else s2.inst_id end,
    i.trade_id,
    t.ord_id,
    i.inst_type,
    s.i_code,
    s.a_type,
    s.m_type,
    s.p_class,
    s.biz_type,
    s.secu_acct_id,
    s.ext_secu_acct_id,
    case
    when t.ordstatus < 0 then 0
    when t.ord_id is null then 1
    else 2
    end as src_type,
    s.amount,
    s.cl_status,
    s.opr_state,
    case when t.ordstatus<0 then s.cl_status else s2.cl_status end as ord_cl_status,
    case when t.ordstatus<0 then s.opr_state else s2.opr_state end as ord_opr_state,
    s.blc_state,
    s.acctg_state,
    s.cancel_flag
    from ttrd_set_instruction_secu s
    inner join ttrd_set_instruction i  on s.inst_id = i.inst_id and i.state='99999'
    left join ttrd_otc_trade t
    on t.intordid = i.trade_id
    left join ttrd_set_instruction_secu s2
    on s.ord_limit_secu_inst_id = s2.secu_inst_id

    union all

    select
    s.cash_inst_id,
    s.inst_id,
    case when t.ordstatus<0 then s.cash_inst_id else s2.cash_inst_id end,
    case when t.ordstatus<0 then s.inst_id else s2.inst_id end,
    i.trade_id,
    t.ord_id,
    i.inst_type,
    ded.I_CODE,
    ded.A_TYPE,
    ded.M_TYPE,
    ded.p_class,
    s.biz_type,
    s.cash_acct_id,
    s.ext_cash_acct_id,
    case
    when t.ordstatus < 0 then 0
    when t.ord_id is null then 1
    else 2
    end as src_type,
    s.amount,
    s.cl_status,
    s.opr_state,
    case when t.ordstatus<0 then s.cl_status else s2.cl_status end as ord_cl_status,
    case when t.ordstatus<0 then s.opr_state else s2.opr_state end as ord_opr_state,
    s.blc_state,
    s.acctg_state,
    s.cancel_flag
    from ttrd_set_instruction_cash s
    inner join ttrd_set_instruction i
    on s.inst_id = i.inst_id and i.state='99999'
    left join vded_info ded
    on ded.EXT_CASH_ACCT_ID = s.ext_cash_acct_id
    left join ttrd_otc_trade t
    on t.intordid = i.trade_id
    left join ttrd_set_instruction_cash s2
    on s.ord_limit_cash_inst_id = s2.cash_inst_id
/

