create view VINST_SECTOR as
  SELECT NULL AS I_CODE,
       NULL AS A_TYPE,
       NULL AS M_TYPE,
       NULL AS SECTOR,
       NULL AS BEG_DATE,
       NULL AS END_DATE
  FROM DUAL WHERE 1<>1
/

comment on table VINST_SECTOR
is '金融工具个性化分类视图'
/

