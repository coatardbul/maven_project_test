create view VTRD_LIMIT_ACCTG_BLC_INFO as
  SELECT A.SRC_TYPE,
         A.SRC_ID,
         A.OCCUPY_OBJ_TYPE,
         A.ORD_ID,
         A.OPR_STATE,
         A.ORDSTATUS,
         A.INTORDID,
         A.TRADE_GRP_ID,
         B.I_NAME,
         C.CLS_NAME,
         A.I_CODE,
         A.A_TYPE,
         A.M_TYPE,
         A.EXT_SECU_ACCT_ID,
         A.SECU_ACCT_ID,
         --       A.EXT_CASH_ACCT_ID,
         A.CASH_ACCT_ID,
         A.ORD_TOTAL_AMOUNT,
         A.ORD_CANCEL_AMOUNT,
         A.ORD_REMAIN_AMOUNT,
         A.REAL_VOLUME,
         A.REAL_AMOUNT,
         A.absREAL_AMOUNT,
         A.NET_CP,
         A.REAL_CP_NOAMRT,
         A.COST_METHOD_AMOUNT,
         A.MARKET_METHOD_AMOUNT,
         A.FULL_CP,
         A.Inst_Id,
         B.COUPON_TYPE,
         C.CLS_CODE,
         CASE
     WHEN A.EXTRA_DIM = 'S' AND B.P_TYPE IN ('0900','0105','0301') THEN 0
     ELSE 1
     END AS DK_FLAG,
         B.P_TYPE,
         B.P_CLASS,
         TO_CHAR(B.Issuer_Id) AS PARTY_ID,
         TO_DATE(B.Mtr_Date, 'yyyy-mm-dd') -
         TO_DATE(E.CURR_DATE, 'yyyy-mm-dd') AS REMAIN_TERM_DAY,
         TO_DATE(B.Mtr_Date, 'yyyy-mm-dd') -
         TO_DATE(B.START_DATE, 'yyyy-mm-dd') AS TERM_DAY,
         B.COUPON AS OPEN_YTM,
         B.CURRENCY,
         NVL(A.REAL_AMOUNT, 0) AS PARTYCREDIT,
         NVL(A.REAL_AMOUNT, 0) * NVL(SE.DP_MID, 1) AS CNY_PARTYCREDIT,
         A.MOCK_TYPE AS MOCK_TYPE
    FROM VTRD_LIMIT_ACCTG_BLC_INFO_CORE A
   INNER JOIN TTRD_INSTRUMENT B
      ON A.I_CODE = B.I_CODE
     AND A.A_TYPE = B.A_TYPE
     AND A.M_TYPE = B.M_TYPE
   INNER JOIN TTRD_LIMIT_CLS_CODE C
      ON INSTR(C.P_TYPE, B.P_TYPE) > 0
    LEFT JOIN VTRD_LIMIT_CURR2CNY SE
      ON B.CURRENCY = SE.CURRENCY
    LEFT JOIN TTRD_CURRDATE E
      ON 1 = 1
   WHERE A.I_CODE NOT LIKE '%@%'
/

