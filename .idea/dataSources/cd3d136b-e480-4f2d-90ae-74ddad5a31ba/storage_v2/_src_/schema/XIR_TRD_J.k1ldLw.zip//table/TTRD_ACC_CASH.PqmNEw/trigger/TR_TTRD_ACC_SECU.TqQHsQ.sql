create trigger TR_TTRD_ACC_SECU
  after insert or update or delete
  on TTRD_ACC_CASH
  for each row
  BEGIN IF inserting THEN
INSERT
INTO ttrd_acc_secu
    (
        ACCID,
        ACCNAME,
        CASH_ACCID,
        OWNER,
        TRDKIND,
        TRDGRPID,
        PS1,
        PS2,
        PS3,
        PS4,
        STATUS,
        TRDGRP_AUTO,
        IS_LOCK,
        LOCKSTATUS,
        ACCFISCASUBJECT,
        ps5,
        ps6,
        ps7,
        ps8,
        INVEST_TYPE,
        ACTING_TYPE,
        I_ID
    )
    VALUES
    (
        :new.ACCID,
        :new.ACCNAME,
        :new.ACCID,
        '-2',
        '',
        '',
        0,
        '0',
        (SELECT t.CASH_EXT_ACCID
           FROM TTRD_ACC_CASH_EXT_MAP t
          WHERE t.CASH_ACCID = :new.ACCID),
        '',
        '0',
        '0',
        '0',
        '0',
        '',
        '',
        '',
        '',
        '',
        '1',
        '9',
        '130'
    );

elsif updating THEN
 UPDATE ttrd_acc_secu
    SET accname=:new.ACCNAME,
        cash_accid=:new.ACCID,
        STATUS=:new.STATUS,
        INVEST_TYPE=:new.INVEST_TYPE,
        I_ID=:new.I_ID
  WHERE ACCID=:old.ACCID;

elsif deleting THEN
 DELETE
   FROM ttrd_acc_secu
  WHERE ACCID=:old.ACCID;

END IF;
END;















/

