create function get_seq_next (seq_name in varchar2) return number
is
  seq_val number ;
begin
  execute immediate 'select ' || seq_name || '.nextval from dual' into seq_val ;
  return seq_val ;
end get_seq_next;
/

