create view V_TP_STDBD_TRANS_RATE as
  SELECT A.BASE_DATE AS BEG_DATE,
       NVL(LAG(A.BASE_DATE) OVER(PARTITION BY A.I_CODE,
                A.A_TYPE,
                A.M_TYPE ORDER BY A.BASE_DATE DESC),
           '2050-12-31') AS END_DATE,
       A.I_CODE,
       A.A_TYPE,
       A.M_TYPE,
       CASE
         WHEN A.M_TYPE = 'XSHG' THEN
          '888880'
         ELSE
          '131990'
       END AS STD_I_CODE,
       'STD_BD' AS STD_A_TYPE,
       A.M_TYPE AS STD_M_TYPE,
       A.DISCOUNT AS TRANS_RATE
  FROM (SELECT I_CODE, A_TYPE, M_TYPE, BASE_DATE, DISCOUNT
          FROM TBND_DISCOUNT
         WHERE BASE_DATE >=
               (SELECT MIN(BEG_DATE) FROM TTRD_ACCOUNTING_SECU_OBJ_HIS)) A
 WHERE EXISTS (SELECT 1
          FROM (SELECT I_CODE, A_TYPE, M_TYPE
                  FROM TTRD_ACCOUNTING_SECU_OBJ A
                 WHERE EXISTS (SELECT 1
                          FROM TTRD_INSTRUMENT
                         WHERE A_TYPE IN
                               ('SPT_BD', 'SPT_ABS', 'SPT_CD')
                           AND M_TYPE IN ('XSHE', 'XSHG')
                           AND A.I_CODE = I_CODE
                           AND A.A_TYPE = A_TYPE
                           AND A.M_TYPE = M_TYPE)
                 GROUP BY I_CODE, A_TYPE, M_TYPE)
         WHERE A.I_CODE = I_CODE
           AND A.A_TYPE = A_TYPE
           AND A.M_TYPE = M_TYPE)
/

