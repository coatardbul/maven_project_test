create PROCEDURE EXH_TTRD_ORDER_PRE_WITHDRAW(P_ORDIDS IN VARCHAR2,                     -- 系统委托号字符串列表（逗号分割）
                                                          PO_OK_ORDIDS OUT VARCHAR2,                -- 确认的需要撤单操作的系统委托号列表（逗号分割）
                                                          PO_OK_CHANNEL_NOS OUT VARCHAR2,           -- 确认的需要撤单的委托通道号列表（逗号分割）
                                                          PO_INNER_WITHDRAW_ORDIDS OUT VARCHAR2,  -- 内部撤单的系统委托号列表逗号分割）
                                                          PO_INNER_WITHDRAW_CHANNEL_NOS OUT VARCHAR2   -- 内部撤单的委托通道号列表（逗号分割）
                                                     ) AS
    /*
     1）  开启一个事物，锁住这些委托，检查每笔委托的撤单标志，如果撤单标志为“待撤”或“已撤”，说明已经有撤单操作，废弃该笔撤单操作；
     2）  检查每笔委托状态，如果委托状态为内部撤单、外部撤单、全部成交、部分撤单以及废单等最终状态时，废弃该笔撤单操作；如果委托状态为待报，则进行内部撤单，不需要通过MQ发送到交易服务端处理
     3）	如果委托状态为待报，处理流程如下:
        a)	把委托状态修改为“内部撤单”和撤单标记修改为“已撤”；
        b)	把信息返回给调用者，由调用者插入委托操作记录，操作状态为成功；(可以和第5步一起插入）
        c)	该笔撤单操作不需要通过MQ发送到交易服务端处理；
     4）	修改委托的撤单标记，当撤单标记为“无”时，则修改为“待撤”，当撤单标记为“待撤”或“已撤”时，则不处理，因为可能存在系统外撤单情况；
     5）	插入委托操作记录，操作状态为正报；
     6）	提交事物，释放委托锁；
     7）	把成功的委托操作记录，发送到MQ，如果发送失败，则修改撤单操作状态为“错误”并修改委托的撤单标记，当撤单标记为“待撤”时，修改撤单标记为“无”；

     注：第1到4步要在一个存储过程里实现，减少数据库的操作次数

    */

    TYPE T_CURSOR IS REF CURSOR;
    V_CURSOR T_CURSOR;

    V_SYSORDID NUMBER;
    V_ORDSTATUS INTEGER;
    V_WTHFLAG INTEGER;
    V_CHANNEL_NO VARCHAR2(20);

    SQL_TEXT VARCHAR2(6000);

    OK_NUM INTEGER;
    INNER_WITHDRAWED_NUM INTEGER;

BEGIN
    PO_OK_ORDIDS := '';
    PO_OK_CHANNEL_NOS := '';
    PO_INNER_WITHDRAW_ORDIDS := '';
    PO_INNER_WITHDRAW_CHANNEL_NOS := '';
    OK_NUM := 0;
    INNER_WITHDRAWED_NUM := 0;

    SQL_TEXT := 'SELECT SYSORDID, ORDSTATUS, WTHFLAG, CHANNEL_NO FROM TTRD_EXH_ORDER WHERE SYSORDID IN (' || P_ORDIDS || ') FOR UPDATE';
    OPEN V_CURSOR FOR SQL_TEXT;

    LOOP
       <<LABEL_NEXT_ROW>>

       FETCH V_CURSOR INTO V_SYSORDID, V_ORDSTATUS, V_WTHFLAG, V_CHANNEL_NO;
       EXIT WHEN V_CURSOR%NOTFOUND;

       -- 检查每笔委托的撤单标志，如果撤单标志为“待撤”或“已撤”，说明已经有撤单操作，废弃该笔撤单操作；
	   -- 修改成只有是“已撤”状态才不允许再撤单，lixin，2017-04-07
       IF (V_WTHFLAG = 2) THEN
           GOTO LABEL_NEXT_ROW;
       END IF;

       -- 检查每笔委托状态，如果委托状态为内部撤单(3)、外部撤单(9)、全部成交(7)、部分撤单(8)以及废单(2)等最终状态时，废弃该笔撤单操作；
       IF (V_ORDSTATUS = 2 OR V_ORDSTATUS = 3 OR V_ORDSTATUS = 7 OR V_ORDSTATUS = 8 OR V_ORDSTATUS = 9) THEN
           GOTO LABEL_NEXT_ROW;
       END IF;

       -- 如果委托状态为待报，则把委托状态修改为“内部撤单”和撤单标记修改为“已撤”，并赋值内部撤单输出参数
       IF V_ORDSTATUS = 0 THEN
          UPDATE TTRD_EXH_ORDER SET ORDSTATUS = 3, WTHFLAG = 2 WHERE SYSORDID = V_SYSORDID;
          IF INNER_WITHDRAWED_NUM > 0 THEN
             PO_INNER_WITHDRAW_ORDIDS := PO_INNER_WITHDRAW_ORDIDS || ',' || V_SYSORDID;
             PO_INNER_WITHDRAW_CHANNEL_NOS := PO_INNER_WITHDRAW_CHANNEL_NOS || ',' || V_CHANNEL_NO;
          ELSE
             PO_INNER_WITHDRAW_ORDIDS := V_SYSORDID;
             PO_INNER_WITHDRAW_CHANNEL_NOS := V_CHANNEL_NO;
          END IF;

          INNER_WITHDRAWED_NUM := INNER_WITHDRAWED_NUM + 1;
          GOTO LABEL_NEXT_ROW;
       END IF;

       -- 修改委托的撤单标记，当撤单标记为“无”时，则修改为“待撤”,并赋值确认撤单操作输出参数
       UPDATE TTRD_EXH_ORDER SET WTHFLAG = 1 WHERE SYSORDID = V_SYSORDID;
       IF OK_NUM > 0 THEN
          PO_OK_ORDIDS := PO_OK_ORDIDS || ',' || V_SYSORDID;
          PO_OK_CHANNEL_NOS := PO_OK_CHANNEL_NOS || ',' || V_CHANNEL_NO;
       ELSE
          PO_OK_ORDIDS := V_SYSORDID;
          PO_OK_CHANNEL_NOS := V_CHANNEL_NO;
       END IF;
       OK_NUM := OK_NUM + 1;

    END LOOP;
    CLOSE V_CURSOR;

END;
/

