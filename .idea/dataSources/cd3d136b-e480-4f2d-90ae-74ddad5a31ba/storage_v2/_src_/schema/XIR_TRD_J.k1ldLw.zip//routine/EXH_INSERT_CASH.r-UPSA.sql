create PROCEDURE EXH_INSERT_CASH(PI_BEG_DATE      IN VARCHAR2,
                                                    PI_ACCID         IN VARCHAR2,
                                                    PI_PS_AMOUNT     IN NUMBER,
                                                    PI_PS_MARGIN     IN NUMBER,
                                                    PI_PS_AVAAMOUNT  IN NUMBER,
                                                    PI_PS_FREAMOUNT  IN NUMBER,
                                                    PI_RT_AMOUNT     IN NUMBER,
                                                    PI_RT_MARGIN     IN NUMBER,
                                                    PI_RT_AVAAMOUNT  IN NUMBER,
                                                    PI_RT_FREAMOUNT  IN NUMBER,
                                                    PI_RT_TOTALASSET IN NUMBER) AS
BEGIN
  INSERT INTO TTRD_EXH_ACC_BALANCE_CASH_EXT
    (BEG_DATE,
     ACCID,
     PS_AMOUNT,
     PS_MARGIN,
     PS_AVAAMOUNT,
     PS_FREAMOUNT,
     RT_AMOUNT,
     RT_MARGIN,
     RT_AVAAMOUNT,
     RT_FREAMOUNT,
     RT_TOTALASSET,
     PS_UPDATETIME,
     RT_UPDATETIME)
  VALUES
    (PI_BEG_DATE,
     PI_ACCID,
     PI_PS_AMOUNT,
     PI_PS_MARGIN,
     PI_PS_AVAAMOUNT,
     PI_PS_FREAMOUNT,
     PI_RT_AMOUNT,
     PI_RT_MARGIN,
     PI_RT_AVAAMOUNT,
     PI_RT_FREAMOUNT,
     PI_RT_TOTALASSET,
     CURRENT_DATE,
     CURRENT_DATE);
END;
/

