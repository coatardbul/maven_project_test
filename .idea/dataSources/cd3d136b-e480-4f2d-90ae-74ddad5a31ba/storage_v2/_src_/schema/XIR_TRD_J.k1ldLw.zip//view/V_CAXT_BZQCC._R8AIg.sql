create view V_CAXT_BZQCC as
  select
O.BEG_DATE,
S.CASH_ACCID,
O.EXT_SECU_ACCT_ID,
O.SECU_ACCT_ID,
O.I_CODE,
C.TRDTYPE,
O.A_TYPE,
O.M_TYPE,
case when O.AMOUNT !=0 then O.AMOUNT
  else 0 end as ZQCC,--券持仓
case when O.AMOUNT !=0 then O.AI
  else 0 end as ZQLX,--券持仓
case when (CA.START_DATE>O.BEG_DATE and C.SECU_SETDATE<=O.BEG_DATE) then 0-O.REAL_CP --首期证券清算款
  when (CA.MTR_DATE>O.BEG_DATE and CA.END_DATE<=O.BEG_DATE) then O.REAL_CP-O.DUE_AI --到期证券清算款
  else 0 end as ZQQSK--证券清算款
--O.REAL_CP,
--O.DUE_CP,
--O.AI,
--O.DUE_AI,
--CA.I_CODE,
--C.TRDTYPE,
--C.SECU_SETDATE,--券首期
--CA.END_DATE,--券到期
--CA.START_DATE,--资金首期
--CA.MTR_DATE,--资金到期
--CA.FST_SET_AMOUNT,
--CA.MTR_SET_AMOUNT
from
(
select
BEG_DATE, END_DATE, EXT_SECU_ACCT_ID, SECU_ACCT_ID, I_CODE, A_TYPE, M_TYPE,
sum(REAL_CP)+sum(DUE_CP) as AMOUNT,
sum(REAL_CP) as REAL_CP,
sum(DUE_CP) as DUE_CP,
sum(AI) as AI,
sum(DUE_AI) as DUE_AI
from ttrd_accounting_secu_obj A
group by BEG_DATE, END_DATE, EXT_SECU_ACCT_ID, SECU_ACCT_ID, I_CODE, A_TYPE, M_TYPE
--资金到期当前表差不到，券到期是2100年
union all
select
BEG_DATE, END_DATE, EXT_SECU_ACCT_ID, SECU_ACCT_ID, I_CODE, A_TYPE, M_TYPE,
REAL_CP+DUE_CP as AMOUNT,
REAL_CP,
DUE_CP,
AI,
DUE_AI
from ttrd_accounting_secu_obj_HIS A
where SET_DATE='1900-01-01'
) O
left join
ttrd_otc_trade C
on C.INTORDID=O.I_CODE
left join ttrd_cashlb ca
on C.INTORDID=CA.I_CODE
left join ttrd_acc_secu S
on O.SECU_ACCT_ID=S.ACCID
where  C.TRDTYPE in ('0150100','0150101') and C.ORDSTATUS='4' --'0150100'逆回购'0150101'正回购
and O.BEG_DATE<=CA.MTR_DATE
/

