create view VTRD_LIMIT_INST_REF_INFO as
  SELECT
    S.INST_ID      AS INSTID,
    S.SECU_INST_ID AS SECU_INSTID,
    S.I_CODE,
    S.A_TYPE,
    S.M_TYPE,
    IT.P_CLASS,
    S.BIZ_TYPE,
  s.secu_acct_id,
    s.ext_secu_acct_id,
    it.party_id as PARTY_ID,
     case
         when tr.ordstatus < 0 then
          nvl(case when ord.total_amount=0 then 1 else ord.remain_amount / ord.total_amount end * s.amount, 0)
         else
          nvl(s.amount, 0)
       end,
     abs(s2.amount) as cancel_amount,
    s.CURRENCY,
    0,
    0,
    0,
    CASE
        WHEN I.STATE = '99999'
        THEN tr.orddate
        ELSE s.set_finish_date
    END,
    1 as ORDSOURCE,
    null,
    null,
    null,
    null,
    null

FROM
    TTRD_SET_INSTRUCTION_SECU S
INNER JOIN TTRD_SET_INSTRUCTION I ON S.SECU_INST_ID = I.REF_SECU_INST_ID
                                  AND (I.STATE = '99999' OR  i.inst_type IN ('2','-10'))
INNER JOIN TTRD_INSTRUMENT IT ON S.I_CODE = IT.I_CODE
                                 AND S.A_TYPE = IT.A_TYPE
                                 AND S.M_TYPE = IT.M_TYPE
LEFT JOIN ttrd_otc_trade tr ON I.trade_id = tr.intordid
left join ttrd_otc_order ord on tr.ord_id=ord.ord_id
left join TTRD_SET_INSTRUCTION_SECU s2
on s2.inst_id = i.inst_id
and s.i_code = s2.i_code
and s.a_type = s2.a_type
and s.m_type = s2.m_type
and s.biz_type = s2.biz_type
and s2.cancel_flag = 1
where i.trd_type not in ('0000431','0000430','0000071','0000411',
                          '0000421','0000541','0000551','0000561',
                          '0000571','0000410','0000540','000560'
                          )
/

