create function REPLACE_ZERO(P_ARG1 IN NUMBER)
RETURN NUMBER IS
BEGIN
   if P_ARG1=0 then
     return null;
  else return P_ARG1;
  end if;
END;
/

