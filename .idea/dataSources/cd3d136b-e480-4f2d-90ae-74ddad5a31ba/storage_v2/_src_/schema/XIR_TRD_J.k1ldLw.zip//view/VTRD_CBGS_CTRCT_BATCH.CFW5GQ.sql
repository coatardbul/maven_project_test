create view VTRD_CBGS_CTRCT_BATCH as
  SELECT B.TXFLOWID AS TXFLOWID, --交易流水标识
    A.INSTR_ID, --中债指令编号
    A.CTRCT_ID, --合同编号
    A.TXID EXTORDID, --外汇交易中心外部成交编号
    (
        CASE
            WHEN A.GIV_ACCT_ID = A.ACCID --为本方托管账号
            THEN
                (SELECT MAP_VALUE
                   FROM VTRD_CBGS_SYS_CONVERT_MAP --判断买入卖出视图
                  WHERE MAP_ITEM = 'CBGS_CTRDBIZTYPE_MAP'
                    AND MAP_KEY = BIZTYPE ||
                        '_SELFGIV') --现券卖出
            ELSE
                  (SELECT MAP_VALUE
                 FROM VTRD_CBGS_SYS_CONVERT_MAP --判断买入卖出视图
                WHERE MAP_ITEM = 'CBGS_CTRDBIZTYPE_MAP'
                  AND MAP_KEY = BIZTYPE ||
                      '_SELFTAK') --现券买入
        END)  BIZTYPE, -- 业务类别
    A.ACCID   AS ZZDACCCODE, -- 本方托管账号
    A.ACCNAME AS ZZDACCNAME, -- 本方托管账号名称
    (
        CASE
            WHEN A.GIV_ACCT_ID = A.ACCID --为本方托管账号
            THEN A.TAK_ACCT_ID --收券账户
            ELSE A.GIV_ACCT_ID --付券账户
        END) PARTY_ZZDACCCODE, --对手方托管账号
    (
        CASE
            WHEN A.GIV_ACCT_ID = A.ACCID --为本方托管账号
            THEN A.TAK_ACCT_NAME --收券账户名称
            ELSE A.GIV_ACCT_NAME --付券账户名称
        END)         PARTY_ZZDACCNAME, --对手方托管账户名称
    A.QUERY_DATE     AS SETDATE, --结算日期
    A.SETTLEMENT1    AS SETTYPE, --结算方式
    A.SETTLE_AMOUNT1 AS AMOUNT, --结算金额
    A.QUERY_DATE, --查询日期
    B.UPDATETIME --更新时间
FROM TTRD_CBGS_SETTLEBIZ_BATCH A, --批量查询结果
    TTRD_CBGS_SETTLEBIZ_QUERY B --结算业务查询
WHERE A.CID = B.CID
AND A.REQUEST_CODE = 'BJ0301'




/

