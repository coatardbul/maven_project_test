create TYPE             "TB_CAT_SYS_VALUATION"                                          IS TABLE OF TYPE_CAT_SYS_VALUATION;
/

