create view VTRD_ACTINGTASK_CASHACC as
  SELECT ca.accid AS cash_acct_id,
    ca.accname  AS cash_acct_name,
    u.unit_id,
    ca.acting_task
FROM ttrd_acc_cash ca
LEFT JOIN ttrd_wmps_unit u
 ON ca.pc1 = u.unit_id




/

