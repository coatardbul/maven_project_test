create view V_SIMPLE_BLC_CASH as
  SELECT MAX(obj_id) AS obj_id,
    CASH_ACCT_ID,
    EXT_CASH_ACCT_ID,
    beg_date,
    MAX(blc_type) AS blc_type,
    set_date,
    CURRENCY,
    SUM(amount)        AS amount,
    SUM(FREEZE_AMOUNT) AS FREEZE_AMOUNT,
    SUM(USABLE_AMOUNT) AS USABLE_AMOUNT
FROM (SELECT OBJ_ID,
            CASH_ACCT_ID,
            EXT_CASH_ACCT_ID,
            beg_date,
            blc_type,
            CASE
                WHEN set_date = '1900-01-01'
                THEN beg_date
                ELSE set_date
            END set_date,
            amount,
            FREEZE_AMOUNT,
            USABLE_AMOUNT,
            CURRENCY
       FROM ttrd_blc_cash_obj )
GROUP BY CASH_ACCT_ID,
    EXT_CASH_ACCT_ID,
    beg_date,
    set_date,
    CURRENCY




/

