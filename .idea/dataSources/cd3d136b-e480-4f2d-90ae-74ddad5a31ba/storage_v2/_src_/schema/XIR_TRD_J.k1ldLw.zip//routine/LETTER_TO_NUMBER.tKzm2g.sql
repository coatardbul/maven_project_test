create function LETTER_TO_NUMBER(SCORE varchar2) return number is
  GRADE_NUMBER number(7, 2);
begin
  select B_GRADE_NUMBER
    into GRADE_NUMBER
    from tbnd_ext_rating_enum
   where B_GRADE = SCORE;
  return GRADE_NUMBER;
end;
/

