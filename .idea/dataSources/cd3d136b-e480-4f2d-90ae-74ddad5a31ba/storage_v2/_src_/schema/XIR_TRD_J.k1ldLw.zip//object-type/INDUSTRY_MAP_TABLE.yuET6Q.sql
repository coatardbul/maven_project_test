create TYPE             "INDUSTRY_MAP_TABLE"                                          AS TABLE OF INDUSTRY_MAP
/

