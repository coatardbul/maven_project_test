create view V_WLTH_NAV_YIELD as
  SELECT A.I_CODE,
       A.A_TYPE,
       A.M_TYPE,
       A.BEG_DATE,
       A.END_DATE,
       A.OBJ_ID,
       -1 * A.REAL_VOLUME AS VOLUME,
       (A.AI + A.CHG_FV) * -1 AS CUMU_PROFIT,
       COALESCE((C.AI + C.CHG_FV), 0) * -1 AS DAY_PROFIT,
       CASE
         WHEN A.REAL_VOLUME = 0 THEN
          0
         ELSE
          (COALESCE(C.AI + C.CHG_FV, 0) / A.REAL_VOLUME)
       END AS ACCRUAL,                              -- 收益  市值法
       CASE
         WHEN A.REAL_VOLUME = 0 THEN
          0
         ELSE
          (COALESCE(C.AI, 0) / A.REAL_VOLUME)
       END AS ACCRUAL_COST,                         -- 收益  成本法
       TO_CHAR(TO_DATE(A.BEG_DATE, 'YYYY-MM-DD') - 6, 'YYYY-MM-DD') AS PRE_DATE_7
  FROM TTRD_ACCOUNTING_SECU_OBJ_HIS A
 INNER JOIN TTRD_INSTRUMENT B
    ON A.I_CODE = B.I_CODE
   AND A.A_TYPE = B.A_TYPE
   AND A.M_TYPE = B.M_TYPE
   --AND B.P_CLASS = '货币型理财产品'
   AND A.TSK_ID = 'BLC'
   AND B.A_TYPE = 'SPT_NWM'
  LEFT JOIN (SELECT ACCTG_OBJ_ID,
                    SUM(AI) AS AI,
                    SUM(CHG_FV) AS CHG_FV,
                    TSK_ID,
                    CHG_DATE
               FROM TTRD_ACCOUNTING_SECU_CHG_HIS
              WHERE INST_ID = 0
                AND A_TYPE = 'SPT_NWM'
              GROUP BY ACCTG_OBJ_ID, TSK_ID, CHG_DATE) C
    ON A.OBJ_ID = C.ACCTG_OBJ_ID
   AND A.TSK_ID = C.TSK_ID
   AND A.BEG_DATE = C.CHG_DATE



/

