create view V_WLTH_NAV_YIELD_7 as
  SELECT A.BEG_DATE,
    A.END_DATE,
    A.I_CODE,
    A.A_TYPE,
    A.M_TYPE,
    A.VOLUME, --份额
    TRUNC(A.ACCRUAL * 10000, 4) AS PROFIT_1W, --万份收益  成本法
    TRUNC(A.ACCRUAL_COST * 10000, 4) AS PROFIT_1W_COST, --万份收益  市值法
    B.SIMPLE_YIELD_7, --七日年后收益率(单利)
    B.CUMU_YIELD_7,--七日年后收益率(复利)
    A.CUMU_PROFIT, --当期累计收益
    A.DAY_PROFIT --日累计收益
FROM V_WLTH_NAV_YIELD A
LEFT JOIN
    (SELECT N1.BEG_DATE,
            N1.I_CODE,
            N1.A_TYPE,
            N1.M_TYPE,
            TRUNC((SUM(N2.ACCRUAL) / COUNT(*)) * 365 * 100, 4) AS SIMPLE_YIELD_7,
            --,
            TRUNC((POWER(EXP(SUM(LN(1 +
            CASE
                WHEN N2.ACCRUAL<=-1
                THEN 0
                ELSE N2.ACCRUAL
            END ))), 365.0 / COUNT(*)) - 1) * 100, 4) AS CUMU_YIELD_7
       FROM V_WLTH_NAV_YIELD N1,
            V_WLTH_NAV_YIELD N2
      WHERE N1.I_CODE = N2.I_CODE
        AND N1.A_TYPE = N2.A_TYPE
        AND N1.M_TYPE = N2.M_TYPE
        AND N2.BEG_DATE <= N1.BEG_DATE
        AND N2.BEG_DATE >= N1.PRE_DATE_7
   GROUP BY N1.BEG_DATE,
            N1.I_CODE,
            N1.A_TYPE,
            N1.M_TYPE) B
 ON A.I_CODE = B.I_CODE
AND A.A_TYPE = B.A_TYPE
AND A.M_TYPE = B.M_TYPE
AND A.BEG_DATE = B.BEG_DATE



/

