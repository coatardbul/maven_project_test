create TYPE             "INDUSTRY_MAP"                                          force AS OBJECT
(
  NODE_ID VARCHAR2(60),
  SOURCE VARCHAR2(60),
  INDUSTRY VARCHAR2(60)
)
/

