create view VTRD_CBGS_SELF_BONDACCSTMT_SUM as
  SELECT B.TXFLOWID AS TXFLOWID,
    A.ACCID,--账户编号
    A.ACCNAME,--账户名称
    A.DTLD_DATE,--托管总对账单日期
    A.I_CODE,--债券代码、
    A.I_NAME,--债券简称、
    A.LDG_TYPE,--科目类型（可用、待付、质押、待购回、冻结）、
    A.LDG_BALANCE, --科目余额
    A.ACCSTAT_TYPE,--账户对账单类型
    A.START_DATE AS START_DATE,--开始日期
    A.END_DATE   AS END_DATE,--结束日期
    B.UPDATETIME AS UPDATETIME --更新时间
FROM TTRD_CBGS_BONDACCSTMT_SUM A,---总对账单
    TTRD_CBGS_BONDACCSTMT_QUERY B ---债券账户对账单查询
WHERE A.CID=B.CID




/

