create procedure TRYADDTABSEQUENCES(tabName in varchar2, startName in varchar2)
		Authid Current_User
        is
        n_col int;
        stmt VARCHAR(2000);
        begin
          select count(*) into n_col from user_sequences
                 where sequence_name = upper(tabName);
          if n_col<1 then
            stmt :='create sequence '||tabName||' minvalue 0 maxvalue 9999999999999999999999999999 start with  '||startName||' increment by 1 cache 20';
            execute immediate stmt;
          end if;
        end;




/

