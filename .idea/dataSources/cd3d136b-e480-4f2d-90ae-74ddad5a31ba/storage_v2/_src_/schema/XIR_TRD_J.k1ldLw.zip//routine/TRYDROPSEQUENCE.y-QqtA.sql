create PROCEDURE tryDropSequence(tableName IN varchar2) is
  stmt VARCHAR2(2000);
  row1 number;
begin
  select count(sequence_name)--
    into row1--
    from user_sequences--
   where sequence_name = upper(tableName);--
  IF (row1 > 0) THEN--
    stmt := 'DROP SEQUENCE ' || tableName;--
    execute immediate stmt;--
  END IF;--
END;
/

