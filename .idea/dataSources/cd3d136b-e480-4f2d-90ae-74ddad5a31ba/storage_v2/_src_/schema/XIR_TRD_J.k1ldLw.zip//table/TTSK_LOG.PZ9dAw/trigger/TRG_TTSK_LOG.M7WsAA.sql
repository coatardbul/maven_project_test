create trigger TRG_TTSK_LOG
  before insert or update
  on TTSK_LOG
  for each row
  BEGIN
    IF INSERTING THEN
      SELECT S_TTSK_LOG.NEXTVAL, TO_CHAR(SYSDATE, 'YYYY-MM-DD')
      INTO :NEW.LOG_ID, :NEW.LOG_DATE
      FROM DUAL;
    END IF;

    UPDATE TTSK_SERVICE
    SET    TS_LOG = SUBSTR(:NEW.LOG_DESC, 1, 500)
    WHERE  TS_ID = :NEW.TS_ID;
END;















/

