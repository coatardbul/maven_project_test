create view TEMP_ACTG_OBJ2 as
  (
select o.beg_date ,u.unit_code,nvl(tak.accname,'其他') accname, i.i_code, p.p_type_name as name,i.p_class, o.real_amount as real_amount,
o.real_cp+o.amrt_ir+nvl(oc.real_amount,0) as amrt_cp,o.ai as ai, i.i_name, p.p_type,unit_name as unit_name,i.a_type
from (select * from ttrd_accounting_secu_obj_his union select * from ttrd_accounting_secu_obj) o
left join （select * from ttrd_accounting_cash_obj_his union select * from ttrd_accounting_cash_obj ）oc
on o.secu_acct_id=oc.cash_acct_id and o.ext_secu_acct_id=oc.ext_cash_acct_id and o.beg_date = oc.beg_date
left join ttrd_instrument i on o.i_code = i.i_code and o.a_type = i.a_type and o.m_type = i.m_type
left join ttrd_p_type p on i.p_type = p.p_type
left join ttrd_acc_secu tas on o.secu_acct_id = tas.accid
left join ttrd_acc_secu tak on tas.ps2 = tak.accid
left join ttrd_acc_cash tac on tas.cash_accid = tac.accid
left join ttrd_wmps_unit u on tac.pc1 = u.unit_id
where o.a_type != 'SPT_NWMPORT'
)



/

