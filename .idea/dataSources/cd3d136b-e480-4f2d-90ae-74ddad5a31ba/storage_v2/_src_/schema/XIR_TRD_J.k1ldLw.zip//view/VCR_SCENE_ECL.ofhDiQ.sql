create view VCR_SCENE_ECL as
  SELECT NULL AS GROUP_ID,
       NULL AS SCN_ID,
       NULL AS SCN_NAME,
       NULL AS PE_CODE,
       NULL AS SCN_WEIGHT
  FROM DUAL WHERE 1<>1
/

comment on table VCR_SCENE_ECL
is 'ECL情景定义视图'
/

