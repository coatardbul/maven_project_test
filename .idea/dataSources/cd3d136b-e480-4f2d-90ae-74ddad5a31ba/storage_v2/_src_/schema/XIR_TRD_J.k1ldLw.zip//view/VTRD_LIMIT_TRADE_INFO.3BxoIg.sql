create view VTRD_LIMIT_TRADE_INFO as
  SELECT A.SRC_TYPE,
         A.SRC_ID,
         A.OCCUPY_OBJ_TYPE,
         A.ORD_ID AS ORD_ID,
         A.INTORDID,
         A.INST_ID,
         A.SECU_INST_ID,
         A.CASH_INST_ID,
         A.I_CODE,
         A.A_TYPE,
         A.M_TYPE,
         D.P_TYPE,
         D.P_CLASS,
         D.CURRENCY,
         D.I_NAME,
         TO_CHAR(D.ISSUER_ID) AS PARTY_ID,
         F.CLS_NAME,
         F.CLS_CODE,
         CASE
           WHEN A.BIZ_TYPE != '21103' AND
                D.P_TYPE IN ('0900', '0105', '0301') THEN
            0
           ELSE
            1
         END AS DK_FLAG,
         D.COUPON_TYPE,
         TO_DATE(D.MTR_DATE, 'yyyy-mm-dd') -
         TO_DATE(E.CURR_DATE, 'yyyy-mm-dd') AS REMAIN_TERM_DAY,
         --D.UNIT_TYPE,
         NVL(D.TERM_DAY,
             TO_DATE(D.MTR_DATE, 'yyyy-mm-dd') -
             TO_DATE(D.START_DATE, 'yyyy-mm-dd')) AS TERM_DAY,
         A.EXT_SECU_ACCT_ID,
         A.SECU_ACCT_ID,
         A.EXT_CASH_ACCT_ID,
         A.CASH_ACCT_ID,
         A.ORD_TOTAL_AMOUNT,
         A.ORD_CANCEL_AMOUNT,
         A.ORD_REMAIN_AMOUNT,
         A.ORD_REMAIN_AMOUNT_REAL,
         A.SETTLE_AMOUNT,
         CASE A.IS_SECU
           WHEN 1 THEN
            A.TRD_VOLUME * D.PAR_VALUE
           ELSE
            A.TRD_VOLUME
         END AS TRD_AMOUNT,
         A.TRD_DIRTY_PRICE,
         A.TRD_PRICE,
         A.TRD_PRICE_DEVIATION,
         A.TRD_VOLUME,
         A.TRD_YIELD_DEVIATION,
         A.SETDAYS,
         A.EXE_MARKET,
         A.END_SETTYPE,
         A.IS_GRP_TRADE,
         A.IS_INNER_TRADE,
         A.DIRECTION,
         A.TRD_TYPE,
         A.FIRST_SETTYPE,
         A.TRADER_ID,
         A.ORDDATE,
         A.ORDSTATUS,
         A.SET_DATE,
         A.TRADE_GRP_ID,
         A.OPR_STATE,
         A.OCCUPY_DATE,
         A.BLC_SECU_VOLUME,
         A.BLC_SECU_VOLUME_ABSZY,
         A.BLC_SECU_VOLUME_HGRC,
         A.BLC_SECU_VOLUME_HGRR,
         A.BLC_SECU_VOLUME_JDRC,
         A.BLC_SECU_VOLUME_JDRR,
         A.BLC_SECU_VOLUME_RC,
         A.BLC_SECU_VOLUME_RR,
         A.BLC_SECU_VOLUME_ZC,
       A.BLC_SECU_VOLUME_BZQZR,
       A.BLC_SECU_VOLUME_PTQZC,
         A.BLC_SECU_VOLUME_ZY,
         A.BLC_TYPE,
         A.BLC_SECU_VOLUME_RC + A.BLC_SECU_VOLUME_RR + A.BLC_SECU_VOLUME_ZC +
       A.BLC_SECU_VOLUME_PTQZC + A.BLC_SECU_VOLUME_ZY AS BLC_SECU_VOLUME_KY,
         A.REAL_VOLUME,
         A.REAL_AMOUNT,
         A.ABSREAL_AMOUNT,
         A.FULL_CP,
         A.REAL_CP_NOAMRT,
         A. COST_METHOD_AMOUNT,
         A.MARKET_METHOD_AMOUNT,
         A.NET_CP,
         A.MOCK_TYPE,
         A.PARTY_ID2
    FROM VTRD_LIMIT_TRADE_INFO_CORE A
   INNER JOIN TTRD_INSTRUMENT D
      ON A.I_CODE = D.I_CODE
     AND A.A_TYPE = D.A_TYPE
     AND A.M_TYPE = D.M_TYPE
    LEFT JOIN TTRD_LIMIT_CLS_CODE F
      ON INSTR(F.P_TYPE, D.P_TYPE) > 0
   INNER JOIN TTRD_CURRDATE E
      ON 1 = 1
   WHERE A.I_CODE NOT LIKE '%@%'
     AND A.BIZ_TYPE <> '26101'
/

