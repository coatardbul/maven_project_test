create PROCEDURE EXH_REALDEAL(PI_EXTORDID       IN VARCHAR2,  -- 外部委托序号
                                         PI_EXTDEAID       IN VARCHAR2,  -- 外部成交编号
                                         PI_DEADATE        IN CHAR,      -- 成交日期
                                         PI_DEADATE_ORG    IN VARCHAR2,  -- 成交日期，对于报价回购提前购回，表示初次交易的成交日期
                                         PI_DEATIME        IN CHAR,      -- 成交时间
                                         PI_CASH_EXT_ACCID IN VARCHAR2,  -- 外部资金账户
                                         PI_SECU_EXT_ACCID IN VARCHAR2,  -- 外部证券账户
                                         PI_CHANNELNO      IN VARCHAR2,  -- 通道号
                                         PI_TRDTYPE        IN VARCHAR2,  -- 成交业务类型
                                         PI_OCFLAG         IN VARCHAR2,  -- 开平标记
                                         PI_I_CODE         IN VARCHAR2,  -- 资产代码
                                         PI_A_TYPE         IN VARCHAR2,  -- 资产类型
                                         PI_M_TYPE         IN VARCHAR2,  -- 市场类型
                                         PI_LS             IN CHAR,      -- 多空标识
                                         PI_IS_CHECK       IN NUMBER,    -- 是否验资验券（0,1）
                                         PI_DEACOUNT       IN NUMBER,    -- 成交数量，存储过程内部取ABS
                                         PI_DEAPRICE       IN NUMBER,    -- 成交价格，存储过程内部取ABS
                                         PI_DEAAMOUNT      IN NUMBER,    -- 成交金额，存储过程内部取ABS
                                         PI_DEAFEE         IN NUMBER,    -- 成交费用，存储过程内部取ABS
                                         PI_DEAAI          IN NUMBER,    -- 成交应计利息，存储过程内部取ABS
                                         PI_SUMMARY        IN VARCHAR2,  -- 摘要
                                         PI_DATASOURCE     IN VARCHAR2,  -- 数据来源
                                         PI_ISFIXED        IN INTEGER,   -- 执行场所，0=竞价系统；1=固定收益；2=大宗交易
                                         PI_SYSORDID       IN NUMBER,    -- 系统委托编号
                                         PI_SYSDEAID       IN NUMBER,    -- 系统成交编号
                                         PI_EXTFLAG1       IN VARCHAR2,  -- 外部编号1，中金所OrderSysID
                                         PI_EXTFLAG2       IN VARCHAR2,  -- 外部编号2，中金所ExchangeID
                                         PI_OCCUR_MARGIN   IN NUMBER,    -- 保证金变化（带符号）
                                         PI_OCCUR_CASH     IN NUMBER,    -- 资金变化（带符号）
                                         PI_OCCUR_SECU     IN NUMBER,    -- 股份变化（带符号）
                                         PI_TRADE_GRP      IN VARCHAR2,  -- 交易分组
                                         PI_INSID_ORG      IN VARCHAR2,  -- 原始指令编号
                                         PO_SYSORDID       OUT NUMBER,  -- 委托操作回报时返回原系统委托号
                                         PO_INSID          OUT VARCHAR2,   -- 指令号
                                         PO_BATCHID        OUT NUMBER,     -- 批次号
                                         PO_ERRCODE        OUT NUMBER,   -- 输出错误号
                                         PO_ERRINFO        OUT VARCHAR2  -- 输出错误信息
                                         ) AS
/*
   1） 判断是否为本系统委托;
   2） 如果不是本系统委托
       a) 插入无主成交表
       b) 增加或减少外部资金股份余额

   3） 如果是本系统委托
       a) 插入有主成交表
       b) 解冻外部资金或股份余额
       d) 增加或减少外部资金股份余额
       d) 修改委托表的成交数量、成交金额、冻结金额、冻结费用
       e) 修改委托状态为全部成交或部分成交
   4） 发送委托状态信息、成交信息到MQ，通知应用服务
*/

/*
  错误号定义：（负号表示错误，正号表示警告，0表示正确），委托应答以“15”开头
     -15011 = 资金余额不存在
     -15013 = 股份余额不存在
     -15003 = 调整资金失败
     -15004 = 调整股份失败
*/

  -- 委托状态
  V_ORDSTATUS INTEGER;
  -- 记录数
  V_CNT INTEGER;
  -- 外部委托号、外部号码1
  V_EXTORDID VARCHAR(50);
  V_EXTFLAG1 VARCHAR(50);
  V_IMP_TIME VARCHAR(50);
  -- 解冻数
  V_UNFREEZE_CNT NUMBER;
  V_UNFREEZE_AMT NUMBER;
  V_UNFREEZE_FEE NUMBER;

  -- 撤单数量
  V_WTHCOUNT NUMBER;

  -- 定义委托表光标集
  CURSOR CUR_ORDER(P_SYSORDID IN NUMBER, P_CHANNEL_NO IN VARCHAR2, P_M_TYPE IN VARCHAR2, P_EXTORDID IN VARCHAR2) IS
     SELECT *
     FROM TTRD_EXH_ORDER
     WHERE (P_SYSORDID > 0 AND SYSORDID = P_SYSORDID) OR
           (P_SYSORDID <= 0 AND EXTORDID = P_EXTORDID AND CHANNEL_NO = P_CHANNEL_NO AND M_TYPE = P_M_TYPE)
     FOR UPDATE;

  -- 定义委托表记录集
  REC_ORDER TTRD_EXH_ORDER%ROWTYPE;

BEGIN
   PO_SYSORDID := 0;
   PO_INSID := '';
   PO_BATCHID := 0;
   PO_ERRCODE := 0;
   PO_ERRINFO := '';

   V_UNFREEZE_CNT := 0;
   V_UNFREEZE_AMT := 0;
   V_UNFREEZE_FEE := 0;

   -- 打开委托表光标集
   SELECT TO_CHAR(LOCALTIMESTAMP,'HH24:MI:SS:FF4') INTO V_IMP_TIME FROM DUAL;
   OPEN CUR_ORDER(PI_SYSORDID, PI_CHANNELNO, PI_M_TYPE, PI_EXTORDID);
   FETCH CUR_ORDER INTO REC_ORDER;

   -- 非系统委托，插入到PENDING表
   IF CUR_ORDER%NOTFOUND THEN
      -- 无主成交，默认取PI_EXTORDID，如果EXTFLAG1 & EXTFLAG2不为空，因为此时的PI_EXTORDID可能为空，所以取EXTFLAG1|EXTFLAG2（例如中金所系统中心号）
      -- 这样对于PENDING表，可以按市场，通道号，成交日期，外部委托号，外部成交号为关键字
      V_EXTORDID := PI_EXTORDID;
      V_EXTFLAG1 := PI_EXTFLAG1;
      IF (PI_EXTFLAG1 IS NOT NULL) AND (PI_EXTFLAG2 IS NOT NULL) THEN
         V_EXTORDID := PI_EXTFLAG1 || '|' || PI_EXTFLAG2;
      END IF;

      SELECT COUNT(1) INTO V_CNT FROM TTRD_DEAL_PENDING WHERE EXTORDID = V_EXTORDID AND EXTDEAID = PI_EXTDEAID AND CHANNEL_NO = PI_CHANNELNO AND DEADATE = PI_DEADATE AND M_TYPE = PI_M_TYPE;
      IF V_CNT >= 1 THEN
         -- 如果无主成交表存在，则说明已经处理，直接退出
         GOTO LABLE_EXIT;
      END IF;

      INSERT INTO TTRD_DEAL_PENDING(EXTORDID, EXTDEAID, DEADATE, DEATIME, CASH_EXT_ACCID, SECU_EXT_ACCID, CHANNEL_NO,
         TRDTYPE, OCFLAG, I_CODE, A_TYPE, M_TYPE, DEACOUNT, DEAPRICE, DEAAMOUNT, INTEREST, DEAFEE, SUMMARY, DATASOURCE, ISFIXED, STATUS,
         EXTFLAG1, EXTFLAG2, INSLIST, INSLIST_CANCEL, LASTUPDATETIME, IMP_TIME, DEADATE_ORG, TRADE_GRP, INSID_ORG)
      VALUES(V_EXTORDID, PI_EXTDEAID, PI_DEADATE, PI_DEATIME, PI_CASH_EXT_ACCID, PI_SECU_EXT_ACCID, PI_CHANNELNO,
         PI_TRDTYPE, PI_OCFLAG, PI_I_CODE, PI_A_TYPE, PI_M_TYPE, ABS(PI_DEACOUNT), ABS(PI_DEAPRICE), ABS(PI_DEAAMOUNT), ABS(PI_DEAAI),
         ABS(PI_DEAFEE), PI_SUMMARY, PI_DATASOURCE, PI_ISFIXED, 0, V_EXTFLAG1, PI_EXTFLAG2, '', '', TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS'), V_IMP_TIME, PI_DEADATE_ORG, PI_TRADE_GRP, PI_INSID_ORG);
   ELSE
      SELECT COUNT(1) INTO V_CNT FROM TTRD_EXH_DEAL WHERE EXTORDID = PI_EXTORDID AND EXTDEAID = PI_EXTDEAID AND CHANNEL_NO = PI_CHANNELNO AND DEADATE = PI_DEADATE AND M_TYPE = PI_M_TYPE;
      IF V_CNT >= 1 THEN
         -- 如果成交表存在，则说明已经处理，直接退出
         GOTO LABLE_EXIT;
      END IF;

      -- maosx，输出系统委托号、指令号、批次号
      PO_SYSORDID := REC_ORDER.SYSORDID;
      PO_INSID := REC_ORDER.INSID;
      PO_BATCHID := REC_ORDER.BATCHID;

      -- 1 插入系统成交表
      INSERT INTO TTRD_EXH_DEAL(ORDDATE, SYSORDID, SYSDEAID, EXTORDID, EXTDEAID, DEADATE, DEATIME, CASH_EXT_ACCID, SECU_EXT_ACCID, CHANNEL_NO,
         I_CODE, A_TYPE, M_TYPE, DEACOUNT, DEAPRICE, DEAAMOUNT, DEAFEE, SUMMARY, EXTFLAG1, EXTFLAG2, IMP_TIME)
      VALUES(REC_ORDER.ORDDATE, REC_ORDER.SYSORDID, PI_SYSDEAID, PI_EXTORDID, PI_EXTDEAID, PI_DEADATE, PI_DEATIME, PI_CASH_EXT_ACCID,
         PI_SECU_EXT_ACCID, PI_CHANNELNO, PI_I_CODE, PI_A_TYPE, PI_M_TYPE, ABS(PI_DEACOUNT), ABS(PI_DEAPRICE), ABS(PI_DEAAMOUNT),
         ABS(PI_DEAFEE), PI_SUMMARY, PI_EXTFLAG1, PI_EXTFLAG2, V_IMP_TIME);

      -- 2 如果委托状态为（5=已报；6=部成）时，才需要解冻资金和股份
      IF (PI_IS_CHECK <> 0) AND (REC_ORDER.ORDSTATUS = 5 OR REC_ORDER.ORDSTATUS = 6) THEN
         V_UNFREEZE_AMT := -1 * ABS(PI_DEACOUNT) * REC_ORDER.ORDFROZENAMT / REC_ORDER.ORDCOUNT;
         V_UNFREEZE_FEE := -1 * ABS(PI_DEACOUNT) * REC_ORDER.ORDFROZENFEE / REC_ORDER.ORDCOUNT;
         V_UNFREEZE_CNT := 0;
         IF REC_ORDER.OCFLAG = 'C' THEN
            V_UNFREEZE_CNT := -1 * ABS(PI_DEACOUNT);
         END IF;

         EXH_FREEZE_CASH_SECU(REC_ORDER.CASH_EXT_ACCID, REC_ORDER.SECU_EXT_ACCID, REC_ORDER.I_CODE, REC_ORDER.A_TYPE, REC_ORDER.M_TYPE,
                              PI_LS, V_UNFREEZE_CNT, V_UNFREEZE_AMT, V_UNFREEZE_FEE, 0, PO_ERRCODE, PO_ERRINFO);

         IF PO_ERRCODE < 0 THEN
            PO_ERRCODE := PO_ERRCODE - 5000;
         END IF;

      END IF;

      -- 3 更新委托表,，成交数量、成交金额、委托状态（6=部成；7=全成；8=部撤；9=全撤）等字段
      --    只所以这么修改，是因为出现现有撤单回报后有成交的情况
      IF REC_ORDER.ORDCOUNT = REC_ORDER.DEACOUNT + ABS(PI_DEACOUNT) THEN
         -- 处理全成情况
         V_ORDSTATUS := 7;
         UPDATE TTRD_EXH_ORDER
         SET ORDSTATUS    = V_ORDSTATUS,
             DEACOUNT     = DEACOUNT + ABS(PI_DEACOUNT),
             DEAAMOUNT    = DEAAMOUNT + ABS(PI_DEAAMOUNT),
             WTHCOUNT     = 0,
             WTHFLAG      = 0
         WHERE CURRENT OF CUR_ORDER;
      ELSE
         IF (REC_ORDER.ORDSTATUS = 8) OR (REC_ORDER.ORDSTATUS = 9) THEN
            -- 处理原状态为部撤或全撤情况
            V_ORDSTATUS := 8;
            V_WTHCOUNT  := REC_ORDER.ORDCOUNT - REC_ORDER.DEACOUNT - ABS(PI_DEACOUNT);
         ELSE
            V_ORDSTATUS := 6;
            V_WTHCOUNT := 0;
         END IF;

         UPDATE TTRD_EXH_ORDER
         SET ORDSTATUS    = V_ORDSTATUS,
             DEACOUNT     = DEACOUNT + ABS(PI_DEACOUNT),
             DEAAMOUNT    = DEAAMOUNT + ABS(PI_DEAAMOUNT),
             WTHCOUNT     = V_WTHCOUNT
         WHERE CURRENT OF CUR_ORDER;
      END IF;
   END IF;


   -- 调整资金和股份
   IF PI_IS_CHECK <> 0 THEN

      SAVEPOINT SP_ADJUST;

      -- 调整资金
      EXH_ADJUST_CASH(PI_CASH_EXT_ACCID, PI_OCCUR_CASH, PI_OCCUR_MARGIN, PO_ERRCODE, PO_ERRINFO);
      IF PO_ERRCODE < 0 THEN
         PO_ERRCODE := -15003;
         GOTO LABLE_ADJUST;
      END IF;

      -- 调整股份
      EXH_ADJUST_SECU(PI_SECU_EXT_ACCID, PI_I_CODE, PI_A_TYPE, PI_M_TYPE, PI_LS, PI_TRDTYPE, PI_OCFLAG, PI_OCCUR_SECU, PO_ERRCODE, PO_ERRINFO);
      IF PO_ERRCODE < 0 THEN
         PO_ERRCODE := -15004;
         GOTO LABLE_ADJUST;
      END IF;

      -- 调整标签
      <<LABLE_ADJUST>>
      IF PO_ERRCODE <> 0 THEN
         ROLLBACK TO SP_ADJUST;
      END IF;
   END IF;


   <<LABLE_EXIT>>

   -- 关闭游标
   IF CUR_ORDER%ISOPEN THEN
      CLOSE CUR_ORDER;
   END IF;

END;
/

