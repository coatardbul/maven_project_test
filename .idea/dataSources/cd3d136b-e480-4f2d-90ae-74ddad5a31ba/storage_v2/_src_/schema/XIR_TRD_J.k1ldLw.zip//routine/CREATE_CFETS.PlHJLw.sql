create PROCEDURE             "CREATE_CFETS"(p_sysordid NUMBER)
as
  v_par_value ttrd_instrument.par_value%type;
  v_cfets ttrd_cfets_executionreport%rowtype;
  config_cfets ttrd_cfets_executionreport%rowtype;
  v_trade ttrd_otc_trade%rowtype;
  t_varchar varchar(50);
begin
  select * into v_trade from ttrd_otc_trade where sysordid = p_sysordid;
  --序号
  select (sysdate-to_date('1970-01-01','yyyy-mm-dd')-8/24)*24*60*60 into v_cfets.EPID from dual;
  --交易时间
  v_cfets.TRDDATE:=v_trade.orddate;
  v_cfets.TRDTIME:=trim(v_trade.ordtime);
  --成交编号
  select 'CBT'||to_char(sysdate,'yyyymmddhh24miss') into v_cfets.EXECID from dual;
  --交易类型
  v_cfets.TRDTYPE:=v_trade.trdtype;
  --0-全部;1-信用拆借;2-利率互换;3-远期利率协议;4-现券买卖;5-债券远期;6-资产支持证券;7-ETFS ;8-债券借贷;9-质押式回购;10 -买断式回购;11 -外汇掉期;12 -外汇即期;13 -轧差清算远期;14 -外汇远期;15 -外汇利率互换;16 -基准（SHIBOR);17 -外汇货币互换;
  v_cfets.MARKETINDICATOR:='4';
  --交易方向 1-买入 / 拆入 / 融入 / 逆回购/固定支付/参考利率1支付  4-卖出 / 拆出 / 融出 / 正回购/固定收取/参考利率1收取
  if substr(v_trade.trdtype,7)='0' then
     v_cfets.DIRCTION:='1';
  else v_cfets.DIRCTION:='4';
  end if;
  --交易对手
  select org_id into v_cfets.PARTY from ttrd_institution where i_id=v_trade.partyid;
  --本方交易员
  v_cfets.TRADER:=v_cfets.trader;
  --本方资金账号
  select t.exhacc,t.accname,t.large_pay_accno,t.bank_name
  into v_cfets.CASH_ACCT_NUMBER,v_cfets.CASH_ACCT_NAME,v_cfets.SETTL_BANK_SORTCODE,v_cfets.SETTL_BANK_NAME
  from ttrd_acc_cash_ext t where accid = v_trade.cash_ext_accid;
  --本方证券账号
  select t.exhacc,t.accname,t.host_market--本方托管机构没有 暂时用host_market代替
  into v_cfets.custodain_acct_number,v_cfets.custodian_acct_name,v_cfets.custodian_name
  from ttrd_acc_secu_ext t where accid = v_trade.secu_ext_accid;
  --交易对手
  select org_id into v_cfets.COUNTERPARTY from ttrd_institution where i_id=v_trade.partyid;
  --交易对手操作员
  v_cfets.CP_TRADER:=v_trade.trader_cp;
  --对手方账户
  v_cfets.CP_CASH_ACCT_NUMBER:=v_trade.party_acct_code;
  v_cfets.CP_CASH_ACCT_NAME:=v_trade.party_acct_name;
  v_cfets.CP_SETTL_BANK_NAME:=v_trade.party_bank_name;
  v_cfets.CP_SETTL_BANK_SORTCODE:=v_trade.party_bank_code;
  v_cfets.CP_CUSTODIAN_ACCT_NAME:=v_trade.party_zzdaccname;
  --v_cfets.CP_CUSTODIAN_NAME:=v_trade.party_zzdaccname; 对手托管机构 没有
  v_cfets.CP_CUSTODAIN_ACCT_NUMBER:=v_trade.party_zzdacccode;
  --金融工具
  v_cfets.I_CODE:=v_trade.i_code;
  v_cfets.A_TYPE:=v_trade.a_type;
  v_cfets.M_TYPE:=v_trade.m_type;
  v_cfets.I_NAME:=v_trade.i_name;
  --U金融工具
  v_cfets.U_I_CODE:='';
  v_cfets.U_A_TYPE:='';
  v_cfets.U_M_TYPE:='';
  v_cfets.U_I_NAME:='';
  --净价
  v_cfets.PRICE:=v_trade.bnd_netprice;
  --全价
  v_cfets.DIRTY_PRICE:=v_trade.ordprice;
  --到期收益率
  v_cfets.YTM:=v_trade.bnd_ytm;
  --U价格
  v_cfets.U_CLEAR_PRICE:='0.00000000';
  v_cfets.U_CLEAR_PRICE2:='0.00000000';
  v_cfets.U_AI_AMT:='0.00000000';
  v_cfets.U_AI_AMT2:='0.00000000';
  v_cfets.U_DIRTY_PRICE:='0.00000000';
  v_cfets.U_DIRTY_PRICE2:='0.00000000';
  v_cfets.U_YTM:='0.00000000';
  v_cfets.U_YTM2:='0.00000000';
  --先去下parValue用于计算
  select par_value into v_par_value from ttrd_instrument
  where i_code=v_trade.i_code and a_type =v_trade.a_type and m_type = v_trade.m_type;
  --券面总额
  v_cfets.TRDFV:=v_trade.ordcount*v_par_value;
  --净价金额
  v_cfets.TRDCASHAMT:=v_trade.ordamount-v_trade.bnd_aiamount;
  --费用
  v_cfets.TRDFEE:='0.000000';
  --结算日期
  v_cfets.SETDATE:=v_trade.setdate;
  v_cfets.SETDATE2:='';
  --期限
  v_cfets.TRADELIMITDAYS:='0';
  --?
  v_cfets.CASHHOLDINGDAYS:='0';
  --全价金额
  v_cfets.SETTLCURRAMT:=v_trade.ordamount;
  v_cfets.SETTLCURRAMT2:='0.000000';
  --0 - DVP;4 - PUD;5 - DUP;6 - BVB;7-NONE
  v_cfets.DELIVERYTYPE:='0';
  v_cfets.DELIVERYTYPE2:='0';
  --总应计利息
  v_cfets.AI_TOTALAMT:=v_trade.bnd_aiamount;
  --F- 成交;H - 撤销;5 - 更新;101-应急;
  v_cfets.EXECTYPE:='F';
  --
  v_cfets.MARGINREQUIRED:='';
  v_cfets.MG_REPLACEMENT:='';
  v_cfets.MG_SUBMITDATE:='';
  v_cfets.MG_CASHAMT:='0.000000';
  v_cfets.CP_MG_CASHAMT:='0.000000';
  v_cfets.MG_PARVALUE:='0.000000';
  v_cfets.CP_MG_PARVALUE:='0.000000';
  v_cfets.MG_CASH_ACCT_NUMBER:='';
  v_cfets.MG_CASH_ACCT_NAME:='';
  v_cfets.MG_SETTL_BANK_NAME:='';
  v_cfets.MG_SETTL_BANK_SORTCODE:='';
  v_cfets.MG_CUSTODIAN_ACCT_NAME:='';
  v_cfets.MG_CUSTODIAN_NAME:='';
  v_cfets.MG_CUSTODAIN_ACCT_NUMBER:='';
  v_cfets.CP_MG_REPLACEMENT:='';
  v_cfets.CP_MG_SUBMITDATE:='';
  v_cfets.CP_MG_CASH_ACCT_NUMBER:='';
  v_cfets.CP_MG_CASH_ACCT_NAME:='';
  v_cfets.CP_MG_SETTL_BANK_NAME:='';
  v_cfets.CP_MG_SETTL_BANK_SORTCODE:='';
  v_cfets.CP_MG_CUSTODIAN_ACCT_NAME:='';
  v_cfets.CP_MG_CUSTODIAN_NAME:='';
  v_cfets.CP_MG_CUSTODAIN_ACCT_NUMBER:='';
  v_cfets.REMARK:='';

  select to_char(systimestamp,'YYYYMMDDHH24MISSFF3') into t_varchar from dual;
  --报价编号
  v_cfets.QUOTEID:=t_varchar;
  --订单编号
  v_cfets.ORDERID:=t_varchar;
  --1-非做市；2-做市
  v_cfets.BND_TRDTYPE:='1';

  v_cfets.TERMTOMATURITY:='0.000000';
  v_cfets.FEE_AMT:='0.000000';
  v_cfets.DISPUTESETTLMETHOD:='';
  v_cfets.FRA_DISCOUNT:='0.000000000000';
  v_cfets.FRA_INTERESTFIXDATE:='';
  v_cfets.FRA_COUPONPAYMENTDATE:='';
  v_cfets.FRA_BUSINESSDAYCONV:='';
  v_cfets.FRA_DAYCOUNT:='';
  v_cfets.IRS_INTERESTACCURALDAYSADJ:='';
  v_cfets.IRS_COUPONPAYMENTDATERESET:='';
  --1-匹配； 2-未匹配  ; 3-撤销
  v_cfets.STATUS:='2';
  --处理时间
  select to_char(systimestamp,'YYYYMMDD-HH24:MI:SS.FF3') into v_cfets.TRANSACTTIME from dual;
  --应计利息
  v_cfets.AI:='';
  select sysdate into v_cfets.IMP_TIME from dual;
  insert into ttrd_cfets_executionreport values v_cfets;
end create_cfets;




/

