create view VCALC_BND_TAG as
  SELECT I_CODE,
       A_TYPE,
       M_TYPE,
       B_EMBOPT_TYPE,
       B_FPML,
       Q_TYPE,
       S_TYPE,
       I_CODE_BENCH,
       A_TYPE_BENCH,
       M_TYPE_BENCH,
       B_ACTUAL_MTR_DATE,
       B_AMORTIZING,
       Q_PAR_VALUE,
       NULL AS TAG_VERSION,
       IMP_TIME
FROM TBND
/

comment on table VCALC_BND_TAG
is 'tag版本债券视图'
/

