create trigger INSERT_PAYMENTINFO_REAL_CODE
  before insert
  on TBSI_PAYMENTINFO
  for each row
  DECLARE
  U_I_CODE2     Varchar2(30);
BEGIN
 IF :new.STREAM_ID IS NOT NULL AND  :new.STREAM_ID LIKE 'leg%' THEN
    :new.REAL_I_CODE := :new.I_CODE || '@' || :new.STREAM_ID ;
 ELSE
    :new.REAL_I_CODE := :new.I_CODE;
 END IF;
end;















/

