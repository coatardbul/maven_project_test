create view V_ACCOUNTING_OBJ_INIT as
  SELECT "BKP_TYPE",
    "SRC_TYPE",
    "SECU_ACCT_TYPE",
    "P_TYPE",
    "P_CLASS",
    "SUBJ_MATTER_P_CLASS",
    "GRP_TYPE",
    "BOND_TYPE",
    "V_CURRENCY",
    "V_SUBJ_ORG_ID",
    "V_CORE_ACCT_CODE",
    "OBJ_ID",
    "TSK_ID",
    "BEG_DATE",
    "ACCT_ID",
    "SECU_ACCT_ID",
    "CASH_ACCT_ID",
    "EXT_ACCT_ID",
    "I_CODE",
    "A_TYPE",
    "M_TYPE",
    "LONG_OR_SHORT",
    "SECU_REAL_VOLUME",
    "SECU_REAL_AMOUNT",
    "SECU_DUE_AMOUNT",
    "SECU_REAL_CP",
    "SECU_DUE_CP",
    "SECU_PRFT_FEE",
    "SECU_AI",
    "SECU_DUE_AI",
    "SECU_AMRT_IR",
    "SECU_PRFT_FV",
    "SECU_CHG_FV",
    "SECU_PRFT_IR",
    "SECU_PRFT_TRD",
    "CASH_REAL_AMOUNT",
    "SECU_OBJ_ID",
    "CASH_OBJ_ID",
    "DUE_OBJ_ID"
FROM (--支出管理账
     SELECT 'GLKJ' AS BKP_TYPE,
            'Secu' AS SRC_TYPE,
            --映射表输入维度：内部证券账户类型
            ACC_SECU.ACCNAME AS SECU_ACCT_TYPE,
            --映射表输入维度：产品类型
            INSTRUMENT.P_TYPE,
            --映射表输入维度：产品分类
            INSTRUMENT.P_ClASS,
            '' AS SUBJ_MATTER_P_CLASS,
            --映射表输入维度：承分销组合类型1 承分销 0非承分销
            TO_CHAR(TRDGRP.GRPTYPE) AS GRP_TYPE,
            --映射表输入维度：发行方式
            '' AS BOND_TYPE,
            --映射表输出维度：币种7
            INSTRUMENT.CURRENCY AS V_CURRENCY,
            ----映射表输出维度：记账机构Id
            UNIT.ORG_ID AS V_SUBJ_ORG_ID,
            --映射表输出维度：核心账号
            '' AS V_CORE_ACCT_CODE,
            A.OBJ_ID,
            A.TSK_ID,
            A.BEG_DATE,
            A.SECU_ACCT_ID     AS ACCT_ID,
            A.SECU_ACCT_ID     AS SECU_ACCT_ID,
            '-1'               AS CASH_ACCT_ID,
            A.EXT_SECU_ACCT_ID AS EXT_ACCT_ID,
            A.I_CODE,
            A.A_TYPE,
            A.M_TYPE,
            A.EXTRA_DIM            AS long_or_short,
            A.REAL_VOLUME          AS SECU_REAL_VOLUME,
            A.REAL_AMOUNT          AS SECU_REAL_AMOUNT,
            A.DUE_AMOUNT           AS SECU_DUE_AMOUNT,
            A.REAL_CP              AS SECU_REAL_CP,
            A.DUE_CP               AS SECU_DUE_CP,
            COALESCE(A.PRFT_FEE,0) AS SECU_PRFT_FEE,
            A.AI                   AS SECU_AI,
            A.DUE_AI               AS SECU_DUE_AI,
            A.AMRT_IR              AS SECU_AMRT_IR,
            A.PRFT_FV              AS SECU_PRFT_FV,
            A.CHG_FV               AS SECU_CHG_FV,
            A.PRFT_IR              AS SECU_PRFT_IR,
            A.PRFT_TRD             AS SECU_PRFT_TRD,
            0                      AS CASH_REAL_AMOUNT,
            A.OBJ_ID               AS SECU_OBJ_ID,
            ''                     AS CASH_OBJ_ID,
            ''                     AS DUE_OBJ_ID
       FROM ( SELECT *
               FROM TTRD_ACCOUNTING_SECU_OBJ_HIS
          UNION ALL
             SELECT *
               FROM TTRD_ACCOUNTING_SECU_OBJ ) A
  LEFT JOIN
            ( SELECT ACCID,
                    PS2,
                    CASH_ACCID,
                    I_ID
               FROM TTRD_ACC_SECU ) C
         ON a.SECU_ACCT_ID = C.ACCID
  LEFT JOIN TTRD_ACC_SECU ACC_SECU
         ON C.PS2 = ACC_SECU.ACCID
  LEFT JOIN TTRD_ACC_CASH ACC_CASH
         ON C.CASH_ACCID = ACC_CASH.ACCID
  LEFT JOIN TTRD_INSTITUTION UNIT
         ON ACC_CASH.I_ID = UNIT.I_ID
  LEFT JOIN TTRD_INSTRUMENT INSTRUMENT
         ON a.I_CODE = INSTRUMENT.I_CODE
        AND a.A_TYPE = INSTRUMENT.A_TYPE
        AND a.M_TYPE = INSTRUMENT.M_TYPE
  LEFT JOIN TTRD_TRDGRP TRDGRP
         ON a.TRADE_GRP_ID = TRDGRP.GRPID ) T
WHERE T.A_TYPE != 'SPT_NWMPORT'
AND I_CODE != 'XQUANTINI'
AND ABS(T.SECU_REAL_CP+T.SECU_DUE_CP)+ ABS(t.SECU_AI+T.SECU_DUE_AI)+ ABS(T.SECU_CHG_FV)+ ABS
    (t.SECU_PRFT_FV+t.SECU_PRFT_IR+t.SECU_PRFT_TRD+t.SECU_PRFT_FEE) >0
UNION ALL
SELECT 'GLKJ' AS BKP_TYPE,
    'Cash'    AS SRC_TYPE,
    --映射表输入维度：内部证券账户类型
    '' AS SECU_ACCT_TYPE,
    DED_INFO.P_TYPE,
    --映射表输入维度：产品分类
    DED_INFO.P_ClASS,
    '' AS SUBJ_MATTER_P_CLASS,
    --映射表输入维度：承分销组合类型1 承分销 0非承分销
    '' AS GRP_TYPE,
    --映射表输入维度：发行方式
    '' AS BOND_TYPE,
    --映射表输出维度：币种7
    a.CURRENCY AS V_CURRENCY,
    ----映射表输出维度：记账机构Id
    UNIT.ORG_ID AS V_SUBJ_ORG_ID,
    --映射表输出维度：核心账号
    '' AS V_CORE_ACCT_CODE,
    A.OBJ_ID,
    A.TSK_ID,
    A.BEG_DATE,
    A.CASH_ACCT_ID     AS ACCT_ID,
    '-1'               AS SECU_ACCT_ID,
    A.CASH_ACCT_ID     AS CASH_ACCT_ID,
    A.EXT_CASH_ACCT_ID AS EXT_ACCT_ID,
    DED_INFO.I_CODE,
    DED_INFO.A_TYPE,
    DED_INFO.M_TYPE,
    ''            AS long_or_short,
    0             AS SECU_REAL_VOLUME,
    0             AS SECU_REAL_AMOUNT,
    0             AS SECU_DUE_AMOUNT,
    0             AS SECU_REAL_CP,
    0             AS SECU_DUE_CP,
    0             AS SECU_PRFT_FEE,
    0             AS SECU_AI,
    0             AS SECU_DUE_AI,
    0             AS SECU_AMRT_IR,
    0             AS SECU_PRFT_FV,
    0             AS SECU_CHG_FV,
    0             AS SECU_PRFT_IR,
    0             AS SECU_PRFT_TRD,
    A.REAL_AMOUNT AS CASH_REAL_AMOUNT,
    ''            AS SECU_OBJ_ID,
    A.OBJ_ID      AS CASH_OBJ_ID,
    ''            AS DUE_OBJ_ID
FROM ( SELECT *
       FROM TTRD_ACCOUNTING_CASH_OBJ_HIS
  UNION ALL
     SELECT *
       FROM TTRD_ACCOUNTING_CASH_OBJ ) A
LEFT JOIN VDED_INFO DED_INFO
 ON A.EXT_CASH_ACCT_ID = DED_INFO.EXT_CASH_ACCT_ID
AND A.CURRENCY = DED_INFO.CURRENCY
LEFT JOIN TTRD_ACC_CASH_EXT ACC_CASH_EXT
 ON A.EXT_CASH_ACCT_ID = ACC_CASH_EXT.ACCID
AND A.CURRENCY = ACC_CASH_EXT.CURRENCY
LEFT JOIN TTRD_INSTRUMENT INSTRUMENT
 ON A.EXT_CASH_ACCT_ID ||
    '_'||
        A.CURRENCY = INSTRUMENT.I_CODE
LEFT JOIN TTRD_INSTITUTION UNIT
 ON ACC_CASH_EXT.I_ID = UNIT.I_ID
WHERE A.REAL_AMOUNT <> 0




/

