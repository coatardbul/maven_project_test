create view VTRD_LIMIT_SELF_BSI as
  SELECT
        '' as PARAM_CODE      ,
        0  as P_VALUE
   FROM DUAL
/

