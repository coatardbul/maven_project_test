create PROCEDURE EXH_ADJUST_CASH(PI_ACCID        IN VARCHAR2,  -- 资金帐号
                                            PI_OCCUR_CASH   IN NUMBER,    -- 资金发生数
                                            PI_OCCUR_MARGIN IN NUMBER,    -- 保证金发生数
                                            PO_ERRCODE      OUT NUMBER,   -- 错误号
                                            PO_ERRINFO      OUT VARCHAR2  -- 错误信息
                                            ) AS
BEGIN
   PO_ERRCODE := 0;
   PO_ERRINFO := '';

   UPDATE TTRD_EXH_ACC_BALANCE_CASH_EXT
      SET RT_AMOUNT     = RT_AMOUNT + PI_OCCUR_CASH,
          RT_MARGIN     = RT_MARGIN + PI_OCCUR_MARGIN,
          RT_AVAAMOUNT  = RT_AVAAMOUNT + PI_OCCUR_CASH - PI_OCCUR_MARGIN,
          RT_UPDATETIME = CURRENT_DATE
   WHERE ACCID = PI_ACCID;
   IF SQL%ROWCOUNT < 1 THEN
      EXH_INSERT_CASH(TO_CHAR(CURRENT_DATE, 'YYYY-MM-DD'),
					PI_ACCID,
                      0,
                      0,
                      0,
                      0,
                      PI_OCCUR_CASH,
                      PI_OCCUR_MARGIN,
                      PI_OCCUR_CASH,
                      0,
					  0);
   END IF;

END;
/

