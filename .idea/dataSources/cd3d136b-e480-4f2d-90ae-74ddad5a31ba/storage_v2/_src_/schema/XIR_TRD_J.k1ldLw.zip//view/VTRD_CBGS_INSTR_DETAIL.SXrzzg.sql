create view VTRD_CBGS_INSTR_DETAIL as
  SELECT A.TXFLOWID  AS TXFLOWID, -- 交易流水标识
    A.INSTR_ID     AS INSTR_ID, --中债指令编号
    A.INSTR_ORIGIN AS INSTR_ORIGIN, --结算指令来源
    A.INSTR_STATUS AS INSTR_STATUS, --中债指令状态
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID
            THEN --Giv为本方托管账号
                (
                    CASE
                        WHEN (A.INSTR_ORIGIN='IO01'
                             OR A.INSTR_ORIGIN='IO00')
                        AND (A.INSTR_STATUS='IS03'
                             OR A.INSTR_STATUS='IS00'
                             OR A.INSTR_STATUS='IS05'
                             OR A.INSTR_STATUS='IS02')
                        THEN 'IC01'
                        ELSE A.INITIATOR_CONFIRM
                    END)
            ELSE (
                    CASE
                        WHEN (A.INSTR_ORIGIN='IO01'
                             OR A.INSTR_ORIGIN='IO00')
                        AND (A.INSTR_STATUS='IS03'
                             OR A.INSTR_STATUS='IS00'
                             OR A.INSTR_STATUS='IS05'
                             OR A.INSTR_STATUS='IS02')
                        THEN (
                                CASE
                                    WHEN A.INSTR_STATUS='IS00'
                                    THEN 'IC01'
                                    WHEN A.INSTR_STATUS='IS03'
                                    THEN 'IC02'
                                END)
                        ELSE A.CP_CONFIRM
                    END)
        END) AS INSTR_CONFIRM, --本方确认标识
    (
        CASE
            WHEN A.TAK_ACC_ID = A.ACCID
            THEN --Tak为本方托管账号
                (
                    CASE
                        WHEN (A.INSTR_ORIGIN='IO01'
                             OR A.INSTR_ORIGIN='IO00')
                        AND (A.INSTR_STATUS='IS03'
                             OR A.INSTR_STATUS='IS00'
                             OR A.INSTR_STATUS='IS05'
                             OR A.INSTR_STATUS='IS02')
                        THEN 'IC01'
                        ELSE A.INITIATOR_CONFIRM
                    END)
            ELSE (
                    CASE
                        WHEN (A.INSTR_ORIGIN='IO01'
                             OR A.INSTR_ORIGIN='IO00')
                        AND (A.INSTR_STATUS='IS03'
                             OR A.INSTR_STATUS='IS00'
                             OR A.INSTR_STATUS='IS05'
                             OR A.INSTR_STATUS='IS02')
                        THEN (
                                CASE
                                    WHEN A.INSTR_STATUS='IS00'
                                    THEN 'IC01'
                                    WHEN A.INSTR_STATUS='IS03'
                                    THEN 'IC02'
                                END)
                        ELSE A.CP_CONFIRM
                    END)
        END) AS PARTY_INSTR_CONFIRM, --对手方确认标识
    A.TXID   AS EXTORDID, --外汇交易中心外部成交编号
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN
                (SELECT MAP_VALUE
                   FROM VTRD_CBGS_SYS_CONVERT_MAP --判断买入卖出视图
                  WHERE MAP_ITEM = 'CBGS_INSTBIZTYPE_MAP'
                    AND MAP_KEY = A.BIZTYPE ||
                        '_SELFGIV') --现券卖出
            ELSE
                  (SELECT MAP_VALUE
                 FROM VTRD_CBGS_SYS_CONVERT_MAP --判断买入卖出视图
                WHERE MAP_ITEM = 'CBGS_INSTBIZTYPE_MAP'
                  AND MAP_KEY = A.BIZTYPE ||
                      '_SELFTAK') --现券买入
        END)  BIZTYPE, -- 业务类别
    A.ACCID   AS ZZDACCCODE, --  本方托管账号
    A.ACCNAME AS ZZDACCNAME, --  本方托管账号名称
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.TAK_ACC_ID --收券账户
            ELSE A.GIV_ACC_ID --付券账户
        END) PARTY_ZZDACCCODE, -- 对手方托管账号
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.TAK_ACC_NAME --收券账户名称
            ELSE A.GIV_ACC_NAME --付券账户名称
        END) PARTY_ZZDACCNAME, --对手方托管账户名称
    (
        CASE
            WHEN A.BIZTYPE = 'BT04' --债券远期结算日期和其他类别相反
            THEN A.DATE2
            WHEN A.BIZTYPE = 'BT00' --债券分销结算日期和其他类别相反
            THEN A.DATE2
            ELSE A.DATE1
        END) AS FSTSETDATE, --首期结算日期
    A.DATE1  AS INSTR_DATE, --指令日期
    (
        CASE
            WHEN A.BIZTYPE = 'BT04' --债券远期结算日期和其他类别相反
            THEN A.SETTLEMENT2
            WHEN A.BIZTYPE = 'BT00' --债券分销结算日期和其他类别相反
            THEN A.SETTLEMENT2
            ELSE A.SETTLEMENT1
        END)    FSTSETTYPE, --首期结算方式
    0        AS FSTNETAMOUNT, --首期净价结算金额（DOUBLE）
    ''       AS FSTNETAMOUNT_STR, --首期净价结算金额（STRING）
    0        AS FSTAIAMOUNT, --首期应计利息（DOUBLE）
    ''       AS FSTAIAMOUNT_STR, --首期应计利息（STRING）
    (
        CASE
            WHEN A.BIZTYPE = 'BT02'
            THEN A.AMOUNT1
            WHEN A.BIZTYPE = 'BT03'
            THEN A.AMOUNT1
            ELSE 0
        END) AS FSTAMOUNT, --首期全价结算金额（DOUBLE）
    (
        CASE
            WHEN A.BIZTYPE = 'BT02'
            THEN A.S_AMOUNT1
            WHEN A.BIZTYPE = 'BT03'
            THEN A.S_AMOUNT1
            ELSE ''
        END ) AS FSTAMOUNT_STR, --首期全价结算金额（STRING）
    (
        CASE
            WHEN A.BIZTYPE = 'BT01'
            THEN A.AMOUNT1
            WHEN A.BIZTYPE = 'BT04'
            THEN A.AMOUNT1
            ELSE 0
        END) AS ENDNETAMOUNT, --到期净价结算金额（DOUBLE）
    (
        CASE
            WHEN A.BIZTYPE = 'BT01'
            THEN A.S_AMOUNT1
            WHEN A.BIZTYPE = 'BT04'
            THEN A.S_AMOUNT1
            ELSE ''
        END) AS ENDNETAMOUNT_STR, --到期净价结算金额（STRING）
    (
        CASE
            WHEN A.BIZTYPE = 'BT01'
            THEN A.AMOUNT3
            WHEN A.BIZTYPE = 'BT04'
            THEN A.AMOUNT3
            ELSE 0
        END) AS ENDAIAMOUNT, --到期应计利息（DOUBLE）
    (
        CASE
            WHEN A.BIZTYPE = 'BT01'
            THEN A.S_AMOUNT3
            WHEN A.BIZTYPE = 'BT04'
            THEN A.S_AMOUNT3
            ELSE ''
        END) AS ENDAIAMOUNT_STR, --到期应计利息（STRING）
    (
        CASE
            WHEN A.BIZTYPE = 'BT00'
            THEN A.AMOUNT1
            WHEN A.BIZTYPE = 'BT01'
            THEN A.AMOUNT2
            WHEN A.BIZTYPE = 'BT02'
            THEN A.AMOUNT2
            WHEN A.BIZTYPE = 'BT03'
            THEN A.AMOUNT2
            WHEN A.BIZTYPE = 'BT04'
            THEN A.AMOUNT2
            WHEN A.BIZTYPE = 'BT05'
            THEN A.AMOUNT1
            WHEN A.BIZTYPE = 'BT06'
            THEN A.AMOUNT1
            ELSE 0
        END) AS ENDAMOUNT, --到期全价结算金额（DOUBLE）
    (
        CASE
            WHEN A.BIZTYPE = 'BT00'
            THEN A.S_AMOUNT1
            WHEN A.BIZTYPE = 'BT01'
            THEN A.S_AMOUNT2
            WHEN A.BIZTYPE = 'BT02'
            THEN A.S_AMOUNT2
            WHEN A.BIZTYPE = 'BT03'
            THEN A.S_AMOUNT2
            WHEN A.BIZTYPE = 'BT04'
            THEN A.S_AMOUNT2
            WHEN A.BIZTYPE = 'BT05'
            THEN A.S_AMOUNT1
            WHEN A.BIZTYPE = 'BT06'
            THEN A.S_AMOUNT1
            ELSE ''
        END) AS ENDAMOUNT_STR, --到期全价结算金额（STRING）
    (
        CASE
            WHEN A.BIZTYPE = 'BT04' --债券远期结算日期和其他类别相反
            THEN A.DATE1
            WHEN A.BIZTYPE = 'BT00' --债券分销结算日期和其他类别相反
            THEN A.DATE1
            ELSE A.DATE2
        END) AS ENDSETDATE, --到期结算日期
    (
        CASE
            WHEN A.BIZTYPE = 'BT04' --债券远期结算日期和其他类别相反
            THEN A.SETTLEMENT1
            WHEN A.BIZTYPE = 'BT00' --债券分销结算日期和其他类别相反
            THEN A.SETTLEMENT1
            ELSE A.SETTLEMENT2
        END)  ENDSETTYPE, -- 到期结算方式
    A.RATE    AS RATE, --回购利率（DOUBLE）
    A.S_RATE  AS RATE_STR, --回购利率（STRING）
    A.I_CODE1    I_CODE, --债券代码
    A.I_NAME1    I_NAME, --债券名称
    (SELECT SUM(W.TRDFV)
       FROM TTRD_CBGS_BOND W
      WHERE W.CID=A.CID
        AND FLAG=1)*10000    ORDMONEY, --债券面额合计(DOUBLE类型)
    A.S_TRDFV1               ORDMONEY_STR, --债券面额合计(STRING类型)
    0                     AS RESERVE, -- 担保方
    A.SG_TYPE1               RESERVETYPE, --担保方式
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_TYPE1
            ELSE A.SG_TYPE2
        END) AS SG_TYPE, --本方结算保证方式
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_I_CODE1
            ELSE A.SG_I_CODE2
        END) AS SG_I_CODE, --本方结算保证债券代码
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_ISIN1
            ELSE A.SG_ISIN2
        END) AS SG_ISIN, --本方结算保证ISIN编码
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_I_NAME1
            ELSE A.SG_I_NAME2
        END) AS SG_I_NAME, --本方结算保证债券简称
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_TRDFV1*10000
            ELSE A.SG_TRDFV2*10000
        END) AS SG_TRDFV, --本方结算保证券面总额(DOUBLE)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.S_SG_TRDFV1
            ELSE A.S_SG_TRDFV2
        END) AS SG_TRDFV_STR, --本方结算保证券面总额(STRING)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_RATE1
            ELSE A.SG_RATE2
        END) AS SG_RATE, --本方结算保证债券质押率(DOUBLE)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.S_SG_RATE1
            ELSE A.S_SG_RATE2
        END) AS SG_RATE_STR, --本方结算保证债券质押率(STRING)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_CASH1
            ELSE A.SG_CASH2
        END) AS SG_CASH, --本方结算保证金保管地
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_AMOUNT1
            ELSE A.SG_AMOUNT2
        END) AS SG_AMOUNT, --本方结算保证金金额(DOUBLE)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.S_SG_AMOUNT1
            ELSE A.S_SG_AMOUNT2
        END) AS SG_AMOUNT_STR, --本方结算保证金金额(STRING)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_TYPE2
            ELSE A.SG_TYPE1
        END) AS CP_SG_TYPE, --对手方结算保证方式
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_I_CODE2
            ELSE A.SG_I_CODE1
        END) AS CP_SG_I_CODE, --对手方结算保证债券代码
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_ISIN2
            ELSE A.SG_ISIN1
        END) AS CP_SG_ISIN, --对手方结算保证ISIN编码
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_I_NAME2
            ELSE A.SG_I_NAME1
        END) AS CP_SG_I_NAME, --对手方结算保证债券简称
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_TRDFV2*10000
            ELSE A.SG_TRDFV1*10000
        END) AS CP_SG_TRDFV, --对手方结算保证券面总额(DOUBLE)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.S_SG_TRDFV2
            ELSE A.S_SG_TRDFV1
        END) AS CP_SG_TRDFV_STR, --对手方结算保证券面总额(STRING)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_RATE2
            ELSE A.SG_RATE1
        END) AS CP_SG_RATE, --对手方结算保证债券质押率(DOUBLE)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.S_SG_RATE2
            ELSE A.S_SG_RATE1
        END) AS CP_SG_RATE_STR, --对手方结算保证债券质押率(STRING)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_CASH2
            ELSE A.SG_CASH1
        END) AS CP_SG_CASH, --对手方结算保证金保管地
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_AMOUNT2
            ELSE A.SG_AMOUNT1
        END) AS CP_SG_AMOUNT, --对手方结算保证金金额(DOUBLE)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.S_SG_AMOUNT2
            ELSE A.S_SG_AMOUNT1
        END)    AS CP_SG_AMOUNT_STR, --对手方结算保证金金额(STRING)
    A.CTRCT_ID1 AS CTRCT_ID1, --合同号1
    A.CTRCT_ID2 AS CTRCT_ID2, --合同号2
    A.CT_NAME,----转托管申请人名称
    A.CT_IN_ACC_ID,---在转入方债券账号
    A.OPERATOR2 AS OPERATOR,----经办人
    A.CHECKER2  AS CHECKER,----复核人
    A.UPDATETIME --更新日期
FROM TTRD_CBGS_SETTLEBIZ_DETAIL A -- 查询详情返回表
WHERE A.REQUEST_CODE = 'BJ0300'
AND A.BIZTYPE --通用结算指令返回
    IN ('BT01', --现券
        'BT02', --质押式回购
        'BT05', --债券借贷
        'BT06', --质押券置换
        'BT00', --普通分销
        'BT11', --转托管
        'BT03', --买断式回购
        'BT04', --债券远期
        'BT10', --投资人选择提前赎回
        'BT07', --BEPS质押
        'BT08', --BEPS解押
        'BT09' --BEPS质押券置换
        )




/

