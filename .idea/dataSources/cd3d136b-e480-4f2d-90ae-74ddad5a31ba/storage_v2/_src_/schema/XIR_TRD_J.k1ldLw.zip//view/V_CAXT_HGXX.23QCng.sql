create view V_CAXT_HGXX as
  SELECT A.SYSORDID,
    A.I_CODE,
    A.ORDDATE,
    A.SETDAYS,
    E.ACCID,
    AC.ACCNAME,										--证券账户，后面改为产品名称
    DECODE(I.STATE,'1','待处理','699','已到期','存续期') AS DQZT,--到期状态
    DECODE(A.M_TYPE,'X_CNBD',DECODE(B.HOST_MARKET,'X_CNBD_ZZD','中债登','X_CNBD_QSS','清算所'),'XSHE',
    '深交所','XSHG','上交所')                                                       AS HOST_MARKET, --交易场所
    '质押式'                                                                         AS HGLX,--回购类型
    DECODE(A.TRDTYPE,'0123100','融券','0123101','融资','0150100','融券','0150101','融资') AS HGFX,--交易方向
    B.REPO_TRADE_VARIETY                                                          AS HGPZ,--回购品种
    TO_DATE(B.END_DATE,'yyyy-mm-dd')-TO_DATE(B.START_DATE,'yyyy-mm-dd')+A.SETDAYS||
    'D'                                                                AS ZKTS,--占款天数
    TO_CHAR(TO_DATE(B.START_DATE,'yyyy-mm-dd')-A.SETDAYS,'yyyy-mm-dd') AS QCRQ,--首期清算日
    B.END_DATE                                                         AS QMRQ,--到期清算日
    TO_CHAR(B.COUPON*100,'fm9999.0000')                                AS COUPON,--收益率%
    TO_CHAR(ROUND(B.FST_SET_AMOUNT/10000,4),'fm99999999999999.0000')    AS QCJE,--期初金额(万)
    TO_CHAR(ROUND(B.MTR_SET_AMOUNT/10000,4),'fm99999999999999.0000')    AS QMJE,--期末金额(万)
    D.I_NAME--交易对手名称
FROM TTRD_OTC_TRADE A
LEFT JOIN TTRD_ACC_SECU E
 ON A.SECU_ACCID=E.ACCID
LEFT JOIN TTRD_CASHLB B
 ON A.I_CODE=B.I_CODE
AND A.A_TYPE=B.A_TYPE
AND A.M_TYPE=B.M_TYPE
LEFT JOIN TTRD_INSTITUTION D
 ON A.PARTYID=D.I_ID
LEFT JOIN
    (SELECT *
       FROM TTRD_SET_INSTRUCTION
      WHERE TRD_TYPE IN('0123300',
                        '0123301',
                        '0150300',
                        '0150301')) I
 ON A.I_CODE=I.H_I_CODE
AND A.A_TYPE=I.H_A_TYPE
AND A.M_TYPE=I.H_M_TYPE
LEFT JOIN TTRD_ACC_CASH AC
 ON E.CASH_ACCID = AC.ACCID
LEFT JOIN TTRD_WMPS_UNIT U
 ON AC.PC1 = U.UNIT_ID
LEFT JOIN TTRD_WMPS_DEFINE WD
 ON U.UNIT_ID=WD.UNIT_ID
WHERE A.ORDSTATUS='4'
AND A.TRDTYPE IN ('0123100',
                  '0123101',
                  '0150100',
                  '0150101')
ORDER BY B.END_DATE
/

