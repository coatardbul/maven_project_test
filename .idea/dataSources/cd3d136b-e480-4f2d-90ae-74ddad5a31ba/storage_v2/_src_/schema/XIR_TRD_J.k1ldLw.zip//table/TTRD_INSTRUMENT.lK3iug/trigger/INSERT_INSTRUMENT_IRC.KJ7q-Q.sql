create trigger INSERT_INSTRUMENT_IRC
  before insert
  on TTRD_INSTRUMENT
  for each row
  DECLARE
  U_I_CODE2     Varchar2(30);

BEGIN
 IF :new.A_TYPE='SWP_IR' OR :new.a_Type='FWD_IR' THEN
     U_I_CODE2 := :new.U_I_CODE;
    IF LOCATE('FR007',U_I_CODE2)=1 THEN

       select 'SWAP_FR007' INTO :new.FWD_IRC from dual;
       select 'SWAP_FR007' INTO :new.DIS_IRC from dual;

      ELSIF LOCATE('DEPO',U_I_CODE2)=1 THEN

          select 'SWAP_DEPO_F01Y' INTO :new.FWD_IRC from dual;
          select 'SWAP_DEPO_F01Y' INTO :new.DIS_IRC from dual;

        ELSIF LOCATE('SHIBOR-1D',U_I_CODE2)=1 THEN

              select 'SWAP_SHIBOR-1D' INTO :new.FWD_IRC from dual;
              select 'SWAP_SHIBOR-1D' INTO :new.DIS_IRC from dual;

          ELSE
              select 'SWAP_SHIBOR-3M' INTO :new.FWD_IRC from dual;
              select 'SWAP_SHIBOR-3M' INTO :new.DIS_IRC from dual;
          END IF;
    ELSE
      select 'INTERBANK_FIXED_GOVBOND' INTO :new.FWD_IRC from dual;
      select 'INTERBANK_FIXED_GOVBOND' INTO :new.DIS_IRC from dual;
   END IF;
end;















/

