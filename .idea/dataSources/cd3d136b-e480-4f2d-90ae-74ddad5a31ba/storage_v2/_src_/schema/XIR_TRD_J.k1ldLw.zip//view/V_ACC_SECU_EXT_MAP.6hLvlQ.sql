create view V_ACC_SECU_EXT_MAP as
  SELECT secu_accid,
    CASE
        WHEN t.host_market1='X_CNBD_ZZD'
        THEN ext_accid1
        WHEN t.host_market2='X_CNBD_ZZD'
        THEN ext_accid2
        ELSE ''
    END zzd_accid,
    CASE
        WHEN t.host_market1='X_CNBD_ZZD'
        THEN exhacc1
        WHEN t.host_market2='X_CNBD_ZZD'
        THEN exhacc2
        ELSE ''
    END zzd_exhacc,
    CASE
        WHEN t.host_market1='X_CNBD_QSS'
        THEN ext_accid1
        WHEN t.host_market2='X_CNBD_QSS'
        THEN ext_accid2
        ELSE ''
    END qss_accid,
    CASE
        WHEN t.host_market1='X_CNBD_QSS'
        THEN exhacc1
        WHEN t.host_market2='X_CNBD_QSS'
        THEN exhacc2
        ELSE ''
    END qss_exhacc
FROM (SELECT m.secu_accid,
            lead(t.accid, 0, '') over(partition BY m.secu_accid ORDER BY t.host_market) AS
                                                                                         ext_accid1,
            lead(t.exhacc, 0, '') over(partition BY m.secu_accid ORDER BY t.host_market) AS exhacc1
            ,
            lead(t.host_market, 0, '') over(partition BY m.secu_accid ORDER BY t.host_market) AS
            host_market1,
            lead(t.accid, 1, '') over(partition BY m.secu_accid ORDER BY t.host_market) AS
                                                                                         ext_accid2,
            lead(t.exhacc, 1, '') over(partition BY m.secu_accid ORDER BY t.host_market) AS exhacc2
            ,
            lead(t.host_market, 1, '') over(partition BY m.secu_accid ORDER BY t.host_market) AS
                                                                                   host_market2,
            MIN(t.accid) over(partition BY m.secu_accid ORDER BY t.host_market) AS flag
       FROM ttrd_acc_secu_ext t,
            ttrd_acc_secu_ext_map m
      WHERE t.accid=m.secu_ext_accid
        AND t.host_market!='X_VIRTUAL')t
WHERE t.ext_accid1 = t.flag
    --查询内部证券账号所关联的中债登账户及清算所账户 数据存储形式为通过关联表关联 本视图将两个外部账号同一行输出


/

