create view VTRD_LIMIT_SECU_BLC_INFO_SC as
  SELECT 2 AS SRC_TYPE,
       A.OBJ_ID AS SRC_ID,
       5 AS OCCUPY_OBJ_TYPE,
       NULL AS ORD_ID,
       -30 AS OPR_STATE,
       NULL AS ORDSTATUS,
       A.OBJ_ID AS INTORDID,
       A.TRADE_GRP_ID,
       A.I_CODE,
       A.A_TYPE,
       A.M_TYPE,
       A.EXT_SECU_ACCT_ID,
       A.SECU_ACCT_ID,
       A.EXT_SECU_ACCT_ID AS EXT_CASH_ACCT_ID,
       AC.CASH_ACCID AS CASH_ACCT_ID,
       NULL AS ORD_TOTAL_AMOUNT,
       NULL AS ORD_CANCEL_AMOUNT,
       NULL AS ORD_REMAIN_AMOUNT,
       CASE
         WHEN (A.BLC_TYPE = 211 OR A.BLC_TYPE = 212) THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_ZY,
       CASE
         WHEN A.BLC_TYPE = 221 THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_RR,
       CASE
         WHEN A.BLC_TYPE = 222 THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_RC,
       CASE
         WHEN A.BLC_TYPE = 232 THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_ZC,
       CASE
         WHEN A.BLC_TYPE = 251 THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_BZQZR,
       CASE
         WHEN A.BLC_TYPE = 252 THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_PTQZC,
       A.BLC_TYPE,
       A.VOLUME AS BLC_SECU_VOLUME,
       CASE
         WHEN A.SET_DATE = A.BEG_DATE THEN
          0
         ELSE
          1
       END AS SETDAYS,
       NULL AS INST_ID,
       CASE
         WHEN (A.BLC_TYPE = 221 AND A1.A_TYPE = 'FWD_BD') THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_HGRR,
       CASE
         WHEN (A.BLC_TYPE = 222 AND A1.A_TYPE = 'FWD_BD') THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_HGRC,
       CASE
         WHEN (A.BLC_TYPE = 221 AND A1.A_TYPE = 'LB_BD') THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_JDRR,
       CASE
         WHEN (A.BLC_TYPE = 222 AND A1.A_TYPE = 'LB_BD') THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_JDRC,
       CASE
         WHEN (A.BLC_TYPE = 211 OR A.BLC_TYPE = 212) THEN
          ABS(A.VOLUME)
         ELSE
          0
       END AS BLC_SECU_VOLUME_ABSZY,
       CASE
         WHEN A.VOLUME > 0 THEN
          'L'
         ELSE
          'S'
       END AS EXTRA_DIM,
       0 AS MOCK_TYPE
  FROM TTRD_BLC_SECU_OBJ A
  LEFT JOIN TTRD_BLC_SECU_OBJ A1
    ON A.P_OBJ_ID = A1.OBJ_ID
   AND A1.SET_DATE = '1900-01-01'
  LEFT JOIN TTRD_ACC_SECU AC
    ON A.SECU_ACCT_ID = AC.ACCID
 WHERE A.SET_DATE = '1900-01-01'
   AND A.VOLUME <> 0
   AND A.BLC_TYPE <> 231

UNION ALL
SELECT 1 AS SRC_TYPE,
       A.SECU_INST_ID || '' AS SRC_ID,
       CASE
         WHEN B.STATE != 99999 THEN
          4
         WHEN C.ORDSTATUS < 0 THEN
          1
         WHEN C.ORD_ID IS NOT NULL THEN
          2
         ELSE
          3
       END AS OCCUPY_OBJ_TYPE,
       C.ORD_ID AS ORD_ID,
       A.OPR_STATE,
       C.ORDSTATUS,
       C.INTORDID,
       A.TRADE_GRP_ID,
       A.I_CODE,
       A.A_TYPE,
       A.M_TYPE,
       A.EXT_SECU_ACCT_ID,
       A.SECU_ACCT_ID,
       A.EXT_SECU_ACCT_ID AS EXT_CASH_ACCT_ID,
       AC.CASH_ACCID AS CASH_ACCT_ID,
       CASE
         WHEN C.ORDSTATUS < 0 THEN
          O.TOTAL_AMOUNT
         ELSE
          NULL
       END AS ORD_TOTAL_AMOUNT,
       CASE
         WHEN C.ORDSTATUS < 0 THEN
          O.CANCEL_AMOUNT
         ELSE
          NULL
       END AS ORD_CANCEL_AMOUNT,
       CASE
         WHEN C.ORDSTATUS < 0 THEN
          O.REMAIN_AMOUNT4CONFIRM
         ELSE
          NULL
       END AS ORD_REMAIN_AMOUNT,
       CASE
         WHEN (A.BIZ_TYPE = '21001' OR A.BIZ_TYPE = '21101' OR
              A.BIZ_TYPE = '21102' OR A.BIZ_TYPE = '21103' OR
              A.BIZ_TYPE = '21201' OR A.BIZ_TYPE = '21202' OR
              A.BIZ_TYPE = '21203' OR A.BIZ_TYPE = '29021' OR
              A.BIZ_TYPE = '29022' OR A.BIZ_TYPE = '29031' OR
              A.BIZ_TYPE = '29032' OR A.BIZ_TYPE = '29041' OR
              A.BIZ_TYPE = '29042' OR A.BIZ_TYPE = '21004' OR
              A.BIZ_TYPE = '21104' OR A.BIZ_TYPE = '21204' OR
              A.BIZ_TYPE = '21108' OR A.BIZ_TYPE = '21208' OR
              A.BIZ_TYPE = '21112' OR A.BIZ_TYPE = '21212') THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_ZY,
       CASE
         WHEN A.BIZ_TYPE = '22101' THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_RR,
       CASE
         WHEN A.BIZ_TYPE = '22201' THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_RC,
       CASE
         WHEN A.BIZ_TYPE = '23201' THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_ZC,
       CASE
         WHEN A.BIZ_TYPE = '25101' THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_BZQZR,
       CASE
         WHEN A.BIZ_TYPE = '25201' THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_PTQZC,
       CASE
         WHEN A.BIZ_TYPE = '22101' THEN
          221
         WHEN A.BIZ_TYPE = '22201' THEN
          222
         WHEN A.BIZ_TYPE = '23101' THEN
          231
         WHEN A.BIZ_TYPE = '23201' THEN
          232
         WHEN A.BIZ_TYPE = '25101' THEN
          251
         WHEN A.BIZ_TYPE = '25201' THEN
          252
         WHEN A.DIRECTION = 'IN' THEN
          211
         ELSE
          212
       END AS BLC_TYPE,
       A.VOLUME AS BLC_SECU_VOLUME,
       CASE
         WHEN A.SET_DATE = (SELECT CURR_DATE FROM TTRD_CURRDATE) THEN
          0
         ELSE
          1
       END AS SETDAYS,
       B.INST_ID,
       CASE
         WHEN (A.BIZ_TYPE = '22101' AND
              (D.A_TYPE = '0220' OR D.A_TYPE = '1020')) THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_HGRR,
       CASE
         WHEN (A.BIZ_TYPE = '22201' AND
              (D.A_TYPE = '0220' OR D.A_TYPE = '1020')) THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_HGRC,
       CASE
         WHEN (A.BIZ_TYPE = '22101' AND B.H_A_TYPE = 'LB_BD') THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_JDRR,
       CASE
         WHEN (A.BIZ_TYPE = '22201' AND B.H_A_TYPE = 'LB_BD') THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_JDRC,
       CASE
         WHEN (A.BIZ_TYPE = '21001' OR A.BIZ_TYPE = '21101' OR
              A.BIZ_TYPE = '21102' OR A.BIZ_TYPE = '21103' OR
              A.BIZ_TYPE = '21201' OR A.BIZ_TYPE = '21202' OR
              A.BIZ_TYPE = '21203' OR A.BIZ_TYPE = '29021' OR
              A.BIZ_TYPE = '29022' OR A.BIZ_TYPE = '29031' OR
              A.BIZ_TYPE = '29032' OR A.BIZ_TYPE = '29041' OR
              A.BIZ_TYPE = '29042' OR A.BIZ_TYPE = '21004' OR
              A.BIZ_TYPE = '21104' OR A.BIZ_TYPE = '21204' OR
              A.BIZ_TYPE = '21108' OR A.BIZ_TYPE = '21208' OR
              A.BIZ_TYPE = '21112' OR A.BIZ_TYPE = '21212') THEN
          ABS(A.VOLUME)
         ELSE
          0
       END AS BLC_SECU_VOLUME_ABSZY,
       CASE
         WHEN A.DIRECTION = 'IN' THEN
          'L'
         ELSE
          'S'
       END AS EXTRA_DIM,
       0 AS MOCK_TYPE
  FROM TTRD_SET_INSTRUCTION_SECU A
 INNER JOIN TTRD_SET_INSTRUCTION B
    ON A.INST_ID = B.INST_ID
   AND A.OPR_STATE = -20
   AND B.STATE = 99999
   AND A.BIZ_TYPE <> '23101'
   AND A.BIZ_TYPE != '99001'
  LEFT JOIN TTRD_OTC_TRADE C
    ON B.TRADE_ID = C.INTORDID
  LEFT JOIN TTRD_OTC_ORDER O
    ON C.ORD_ID = O.ORD_ID
  LEFT JOIN TTRD_ACC_SECU AC
    ON A.SECU_ACCT_ID = AC.ACCID
  LEFT JOIN TTRD_INSTRUMENT D
    ON B.H_I_CODE = D.I_CODE
   AND B.H_A_TYPE = D.A_TYPE
   AND B.H_M_TYPE = D.M_TYPE
 WHERE A.A_TYPE <> 'SPT_DED'
   AND (A.CANCEL_FLAG = 0 OR A.CANCEL_FLAG IS NULL)
   AND A.BIZ_TYPE <> '26101'
UNION ALL
-- 通过L指令找到对应的F指令
SELECT 1 AS SRC_TYPE,
       A.SECU_INST_ID || '' AS SRC_ID,
       CASE
         WHEN B.STATE != 99999 THEN
          4
         WHEN C.ORDSTATUS < 0 THEN
          1
         WHEN C.ORD_ID IS NOT NULL THEN
          2
         ELSE
          3
       END AS OCCUPY_OBJ_TYPE,
       C.ORD_ID AS ORD_ID,
       A.OPR_STATE,
       C.ORDSTATUS,
       C.INTORDID,
       A.TRADE_GRP_ID,
       A.I_CODE,
       A.A_TYPE,
       A.M_TYPE,
       A.EXT_SECU_ACCT_ID,
       A.SECU_ACCT_ID,
       A.EXT_SECU_ACCT_ID AS EXT_CASH_ACCT_ID,
       AC.CASH_ACCID AS CASH_ACCT_ID,
       CASE
         WHEN C.ORDSTATUS < 0 THEN
          O.TOTAL_AMOUNT
         ELSE
          NULL
       END AS ORD_TOTAL_AMOUNT,
       CASE
         WHEN C.ORDSTATUS < 0 THEN
          O.CANCEL_AMOUNT
         ELSE
          NULL
       END AS ORD_CANCEL_AMOUNT,
       NULL AS ORD_REMAIN_AMOUNT,
       CASE
         WHEN (A.BIZ_TYPE = '21001' OR A.BIZ_TYPE = '21101' OR
              A.BIZ_TYPE = '21102' OR A.BIZ_TYPE = '21103' OR
              A.BIZ_TYPE = '21201' OR A.BIZ_TYPE = '21202' OR
              A.BIZ_TYPE = '21203' OR A.BIZ_TYPE = '29021' OR
              A.BIZ_TYPE = '29022' OR A.BIZ_TYPE = '29031' OR
              A.BIZ_TYPE = '29032' OR A.BIZ_TYPE = '29041' OR
              A.BIZ_TYPE = '29042' OR A.BIZ_TYPE = '21004' OR
              A.BIZ_TYPE = '21104' OR A.BIZ_TYPE = '21204' OR
              A.BIZ_TYPE = '21108' OR A.BIZ_TYPE = '21208' OR
              A.BIZ_TYPE = '21112' OR A.BIZ_TYPE = '21212') THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_ZY,
       CASE
         WHEN A.BIZ_TYPE = '22101' THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_RR,
       CASE
         WHEN A.BIZ_TYPE = '22201' THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_RC,
       CASE
         WHEN A.BIZ_TYPE = '23201' THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_ZC,
       CASE
         WHEN A.BIZ_TYPE = '25101' THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_BZQZR,
       CASE
         WHEN A.BIZ_TYPE = '25201' THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_PTQZC,
       CASE
         WHEN A.BIZ_TYPE = '22101' THEN
          221
         WHEN A.BIZ_TYPE = '22201' THEN
          222
         WHEN A.BIZ_TYPE = '23101' THEN
          231
         WHEN A.BIZ_TYPE = '23201' THEN
          232
         WHEN A.BIZ_TYPE = '25101' THEN
          251
         WHEN A.BIZ_TYPE = '25201' THEN
          252
         WHEN A.DIRECTION = 'IN' THEN
          211
         ELSE
          212
       END AS BLC_TYPE,
       A.VOLUME AS BLC_SECU_VOLUME,
       CASE
         WHEN A.SET_DATE = (SELECT CURR_DATE FROM TTRD_CURRDATE) THEN
          0
         ELSE
          1
       END AS SETDAYS,
       B.INST_ID,
       CASE
         WHEN (A.BIZ_TYPE = '22101' AND
              (D.A_TYPE = '0220' OR D.A_TYPE = '1020')) THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_HGRR,
       CASE
         WHEN (A.BIZ_TYPE = '22201' AND
              (D.A_TYPE = '0220' OR D.A_TYPE = '1020')) THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_HGRC,
       CASE
         WHEN (A.BIZ_TYPE = '22101' AND B.H_A_TYPE = 'LB_BD') THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_JDRR,
       CASE
         WHEN (A.BIZ_TYPE = '22201' AND B.H_A_TYPE = 'LB_BD') THEN
          A.VOLUME
         ELSE
          0
       END AS BLC_SECU_VOLUME_JDRC,
       CASE
         WHEN (A.BIZ_TYPE = '21001' OR A.BIZ_TYPE = '21101' OR
              A.BIZ_TYPE = '21102' OR A.BIZ_TYPE = '21103' OR
              A.BIZ_TYPE = '21201' OR A.BIZ_TYPE = '21202' OR
              A.BIZ_TYPE = '21203' OR A.BIZ_TYPE = '29021' OR
              A.BIZ_TYPE = '29022' OR A.BIZ_TYPE = '29031' OR
              A.BIZ_TYPE = '29032' OR A.BIZ_TYPE = '29041' OR
              A.BIZ_TYPE = '29042' OR A.BIZ_TYPE = '21004' OR
              A.BIZ_TYPE = '21104' OR A.BIZ_TYPE = '21204' OR
              A.BIZ_TYPE = '21108' OR A.BIZ_TYPE = '21208' OR
              A.BIZ_TYPE = '21112' OR A.BIZ_TYPE = '21212') THEN
          ABS(A.VOLUME)
         ELSE
          0
       END AS BLC_SECU_VOLUME_ABSZY,
       CASE
         WHEN A.DIRECTION = 'IN' THEN
          'L'
         ELSE
          'S'
       END AS EXTRA_DIM,
       0 AS MOCK_TYPE
  FROM TTRD_SET_INSTRUCTION_SECU A
 INNER JOIN TTRD_SET_INSTRUCTION B
    ON A.INST_ID = B.INST_ID
      --AND A.OPR_STATE = -20
   AND B.STATE = 99999
   AND A.BIZ_TYPE <> '23101'
   AND A.BIZ_TYPE <> '23201'
   AND A.BIZ_TYPE <> '24101'
   AND A.BIZ_TYPE <> '24201'
   AND A.BIZ_TYPE <> '22201'
   AND A.BIZ_TYPE <> '22101'
   AND A.BIZ_TYPE != '99001'
  LEFT JOIN TTRD_SET_INSTRUCTION B1
    ON B1.DUE_OBJ_KEY = B.DUE_OBJ_KEY
   AND B1.DUE_ORDER = 'L'
   AND B.DUE_ORDER = 'F'
 INNER JOIN TTRD_SET_INSTRUCTION_SECU A1
    ON A1.INST_ID = B1.INST_ID
      --AND A1.OPR_STATE = -20
   AND B1.STATE = 99999
   AND A1.BIZ_TYPE <> '23101'
   AND A1.BIZ_TYPE <> '23201'
   AND A1.BIZ_TYPE <> '24101'
   AND A1.BIZ_TYPE <> '24201'
   AND A1.BIZ_TYPE <> '22201'
   AND A1.BIZ_TYPE <> '22101'
   AND A1.BIZ_TYPE != '99001'
  LEFT JOIN TTRD_OTC_TRADE C
    ON B.TRADE_ID = C.INTORDID
  LEFT JOIN TTRD_OTC_ORDER O
    ON C.ORD_ID = O.ORD_ID
  LEFT JOIN TTRD_ACC_SECU AC
    ON A.SECU_ACCT_ID = AC.ACCID
  LEFT JOIN TTRD_INSTRUMENT D
    ON B.H_I_CODE = D.I_CODE
   AND B.H_A_TYPE = D.A_TYPE
   AND B.H_M_TYPE = D.M_TYPE
 WHERE A.A_TYPE <> 'SPT_DED'
   AND (A.CANCEL_FLAG = 0 OR A.CANCEL_FLAG IS NULL)
   AND A.OPR_STATE = -30
   AND (A1.OPR_STATE IS NULL OR A1.OPR_STATE <> -30)
   AND A.BIZ_TYPE <> '26101'
--AND (C.ORDSTATUS < 0 OR C.ORD_ID IS NULL)
UNION ALL
SELECT M.SRC_TYPE,
       M.SRC_ID,
       M.OCCUPY_OBJ_TYPE,
       M.ORD_ID,
       M.OPR_STATE,
       M.ORDSTATUS,
       M.INTORDID,
       M.TRADE_GRP_ID,
       M.I_CODE,
       M.A_TYPE,
       M.M_TYPE,
       M.EXT_SECU_ACCT_ID,
       M.SECU_ACCT_ID,
       M.EXT_CASH_ACCT_ID,
       M.CASH_ACCT_ID,
       M.ORD_TOTAL_AMOUNT,
       M.ORD_CANCEL_AMOUNT,
       M.ORD_REMAIN_AMOUNT,
       M.                      BLC_SECU_VOLUME_ZY,
       M.BLC_SECU_VOLUME_RR,
       M.BLC_SECU_VOLUME_RC,
       M.BLC_SECU_VOLUME_ZC,
       M.BLC_SECU_VOLUME_BZQZR,
       M.BLC_SECU_VOLUME_PTQZC,
       M.BLC_TYPE,
       M.BLC_SECU_VOLUME,
       M.SETDAYS,
       M.INST_ID,
       M.BLC_SECU_VOLUME_HGRR,
       M.BLC_SECU_VOLUME_HGRC,
       M.BLC_SECU_VOLUME_JDRR,
       M.BLC_SECU_VOLUME_JDRC,
       M.BLC_SECU_VOLUME_ABSZY,
       M.EXTRA_DIM,
       1                       AS MOCK_TYPE
  FROM VTRD_LIMIT_MOCK_INFO M
 WHERE M.OPR_STATE = -20
/

