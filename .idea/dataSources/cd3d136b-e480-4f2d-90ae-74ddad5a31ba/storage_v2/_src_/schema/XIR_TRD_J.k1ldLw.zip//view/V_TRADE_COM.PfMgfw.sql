create view V_TRADE_COM as
  SELECT R."TPRT_CODE",
    R."ACC_NO",
    R."ACC_NAME",
    R."SECU_NAME",
    R."TRDDATE",
    R."BIZ_TYPE",
    R."CP_ACC_NO",
    R."CP_SECU_NAME",
    R."I_CODE",
    R."I_NAME",
    R."PARTY",
    R."PARTY_BANK_ACC_NO",
    R."ORDCOUNT",
    R."ORDPRICE",
    R."ORDAMOUNT",
    R."BND_SETTYPE",
    R."BND_PRICE",
    R."BND_AI",
    R."FST_DATE",
    R."FST_AMOUNT",
    R."LST_DATE",
    R."LST_AMOUNT",
    R."RATE",
    R."DAY_COUNT",
    R."PAY_COUNT"
FROM BSB_TRADE_COM R
WHERE (
        R.TPRT_CODE, R.TRDDATE, R.ORDAMOUNT) IN
    ( SELECT P.TPRT_NAME,
            T.TRDDATE,
            T.ORDAMOUNT
       FROM BSB_WLTH_INFO_COM P
  LEFT JOIN BSB_TRADE_COM T
         ON P.START_DATE = T.TRDDATE
        AND P.ACC_NO = T.ACC_NO
      WHERE T.BIZ_TYPE = '拆出')




/

