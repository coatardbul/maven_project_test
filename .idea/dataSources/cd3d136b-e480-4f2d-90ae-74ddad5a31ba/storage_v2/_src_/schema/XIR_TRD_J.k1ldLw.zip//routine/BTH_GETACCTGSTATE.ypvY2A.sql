create FUNCTION             "BTH_GETACCTGSTATE"(theory_date IN VARCHAR2,
                                             real_date   IN VARCHAR2,
                                             hisdate     IN VARCHAR2)
	RETURN NUMBER IS
	BEGIN
		IF real_date IS NULL AND theory_date IS NULL THEN
			RETURN 0;
		END IF;

		IF real_date IS NULL AND theory_date IS NOT NULL
		THEN
			IF hisdate > theory_date
			THEN
				RETURN 103;
			ELSE
				RETURN 0;
			END IF;
		END IF;

		IF theory_date IS NULL AND real_date IS NOT NULL
		THEN
			IF hisdate > real_date
			THEN
				RETURN 106;
			ELSE
				RETURN 0;
			END IF;
		END IF;

		IF theory_date = real_date
		THEN
			IF hisdate > real_date
			THEN
				RETURN 106;
			ELSE
				RETURN 0;
			END IF;
		ELSE
			IF hisdate > theory_date AND hisdate <= real_date
			THEN
				RETURN 103;
			ELSIF hisdate <= theory_date
				THEN
					RETURN 0;
			ELSIF hisdate > real_date
				THEN
					RETURN 106;
			END IF;
		END IF;
	END;





/

