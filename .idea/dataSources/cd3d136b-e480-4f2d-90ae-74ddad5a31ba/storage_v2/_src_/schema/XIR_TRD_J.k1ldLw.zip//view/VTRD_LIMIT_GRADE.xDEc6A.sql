create view VTRD_LIMIT_GRADE as
  SELECT A.I_CODE,
    A.A_TYPE,
    A.M_TYPE,
    CASE
        WHEN B.P_CLASS IN ('国债',
                           '地方政府债',
                           '央行票据',
                           '政策性金融债')
        THEN NVL(C.B_GRADE_NUMBER, 1000)
        ELSE NVL(C.B_GRADE_NUMBER, 0)
    END AS GRADE,
    CASE
        WHEN B.P_CLASS IN ('国债',
                           '地方政府债',
                           '央行票据',
                           '政策性金融债')
        THEN NVL(D.B_GRADE_NUMBER, 1000)
        ELSE NVL(D.B_GRADE_NUMBER, 0)
    END AS I_GRADE,
    CASE
        WHEN B.P_CLASS IN ('国债',
                           '地方政府债',
                           '央行票据',
                           '政策性金融债')
        THEN NVL(E.B_GRADE_NUMBER, 1000)
        ELSE NVL(E.B_GRADE_NUMBER, 0)
    END AS W_GRADE,
	T.B_SENIORITY,
	NVL(TR.OUTLOOK,'未评级') AS OUTLOOK
FROM TTRD_INSTRUMENT A
LEFT JOIN VBND B
 ON A.I_CODE = B.I_CODE
AND A.A_TYPE = B.A_TYPE
AND A.M_TYPE = B.M_TYPE
LEFT JOIN TBND_EXT_RATING_ENUM C
 ON B.B_EXT_RATING=C.B_GRADE
LEFT JOIN TBND_EXT_RATING_ENUM D
 ON B.B_ISSUER_EXT_RATING=D.B_GRADE
LEFT JOIN TBND_EXT_RATING_ENUM E
 ON B.B_WARRANTOR_GRADE=E.B_GRADE
LEFT JOIN TBND T
 ON A.I_CODE = T.I_CODE
AND A.A_TYPE = T.A_TYPE
AND A.M_TYPE = T.M_TYPE
LEFT JOIN TTRD_CURRDATE TC ON 1=1
LEFT JOIN TCOMPANY_RATING TR
 ON T.B_ISSUER = TR.COMP_NAME
 AND TC.CURR_DATE > TR.BEG_DATE
 AND TC.CURR_DATE <= TR.END_DATE
/

