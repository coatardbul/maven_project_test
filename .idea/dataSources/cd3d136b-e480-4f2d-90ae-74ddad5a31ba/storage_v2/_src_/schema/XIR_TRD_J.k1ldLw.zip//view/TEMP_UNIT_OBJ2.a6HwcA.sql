create view TEMP_UNIT_OBJ2 as
  (
select "BEG_DATE","UNIT_NAME","A_NAME","ACCNAME","AMRT_CP","AI" from
(select beg_date,unit_name,a_name,accname,sum(amrt_cp) as amrt_cp,sum(ai) as ai from (
select beg_date,unit_name,
case when a_type = 'SPT_DED' then p_class when a_type in ('SPT_DB','SPT_CB','SPT_ABS') then '债券' else name end as a_name,
   accname, case when  a_type = 'SPT_NWM' then real_amount else amrt_cp end as amrt_cp,ai as ai
from temp_actg_obj2)
group by beg_date,unit_name,a_name,accname) t  )



/

