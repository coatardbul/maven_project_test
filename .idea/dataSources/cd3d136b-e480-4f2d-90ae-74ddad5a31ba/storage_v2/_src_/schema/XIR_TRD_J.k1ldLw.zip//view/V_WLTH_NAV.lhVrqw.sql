create view V_WLTH_NAV as
  SELECT TSK_ID,
       A.BEG_DATE,
       A.END_DATE,
       C.I_CODE,
       C.A_TYPE,
       A.M_TYPE,
       ABS(REAL_VOLUME) AS VOLUME,
       ABS(PRFT_TRD + PRFT_IR + PRFT_FV) AS TOTAL_NAV,          -- 总净值(市值法)
       ABS(PRFT_TRD + PRFT_IR) AS TOTAL_NAV_COST,               -- 总净值(成本法)
       CASE
         WHEN REAL_AMOUNT = 0 OR PRFT_TRD = 0 THEN
          0
         ELSE
          TRUNC((PRFT_TRD + PRFT_IR + PRFT_FV) / PRFT_TRD, 4)
       END AS UNIT_NAV,                                         -- 单位净值(市值法)
       CASE
         WHEN REAL_AMOUNT = 0 OR PRFT_TRD = 0 THEN
          0
         ELSE
          TRUNC((PRFT_TRD + PRFT_IR) / PRFT_TRD, 4)
       END AS UNIT_NAV_COST,                                    -- 单位净值(成本法)
       CASE
         WHEN REAL_AMOUNT = 0 OR PRFT_TRD = 0 THEN
          0
         ELSE
          (PRFT_TRD + PRFT_IR + PRFT_FV) / PRFT_TRD
       END AS UNIT_NAV_HP,                                      -- 单位净值高精度(市值法)
       CASE
         WHEN REAL_AMOUNT = 0 OR PRFT_TRD = 0 THEN
          0
         ELSE
          (PRFT_TRD + PRFT_IR) / PRFT_TRD
       END AS UNIT_NAV_HP_COST,                                 -- 单位净值高精度(成本法)
       B.P_CLASS,
       B.I_NAME,
       D.FV_TYPE,
       ABS(PRFT_IR) AS PRFT_IR
  FROM TTRD_ACCOUNTING_SECU_OBJ A
  LEFT JOIN TTRD_WMPS_UNIT  U ON U.UNIT_CODE = A.I_CODE
 INNER JOIN (
               SELECT W_ID, I_CODE, A_TYPE, M_TYPE, I_NAME, P_CLASS,UNIT_ID
               FROM TTRD_WMPS_DEFINE_MAIN
             UNION ALL
              SELECT W_ID, I_CODE, A_TYPE, M_TYPE, I_NAME, P_CLASS,TO_CHAR(UNIT_ID)
               FROM TTRD_WMPS_DEFINE
               ) B
    ON A.M_TYPE = B.M_TYPE
   AND U.UNIT_ID = B.UNIT_ID
 INNER JOIN TTRD_INSTRUMENT C
    ON B.I_CODE = C.I_CODE
   AND B.A_TYPE = C.A_TYPE
   AND B.M_TYPE = C.M_TYPE
 INNER JOIN TTRD_P_TYPE D
    ON C.P_TYPE = D.P_TYPE
 WHERE A.A_TYPE = 'SPT_NWMPORT'
   AND C.P_CLASS <> '货币型理财产品'

UNION ALL

SELECT TSK_ID,
       A.BEG_DATE,
       A.END_DATE,
       C.I_CODE,
       C.A_TYPE,
       A.M_TYPE,
       ABS(REAL_VOLUME) AS VOLUME,
       ABS(PRFT_TRD + PRFT_IR + PRFT_FV) AS TOTAL_NAV,          -- 总净值(市值法)
       ABS(PRFT_TRD + PRFT_IR) AS TOTAL_NAV_COST,               -- 总净值(成本法)
       CASE
         WHEN REAL_AMOUNT = 0 OR PRFT_TRD = 0 THEN
          0
         ELSE
          TRUNC((PRFT_TRD + PRFT_IR + PRFT_FV) / PRFT_TRD, 4)
       END AS UNIT_NAV,                                         -- 单位净值(市值法)
       CASE
         WHEN REAL_AMOUNT = 0 OR PRFT_TRD = 0 THEN
          0
         ELSE
          TRUNC((PRFT_TRD + PRFT_IR) / PRFT_TRD, 4)
       END AS UNIT_NAV_COST,                                    -- 单位净值(成本法)
       CASE
         WHEN REAL_AMOUNT = 0 OR PRFT_TRD = 0 THEN
          0
         ELSE
          (PRFT_TRD + PRFT_IR + PRFT_FV) / PRFT_TRD
       END AS UNIT_NAV_HP,                                      -- 单位净值高精度(市值法)
       CASE
         WHEN REAL_AMOUNT = 0 OR PRFT_TRD = 0 THEN
          0
         ELSE
          (PRFT_TRD + PRFT_IR) / PRFT_TRD
       END AS UNIT_NAV_HP_COST,                                 -- 单位净值高精度(成本法)
       B.P_CLASS,
       B.I_NAME,
       D.FV_TYPE,
       ABS(PRFT_IR) AS PRFT_IR
  FROM TTRD_ACCOUNTING_SECU_OBJ_HIS A
  LEFT JOIN TTRD_WMPS_UNIT  U ON U.UNIT_CODE = A.I_CODE
 INNER JOIN (
               SELECT W_ID, I_CODE, A_TYPE, M_TYPE, I_NAME, P_CLASS,UNIT_ID
               FROM TTRD_WMPS_DEFINE_MAIN
             UNION ALL
              SELECT W_ID, I_CODE, A_TYPE, M_TYPE, I_NAME, P_CLASS,TO_CHAR(UNIT_ID)
               FROM TTRD_WMPS_DEFINE
               ) B
    ON  A.M_TYPE = B.M_TYPE
   AND U.UNIT_ID = B.UNIT_ID
 INNER JOIN TTRD_INSTRUMENT C
    ON B.I_CODE = C.I_CODE
   AND B.A_TYPE = C.A_TYPE
   AND B.M_TYPE = C.M_TYPE
 INNER JOIN TTRD_P_TYPE D
    ON C.P_TYPE = D.P_TYPE
 WHERE A.A_TYPE = 'SPT_NWMPORT'
   AND C.P_CLASS <> '货币型理财产品'



/

