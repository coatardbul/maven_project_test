create procedure TRYDROPTABCOLUMN(tabName in varchar2, colName in varchar2) is
        n_col int;
        stmt VARCHAR(2000);
        begin
          select count(*) into n_col from cols
                 where table_name = upper(tabName) and column_name = upper(colName);
          if n_col>0 then
            stmt :='alter table '||tabName||' drop column '||colName;
            execute immediate stmt;
          end if;
        end TRYDROPTABCOLUMN;




/

