create trigger INSERT_TCOMPANY_INDUSTRY
  before insert
  on TTRD_INSTITUTION_INDUSTRY
  for each row
  BEGIN
  select XIR_TRD_J.S_INSTITUION_INDUSTRY.nextval into :NEW.ID from dual;
END;















/

