create FUNCTION             "BITOR" (x IN NUMBER, y IN NUMBER) RETURN NUMBER AS

BEGIN

  RETURN (x + y - BITAND(x, y));

END;




/

