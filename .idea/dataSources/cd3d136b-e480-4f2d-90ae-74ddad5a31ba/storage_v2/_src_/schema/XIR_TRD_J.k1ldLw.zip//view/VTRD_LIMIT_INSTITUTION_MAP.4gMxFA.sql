create view VTRD_LIMIT_INSTITUTION_MAP as
  select i_id, 0 as parent_id, 0 as sort
 from ttrd_institution
 where bitand(p_type, 2) > 0
/

