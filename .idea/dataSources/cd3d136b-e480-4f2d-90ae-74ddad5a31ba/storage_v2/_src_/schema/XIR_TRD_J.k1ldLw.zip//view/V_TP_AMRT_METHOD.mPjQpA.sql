create view V_TP_AMRT_METHOD as
  SELECT 'BLC' AS TSK_ID,
    A.P_TYPE,
    COALESCE(A.AMORT_METHOD, -1) AS AMRT_METHOD,
    A.P_TYPE_NAME,
    COALESCE(A.AMORT_METHOD_NAME, '不摊销') AS AMRT_METHOD_NAME
FROM TTRD_P_TYPE A
WHERE A_TYPE IN ('SPT_BD',
                 'SPT_CB',
                 'SPT_ABS',
                 'SPT_LBS')
UNION ALL
SELECT 'BLC' AS TSK_ID,
    A.P_TYPE,
    -1 AS AMRT_METHOD,
    A.P_TYPE_NAME,
    '不摊销' AS AMRT_METHOD_NAME
FROM TTRD_P_TYPE A
WHERE A_TYPE NOT IN ('SPT_BD',
                     'SPT_CB',
                     'SPT_ABS',
                     'SPT_LBS')




/

