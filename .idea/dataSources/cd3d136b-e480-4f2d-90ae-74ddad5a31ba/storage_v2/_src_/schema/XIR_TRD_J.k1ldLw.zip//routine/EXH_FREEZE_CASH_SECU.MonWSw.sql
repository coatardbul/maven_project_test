create PROCEDURE EXH_FREEZE_CASH_SECU(PI_CASH_ACCID IN VARCHAR2,  -- 资金帐号
                                                 PI_SECU_ACCID IN VARCHAR2,  -- 证券帐号
                                                 PI_I_CODE IN VARCHAR2,      -- 证券代码
                                                 PI_A_TYPE IN VARCHAR2,      -- 资产类别
                                                 PI_M_TYPE IN VARCHAR2,      -- 市场类别
                                                 PI_LS IN CHAR,              -- 多空标识（L,S）
                                                 PI_FREEZE_CNT NUMBER,       -- 冻结/解冻股份（正，冻结；负，解冻）
                                                 PI_FREEZE_AMT NUMBER,       -- 冻结/解冻资金（正，冻结；负，解冻）
                                                 PI_FREEZE_FEE NUMBER,       -- 冻结/解冻费用（正，冻结；负，解冻）
                                                 PI_RESERVE_AMT IN NUMBER,   -- 最小资金保留数
                                                 PO_ERRCODE OUT NUMBER,      -- 错误号
                                                 PO_ERRINFO OUT VARCHAR2     -- 错误信息
                                            ) AS

  CURSOR CUR_CASH(P_CASH_ACCID IN VARCHAR2) IS
     SELECT *
     FROM TTRD_EXH_ACC_BALANCE_CASH_EXT
     WHERE ACCID = P_CASH_ACCID
     FOR UPDATE;

  CURSOR CUR_SECU(P_SECU_ACCID IN VARCHAR2, P_I_CODE IN VARCHAR2, P_A_TYPE IN VARCHAR2, P_M_TYPE IN VARCHAR2, P_LS IN CHAR) IS
    SELECT *
       FROM TTRD_EXH_ACC_BALANCE_SECU_EXT
    WHERE ACCID = P_SECU_ACCID
       AND I_CODE = P_I_CODE
       AND A_TYPE = P_A_TYPE
       AND M_TYPE = P_M_TYPE
       AND LS = P_LS
       FOR UPDATE;

  REC_CASH TTRD_EXH_ACC_BALANCE_CASH_EXT%ROWTYPE;
  REC_SECU TTRD_EXH_ACC_BALANCE_SECU_EXT%ROWTYPE;

  V_RESERVE_CASH NUMBER;
  V_FREEZE_CASH NUMBER;
  V_FREEZE_SECU NUMBER;

BEGIN
   PO_ERRCODE := 0;
   PO_ERRINFO := '';
   V_FREEZE_CASH := PI_FREEZE_AMT + PI_FREEZE_FEE;
   V_FREEZE_SECU := PI_FREEZE_CNT;
   V_RESERVE_CASH := PI_RESERVE_AMT;
   IF V_RESERVE_CASH < 0 THEN
      V_RESERVE_CASH := 0;
   END IF;

   -- 冻结失败，则回滚至此
   SAVEPOINT SP_FREEZE;

   -- 冻结/解冻资金
   IF V_FREEZE_CASH <> 0 THEN
      -- 打开资金游标
      OPEN CUR_CASH(PI_CASH_ACCID);
      FETCH CUR_CASH INTO REC_CASH;
      IF CUR_CASH%NOTFOUND THEN
         PO_ERRCODE := -10011;
         PO_ERRINFO := '资金余额不存在';
         GOTO LABLE_QUIT;
      END IF;

      IF V_FREEZE_CASH >= 0.001 THEN
         -- 冻结：检查资金可用余额是否足额
         IF REC_CASH.RT_AVAAMOUNT - V_RESERVE_CASH - V_FREEZE_CASH < 0.001 THEN
            PO_ERRCODE := -10012;
            PO_ERRINFO := '资金余额不足，还需资金：' || TO_CHAR(REC_CASH.RT_AVAAMOUNT - V_RESERVE_CASH - V_FREEZE_CASH);
            GOTO LABLE_QUIT;
         END IF;
      END IF;

      -- 冻结、解冻资金
      UPDATE TTRD_EXH_ACC_BALANCE_CASH_EXT
         SET RT_AVAAMOUNT  = RT_AVAAMOUNT - ROUND(V_RESERVE_CASH, 2),
             RT_FREAMOUNT  = RT_FREAMOUNT + ROUND(V_RESERVE_CASH, 2),
             RT_UPDATETIME = CURRENT_DATE
      WHERE CURRENT OF CUR_CASH;
   END IF;

   -- 冻结/解冻股份
   IF V_FREEZE_SECU <> 0 THEN
      -- 打开股份游标
      OPEN CUR_SECU(PI_SECU_ACCID, PI_I_CODE, PI_A_TYPE, PI_M_TYPE, PI_LS);
      FETCH CUR_SECU INTO REC_SECU;
      IF CUR_SECU%NOTFOUND THEN
         PO_ERRCODE := -10013;
         PO_ERRINFO := '股份余额不存在';
         GOTO LABLE_QUIT;
      END IF;

      IF V_FREEZE_SECU > 0 THEN
         -- 冻结：检查股份可用余额是否足额
         IF REC_SECU.RT_AVAAMOUNT - V_FREEZE_SECU < 0 THEN
            PO_ERRCODE := -10014;
            PO_ERRINFO := '股份余额不足，还需证券：' || TO_CHAR(V_FREEZE_SECU - REC_SECU.RT_AVAAMOUNT);
            GOTO LABLE_QUIT;
         END IF;
      END IF;

      UPDATE TTRD_EXH_ACC_BALANCE_SECU_EXT
         SET RT_AVAAMOUNT       = RT_AVAAMOUNT - V_FREEZE_SECU,
             RT_ORDER_FREAMOUNT = RT_ORDER_FREAMOUNT + V_FREEZE_SECU,
             RT_UPDATETIME      = CURRENT_DATE
      WHERE CURRENT OF CUR_SECU;
   END IF;


   <<LABLE_QUIT>>

   IF PO_ERRCODE < 0 THEN
      -- 验资验券失败，回滚至保存点SP_FREEZE
      ROLLBACK TO SP_FREEZE;
   END IF;

   IF CUR_CASH%ISOPEN THEN
      CLOSE CUR_CASH;
   END IF;

   IF CUR_SECU%ISOPEN THEN
      CLOSE CUR_SECU;
   END IF;

END;
/

