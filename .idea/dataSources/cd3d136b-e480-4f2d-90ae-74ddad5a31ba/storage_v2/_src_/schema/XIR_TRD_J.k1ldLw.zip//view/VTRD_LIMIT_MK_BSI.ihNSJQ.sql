create view VTRD_LIMIT_MK_BSI as
  SELECT I_CODE,
    A_TYPE,
    M_TYPE,
    MK_PRICE,
    MK_PRICE + MK_ACCRUAL AS MK_DIRTY_PRICE,
    MK_ACCRUAL,
    MK_DURATION,
    MK_MAC_DURATION,
    MK_CONVEXITY,
    MK_DVBP,
    MK_YIELD,
    MK_PAR_VALUE,
    MK_PAR_VALUE2,
    MK_VOLUME,
    MK_U_VOLUME,
    CURRENCY,
    -- 剩余期限（含行权）
    CASE
        WHEN LEFT_DATES IS NULL
        AND STRIKE_LEFT_DATES IS NULL
        THEN NULL
        ELSE
            CASE
                WHEN STRIKE_LEFT_DATES IS NULL
                THEN LEFT_DATES
                ELSE DECODE(SIGN(LEFT_DATES - STRIKE_LEFT_DATES), 1, STRIKE_LEFT_DATES, LEFT_DATES)
            END
    END AS LEFT_DATES_M,
    -- 反售期限
    RETURN_LIMIT_DATE,
    HUGE_REDEMPTION_RATIO*MK_VOLUME AS HUGE_REDEMPTION_RATIO, -- 巨额赎回比例
    COALESCE(GRADE_DOWN_TERM,99999) AS GRADE_DOWN_TERM,
  S_TOTAL_STOCK,
  S_LIST_STOCK,
  DP_CLOSE
FROM (SELECT A.I_CODE,
            A.A_TYPE,
            A.M_TYPE,
            CASE
                WHEN COALESCE(EE.NETPRICE, 0) > 0
                THEN EE.NETPRICE
                ELSE
                    CASE
                        WHEN COALESCE(B.MANUAL_FV, 0) > 0
                        THEN B.MANUAL_FV
                        ELSE
                            CASE
                                WHEN B.FV_TYPE = 1
                                THEN COALESCE(B.MKT_FV, COALESCE(B.CAL_FV, 0))
                                WHEN B.FV_TYPE = 2
                                THEN COALESCE(B.CAL_FV, COALESCE(B.MKT_FV, 0))
                                ELSE A.PAR_VALUE
                            END
                    END
            END                        AS MK_PRICE,
            COALESCE(C.MK_ACCRUAL, 0)  AS MK_ACCRUAL,
            COALESCE(EE.MODIFIED_D,C.MK_DURATION, 0) AS MK_DURATION,
            ROUND((TO_DATE(A.MTR_DATE, 'YYYY-MM-DD') - TO_DATE((GG.CURR_DATE), 'YYYY-MM-DD')) / 365
            , 2) AS LEFT_DATES,
            CASE
                WHEN DE.B_STRIKE_DATE IS NOT NULL
                THEN ROUND((TO_DATE(DE.B_STRIKE_DATE, 'YYYY-MM-DD') - TO_DATE((GG.CURR_DATE),
                    'YYYY-MM-DD')) / 365, 2)
                ELSE NULL
            END AS STRIKE_LEFT_DATES,
            CASE
                WHEN TT.START_DATE IS NOT NULL
                AND TT.MTR_DATE IS NOT NULL
                THEN ROUND((TO_DATE(TT.MTR_DATE, 'YYYY-MM-DD') - TO_DATE(TT.START_DATE,
                    'YYYY-MM-DD')) / 365, 4)
                ELSE NULL
            END                                   AS RETURN_LIMIT_DATE,
            COALESCE(C.MK_MAC_DURATION, 0)        AS MK_MAC_DURATION,
            COALESCE(C.MK_CONVEXITY, 0)           AS MK_CONVEXITY,
            COALESCE(C.MK_DVBP, 0)                AS MK_DVBP,
            COALESCE(C.MK_YIELD, 0)               AS MK_YIELD,
            COALESCE(C.MK_PAR_VALUE, A.PAR_VALUE) AS MK_PAR_VALUE,
            A.PAR_VALUE                           AS MK_PAR_VALUE2,
            COALESCE(FF.VOLUME * 100000000, 0)    AS MK_VOLUME,
            COALESCE(IE.VOLUME * 100000000, 0)    AS MK_U_VOLUME,
            A.CURRENCY,
            TF.HUGE_REDEMPTION_RATIO,
            GRADE.GRADE_DOWN_TERM,
      TE.S_TOTAL_STOCK,
      TE.S_LIST_STOCK,
      TEXG.DP_CLOSE
       FROM TTRD_INSTRUMENT A
  LEFT JOIN TTRD_CURRDATE GG
         ON 1 = 1
  LEFT JOIN TTRD_INSTRUMENT_EVAL B
         ON A.I_CODE = B.I_CODE
        AND A.A_TYPE = B.A_TYPE
        AND A.M_TYPE = B.M_TYPE
        AND B.BEG_DATE = GG.CURR_DATE
  LEFT JOIN
            (SELECT t.*,
                    ROW_NUMBER() OVER(PARTITION BY I_CODE, A_TYPE, M_TYPE ORDER BY beg_date DESC)
                    RN
               FROM TBSI_IR t) C
         ON A.I_CODE = C.I_CODE
        AND A.A_TYPE = C.A_TYPE
        AND A.M_TYPE = C.M_TYPE
        AND C.RN = 1
  LEFT JOIN ttrd_instrument_extend FF
         ON A.I_CODE = FF.I_CODE
        AND A.A_TYPE = FF.A_TYPE
        AND A.M_TYPE = FF.M_TYPE
        AND FF.extend_type = '03'
        AND FF.BEG_DATE <= GG.CURR_DATE
        AND (
                FF.END_DATE > GG.CURR_DATE
             OR FF.END_DATE IS NULL)

    LEFT JOIN ttrd_instrument_extend IE
         ON A.U_I_CODE = IE.I_CODE
        AND A.U_A_TYPE = IE.A_TYPE
        AND A.U_M_TYPE = IE.M_TYPE
        AND IE.extend_type = '03'
        AND IE.BEG_DATE <= GG.CURR_DATE
        AND (
                IE.END_DATE > GG.CURR_DATE
             OR IE.END_DATE IS NULL)

  LEFT JOIN TCB_BOND_EVAL EE
         ON A.I_CODE = EE.I_CODE
        AND A.A_TYPE = EE.A_TYPE
        AND A.M_TYPE = EE.M_TYPE
        AND EE.BEG_DATE <= GG.CURR_DATE
        AND EE.END_DATE > GG.CURR_DATE
  LEFT JOIN
            ( SELECT I_CODE,
                    A_TYPE,
                    M_TYPE,
                    MIN(B_STRIKE_DATE) AS B_STRIKE_DATE
               FROM TBND_EXERCISE
              WHERE B_STRIKE_DATE >=
                    (SELECT CURR_DATE
                       FROM TTRD_CURRDATE)
           GROUP BY I_CODE,
                    A_TYPE,
                    M_TYPE ) DE
         ON A.I_CODE = DE.I_CODE
        AND A.A_TYPE = DE.A_TYPE
        AND A.M_TYPE = DE.M_TYPE
  LEFT JOIN
            (SELECT TC.I_CODE,
                    TC.A_TYPE,
                    TC.M_TYPE,
                    TC.BEG_DATE AS START_DATE,
                    TC.MTR_DATE AS MTR_DATE
               FROM TTRD_CASHLB TC
          UNION ALL
             SELECT TB.I_CODE,
                    TB.A_TYPE,
                    TB.M_TYPE,
                    TB.FST_SETDATE AS START_DATE,
                    TB.END_SETDATE AS MTR_DATE
               FROM TTRD_OUTRIGHT TB) TT
         ON A.I_CODE = TT.I_CODE
        AND A.A_TYPE = TT.A_TYPE
        AND A.M_TYPE = TT.M_TYPE
        LEFT JOIN TFND TF ON A.I_CODE = TF.I_CODE
        AND A.A_TYPE = TF.A_TYPE
        AND A.M_TYPE = TF.M_TYPE
    LEFT JOIN TSTK_EQUITY TE
    ON A.I_CODE = TE.I_CODE
        AND A.A_TYPE = TE.A_TYPE
        AND A.M_TYPE = TE.M_TYPE
    LEFT JOIN TEXG_DAILYPRICE TEXG
    ON A.I_CODE = TEXG.I_CODE
        AND A.A_TYPE = TEXG.A_TYPE
        AND A.M_TYPE = TEXG.M_TYPE
        LEFT JOIN (
                SELECT R.I_CODE ,R.A_TYPE,R.M_TYPE,MIN(TO_DATE(C.CURR_DATE,'YYYY-MM-DD')-TO_DATE(R.BEG_DATE,'YYYY-MM-DD')) AS GRADE_DOWN_TERM
                FROM TBND_EXT_RATING R
                LEFT JOIN TBND_EXT_RATING_ENUM E ON R.B_GRADE = E.B_GRADE
                LEFT JOIN TTRD_CURRDATE C ON 1=1
                WHERE R.B_RATING_CHANGE = '3' AND E.B_GRADE_NUMBER<'126' AND R.BEG_DATE <= C.CURR_DATE
                GROUP BY R.I_CODE ,R.A_TYPE,R.M_TYPE
        ) GRADE ON A.I_CODE = GRADE.I_CODE
        AND A.A_TYPE = GRADE.A_TYPE
        AND A.M_TYPE = GRADE.M_TYPE
        )
/

