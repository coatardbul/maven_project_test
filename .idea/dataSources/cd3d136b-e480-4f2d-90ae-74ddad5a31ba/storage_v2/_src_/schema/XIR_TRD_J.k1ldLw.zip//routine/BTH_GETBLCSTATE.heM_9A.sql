create FUNCTION             "BTH_GETBLCSTATE"(real_date IN VARCHAR2,
                                           hisdate   IN VARCHAR2)
  RETURN number IS
BEGIN
  if real_date is null then
    return 0;
  end if;

  if hisdate > real_date then
    return 53;
  else
    return 0;
  end if;
END;





/

