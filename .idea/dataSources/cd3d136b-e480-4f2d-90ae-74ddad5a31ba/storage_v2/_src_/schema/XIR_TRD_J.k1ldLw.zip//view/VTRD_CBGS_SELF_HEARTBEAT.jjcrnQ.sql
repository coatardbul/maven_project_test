create view VTRD_CBGS_SELF_HEARTBEAT as
  SELECT TXFLOWID, --交易流水标识
    HRTBT_ID, --心跳序号
    HRTBTREF_ID, --心跳参考号
    IR_STATUS, --状态0:IR提交结算服务成功，1：已提交中债登，5：中债回应
    MSG_SND_DATETIME, --发起时间
    UPDATETIME, --返回时间
    ERRORCODE, -- 错误号
    ERRORMSG --错误信息
FROM TTRD_CBGS_HEARTBEATMESSAGE




/

