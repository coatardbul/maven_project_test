create PROCEDURE EXH_INSERT_SECU(PI_BEG_DATE           IN VARCHAR2,
											PI_ACCID              IN VARCHAR2,
                                            PI_I_CODE             IN VARCHAR2,
                                            PI_A_TYPE             IN VARCHAR2,
                                            PI_M_TYPE             IN VARCHAR2,
                                            PI_LS                 IN VARCHAR2,
                                            PI_PS_AMOUNT          IN NUMBER,
                                            PI_PS_AVAAMOUNT       IN NUMBER,
                                            PI_PS_FREAMOUNT       IN NUMBER,
                                            PI_RT_AMOUNT          IN NUMBER,
                                            PI_RT_AVAAMOUN        IN NUMBER,
                                            PI_RT_ORDER_FREAMOUNT IN NUMBER,
                                            PI_RT_BUY_FREAMOUNT   IN NUMBER) AS
BEGIN
  INSERT INTO TTRD_EXH_ACC_BALANCE_SECU_EXT
    (BEG_DATE,
     ACCID,
     I_CODE,
     A_TYPE,
     M_TYPE,
     LS,
     PS_AMOUNT,
     PS_AVAAMOUNT,
     PS_FREAMOUNT,
     RT_AMOUNT,
     RT_AVAAMOUNT,
     RT_ORDER_FREAMOUNT,
     RT_BUY_FREAMOUNT,
     PS_UPDATETIME,
     RT_UPDATETIME)
  VALUES
    (PI_BEG_DATE,
     PI_ACCID,
     PI_I_CODE,
     PI_A_TYPE,
     PI_M_TYPE,
     PI_LS,
     PI_PS_AMOUNT,
     PI_PS_AVAAMOUNT,
     PI_PS_FREAMOUNT,
     PI_RT_AMOUNT,
     PI_RT_AVAAMOUN,
     PI_RT_ORDER_FREAMOUNT,
     PI_RT_BUY_FREAMOUNT,
     CURRENT_DATE,
     CURRENT_DATE);
END;
/

