create view VTRD_CBGS_INSTR_BATCH as
  SELECT B.TXFLOWID AS TXFLOWID, --交易流水标识
    A.INSTR_ID, --中债指令编号
    A.INSTR_ORIGIN, --中债指令来源
    A.INSTR_STATUS, --中债指令状态
    (
        CASE
            WHEN A.GIV_ACCT_ID = A.ACCID --为本方托管账号
            THEN A.INITIATOR_CONFIRM
            ELSE A.CP_CONFIRM
        END) AS INSTR_CONFIRM, --本方确认标识
    (
        CASE
            WHEN A.GIV_ACCT_ID = A.ACCID --为本方托管账号
            THEN A.CP_CONFIRM
            ELSE A.INITIATOR_CONFIRM
        END) AS PARTY_INSTR_CONFIRM, --对手方确认标识
    A.TXID      EXTORDID, --外汇交易中心外部成交编号
    (
        CASE
            WHEN A.GIV_ACCT_ID = A.ACCID --为本方托管账号
            THEN
                (SELECT MAP_VALUE
                   FROM VTRD_CBGS_SYS_CONVERT_MAP --判断买入卖出视图
                  WHERE MAP_ITEM = 'CBGS_INSTBIZTYPE_MAP'
                    AND MAP_KEY = A.BIZTYPE ||
                        '_SELFGIV') --现券卖出
            ELSE
                  (SELECT MAP_VALUE
                 FROM VTRD_CBGS_SYS_CONVERT_MAP --判断买入卖出视图
                WHERE MAP_ITEM = 'CBGS_INSTBIZTYPE_MAP'
                  AND MAP_KEY = A.BIZTYPE ||
                      '_SELFTAK') --现券买入
        END)  BIZTYPE, -- 业务类别
    A.ACCID   AS ZZDACCCODE, -- 本方托管账号
    A.ACCNAME AS ZZDACCNAME, -- 本方托管账号名称
    (
        CASE
            WHEN A.GIV_ACCT_ID = A.ACCID --为本方托管账号
            THEN A.TAK_ACCT_ID --收券账户
            ELSE A.GIV_ACCT_ID --付券账户
        END) PARTY_ZZDACCCODE, -- 对手方托管账号
    (
        CASE
            WHEN A.GIV_ACCT_ID = A.ACCID --为本方托管账号
            THEN A.TAK_ACCT_NAME --收券账户名称
            ELSE A.GIV_ACCT_NAME --付券账户名称
        END)         PARTY_ZZDACCNAME, --对手方托管账户名称
    A.QUERY_DATE     AS FSTSETDATE, --首期结算日期
    A.SETTLEMENT1       FSTSETTYPE, --首期结算方式
    A.SETTLE_AMOUNT1    FSTAMOUNT, --首期结算金额
    ''               AS ENDSETDATE, --到期结算日期
    A.SETTLEMENT2       ENDSETTYPE, --到期结算方式
    A.SETTLE_AMOUNT2    ENDAMOUNT, --到期结算金额
    A.QUERY_DATE, --查询日期
    B.UPDATETIME --更新日期
FROM TTRD_CBGS_SETTLEBIZ_BATCH A, --批量查询结果
    TTRD_CBGS_SETTLEBIZ_QUERY B --结算业务查询
WHERE A.CID = B.CID
AND A.REQUEST_CODE = 'BJ0300'
AND A.BIZTYPE IN ('BT01', --现券
                  'BT02', --质押式回购
                  'BT05', --债券借贷
                  'BT06', --质押券置换
                  'BT00', --普通分销
                  'BT11', --转托管
                  'BT03', --买断式回购
                  'BT04', --债券远期
                  'BT10', --投资人选择提前赎回
                  'BT07', --BEPS质押
                  'BT08', --BEPS解押
                  'BT09' --BEPS质押券置换
                  )




/

