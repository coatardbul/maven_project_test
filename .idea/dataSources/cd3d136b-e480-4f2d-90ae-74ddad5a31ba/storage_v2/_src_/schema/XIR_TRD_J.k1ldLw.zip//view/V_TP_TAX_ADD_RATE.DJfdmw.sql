create view V_TP_TAX_ADD_RATE as
  SELECT
'' AS TAX_RATE_TYPE, --附加税税率类型：11城建税 12中央教育附加税 13地方教育附加税
0.03 AS TAX_RATE
FROM DUAL WHERE 1 = 0



/

