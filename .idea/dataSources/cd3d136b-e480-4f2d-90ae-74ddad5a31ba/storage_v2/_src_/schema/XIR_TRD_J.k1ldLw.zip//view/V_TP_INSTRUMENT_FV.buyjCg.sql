create view V_TP_INSTRUMENT_FV as
  SELECT A.I_CODE,
    --代码
    A.A_TYPE,
    A.M_TYPE,
    B.I_NAME,
    --名称
    CASE
        WHEN COALESCE(MANUAL_FV,0)>0
        THEN MANUAL_FV
        ELSE
            CASE
                WHEN FV_TYPE=1
                THEN COALESCE(MKT_FV,COALESCE(CAL_FV,0))
                WHEN FV_TYPE=2
                THEN COALESCE(CAL_FV,COALESCE(MKT_FV,0))
                ELSE 0
            END
    END AS FV,
    --核算使用估值
    A.MANUAL_FV,
    ---手工维护估值
    A.MKT_FV,
    --市场估值
    A.CAL_FV,
    --系统定价
    A.MANUAL_YIELD,
    --手工到期收益率
    A.MKT_YIELD,
    --市场到期收益率
    A.CAL_YIELD,
    --定价到期收益率
    A.BEG_DATE,
    A.END_DATE,
    --估值日期
    A.IMP_TIME, --估值时间
    FV_TYPE
FROM TTRD_INSTRUMENT_EVAL A,
    TTRD_INSTRUMENT B
WHERE A.I_CODE = B.I_CODE
AND A.A_TYPE = B.A_TYPE
AND A.M_TYPE = B.M_TYPE
AND (
        MANUAL_FV IS NOT NULL
    AND MANUAL_FV<>0
     OR MKT_FV IS NOT NULL
    AND MKT_FV<>0
     OR CAL_FV IS NOT NULL
    AND CAL_FV<>0 )
UNION ALL
SELECT A1.I_CODE,
    A1.A_TYPE,
    A1.M_TYPE,
    A1.I_NAME,
    UNIT_NAV AS FV,
    --核算使用估值
    UNIT_NAV AS MANUAL_FV,
    ---手工维护估值
    UNIT_NAV AS MKT_FV,
    --市场估值
    UNIT_NAV AS CAL_FV,
    --系统定价
    UNIT_NAV AS MANUAL_YIELD,
    --手工到期收益率
    UNIT_NAV AS MKT_YIELD,
    --市场到期收益率
    UNIT_NAV AS CAL_YIELD,
    --定价到期收益率
    BEG_DATE,
    END_DATE,
    --估值日期
    NULL AS IMP_TIME,
    --估值时间
    FV_TYPE
FROM (SELECT BEG_DATE,
            TO_CHAR(TO_DATE(BEG_DATE, 'YYYY-MM-DD') + 1, 'YYYY-MM-DD') AS END_DATE,
            A.I_CODE,
            A.A_TYPE,
            A.M_TYPE,
            COALESCE(A.PUBLISH_NAV, A.SYSTEM_NAV) AS UNIT_NAV,
            B.P_CLASS,
            B.I_NAME,
            C.FV_TYPE
       FROM TTRD_WMPS_NAV_PUBLISH A,
            TTRD_INSTRUMENT B,
            TTRD_P_TYPE C
      WHERE A.A_TYPE = 'SPT_NWM'
        AND A.I_CODE = B.I_CODE
        AND A.A_TYPE = B.A_TYPE
        AND A.M_TYPE = B.M_TYPE
        AND B.P_CLASS <> '货币型理财产品'
        AND B.P_TYPE = C.P_TYPE) A1
UNION ALL
SELECT A.I_CODE, A.A_TYPE, A.M_TYPE, B.I_NAME, A.UNIT_NAV, NULL, UNIT_NAV, NULL, NULL, NULL, NULL, A.BEG_DATE, A.END_DATE, NULL, 1
FROM TTRD_ACCOUNTING_WLTH_NAV A, TTRD_WMPS_DEFINE_MAIN B
WHERE A.I_CODE = B.I_CODE AND A.A_TYPE = B.A_TYPE AND A.M_TYPE = B.M_TYPE AND B.WMPS_TYPE = 5



/

