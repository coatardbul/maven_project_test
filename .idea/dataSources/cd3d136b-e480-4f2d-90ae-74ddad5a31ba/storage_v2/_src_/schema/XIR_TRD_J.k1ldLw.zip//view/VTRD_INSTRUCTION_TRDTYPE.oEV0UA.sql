create view VTRD_INSTRUCTION_TRDTYPE as
  SELECT a.inst_id,
    d.trdtype,
    d.fst_trdtype,
    b.secu_inst_id
FROM ttrd_set_instruction a
INNER JOIN ttrd_set_instruction_secu b
 ON a.inst_id = b.inst_id
AND a.h_i_code = b.i_code
AND a.h_a_type = b.a_type
AND a.h_m_type = b.m_type
INNER JOIN ttrd_instrument c
 ON a.h_i_code = c.i_code
AND a.h_a_type = c.a_type
AND a.h_m_type = c.m_type
INNER JOIN ttrd_instruction_trdtype d
 ON (
        c.a_type = d.a_type
     OR d.a_type = '#')
AND (
        c.p_type = d.p_type
     OR d.p_type = '#')
AND b.biz_type = d.biz_type
AND (
        d.direction = 'ALL'
     OR d.direction = b.direction)
WHERE a.inst_type = 2
AND a.state = -1
AND d.group_num = 0
/*适用于仅存在一条券指令与主指令金融工具相同，可多条额外券指令*/
UNION ALL
SELECT a.inst_id,
    d.trdtype,
    d.fst_trdtype,
    b.secu_inst_id
FROM ttrd_set_instruction a
INNER JOIN ttrd_set_instruction_secu b
 ON a.inst_id = b.inst_id
INNER JOIN ttrd_instrument c
 ON a.h_i_code = c.i_code
AND a.h_a_type = c.a_type
AND a.h_m_type = c.m_type
INNER JOIN ttrd_instruction_trdtype d
 ON (
        c.a_type = d.a_type
     OR d.a_type = '#')
AND (
        c.p_type = d.p_type
     OR d.p_type = '#')
AND d.biz_type = b.biz_type
AND d.direction = b.direction
WHERE a.inst_type = 2
AND a.state = -1
AND d.group_num = 1
AND NOT EXISTS
    (SELECT secu_inst_id
       FROM ttrd_set_instruction_secu se
      WHERE se.inst_id = a.inst_id
        AND se.i_code = a.h_i_code
        AND se.a_type = a.h_a_type
        AND se.m_type = a.h_m_type)
/*适用于仅存在一条券指令，且金融工具与主指令不同*/
UNION ALL
SELECT a.inst_id,
    d.trdtype,
    d.fst_trdtype,
    (SELECT MIN(b.secu_inst_id)
       FROM ttrd_set_instruction_secu b
      WHERE b.inst_id = a.inst_id) secu_inst_id
FROM ttrd_set_instruction a
INNER JOIN ttrd_instrument c
 ON a.h_i_code = c.i_code
AND a.h_a_type = c.a_type
AND a.h_m_type = c.m_type
INNER JOIN ttrd_instruction_trdtype d
 ON (
        c.a_type = d.a_type
     OR d.a_type = '#')
AND (
        c.p_type = d.p_type
     OR d.p_type = '#')
WHERE a.inst_type = 2
AND a.state = -1
AND d.group_num = 2
AND NOT EXISTS
    (SELECT secu_inst_id
       FROM ttrd_set_instruction_secu se
      WHERE se.inst_id = a.inst_id
        AND se.i_code = a.h_i_code
        AND se.a_type = a.h_a_type
        AND se.m_type = a.h_m_type)
    /*适用于存在多条券指令，且金融工具与主指令都不同*/
    
 
 
 
 

