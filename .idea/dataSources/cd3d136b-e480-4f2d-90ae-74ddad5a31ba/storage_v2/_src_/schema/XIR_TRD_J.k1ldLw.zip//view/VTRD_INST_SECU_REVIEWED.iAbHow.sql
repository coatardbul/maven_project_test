create view VTRD_INST_SECU_REVIEWED as
  SELECT SECU_ACCT_ID,
    EXT_SECU_ACCT_ID,
    I_CODE,
    A_TYPE,
    M_TYPE,
    TRADE_GRP_ID,
    SET_DATE,
    SUM(AMOUNT)  AS AMOUNT,
    SUM(REAL_AI) AS REAL_AI,
    SUM(REAL_CP) AS REAL_CP,
    SUM(DUE_AI)  AS DUE_AI,
    SUM(DUE_CP)  AS DUE_CP
FROM (SELECT S.SECU_ACCT_ID,
            S.EXT_SECU_ACCT_ID,
            S.I_CODE,
            S.A_TYPE,
            S.M_TYPE,
            S.TRADE_GRP_ID,
            S.SET_DATE,
            S.AMOUNT,
            CASE
                WHEN (S.BIZ_TYPE='21301'
                     OR S.BIZ_TYPE='21302')
                THEN 0
                ELSE S.ESTD_AI
            END AS REAL_AI,
            CASE
                WHEN (S.BIZ_TYPE='21301'
                     OR S.BIZ_TYPE='21302')
                THEN 0
                ELSE S.ESTD_CP
            END AS REAL_CP,
            CASE
                WHEN (S.BIZ_TYPE='21301'
                     OR S.BIZ_TYPE='21302')
                THEN S.ESTD_AI
                ELSE 0
            END AS DUE_AI,
            CASE
                WHEN (S.BIZ_TYPE='21301'
                     OR S.BIZ_TYPE='21302')
                THEN S.ESTD_CP
                ELSE 0
            END AS DUE_CP
       FROM TTRD_SET_INSTRUCTION_SECU S
  LEFT JOIN TTRD_SET_INSTRUCTION I
         ON S.INST_ID = I.INST_ID
      WHERE I.INST_TYPE>-10
        AND S.OPR_STATE IN(1,2,5,9) ) T
GROUP BY SECU_ACCT_ID,
    EXT_SECU_ACCT_ID,
    I_CODE,
    A_TYPE,
    M_TYPE,
    TRADE_GRP_ID,
    SET_DATE




/

