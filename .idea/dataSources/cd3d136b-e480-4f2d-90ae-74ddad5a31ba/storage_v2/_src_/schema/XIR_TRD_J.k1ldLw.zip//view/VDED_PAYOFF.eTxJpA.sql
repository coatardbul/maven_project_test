create view VDED_PAYOFF as
  SELECT NULL AS I_CODE,
        NULL AS A_TYPE,
        NULL AS M_TYPE,
        NULL AS PARAM_TYPE,
        NULL AS PARAM_KEY,
        NULL AS PARAM_VALUE
        FROM DUAL




/

