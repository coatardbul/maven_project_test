create procedure TRYDROPINDEX(indexName in varchar2) is
      stmt VARCHAR2(2000);
      row1 number;
      begin
      select count(index_name) into row1 from user_indexes where index_name = indexName;
        IF (row1>0) THEN
          stmt :='DROP INDEX '|| indexName;
          execute immediate stmt;
        END IF;
      end TRYDROPINDEX;




/

