create view V_TCB_BOND_EVAL_ALL as
  select
              O.I_CODE,
              O.A_TYPE,
              O.M_TYPE,
              O.BEG_DATE,
              case when A.TERM is null then to_char(nvl(C.MK_MATURITY,0), 'fm9990.0000')
                else A.TERM END as TERM ,--估值行权+到期剩余期限
              case
                when nvl(A.A_TERM,0)=0 and nvl(B.A_TERM,0)=0 then to_char(nvl(C.MK_MATURITY,0), 'fm9990.0000')
                  when nvl(A.A_TERM,0)=0 then to_char(B.A_TERM, 'fm9990.0000')
                    else to_char(A.A_TERM, 'fm9990.0000') END  as  A_TERM, --到期剩余期限
              case
                when nvl(A.B_TERM,0)=0 and nvl(B.B_TERM,0)=0 then to_char(nvl(C.MK_MATURITY,0), 'fm9990.0000')
                  when nvl(A.B_TERM,0)=0 then to_char(B.B_TERM, 'fm9990.0000')
                    else to_char(A.B_TERM, 'fm9990.0000') END  as B_TERM, --行权优先剩余期限
              case
                when nvl(A.A_MODIFIED_D,0)=0 and nvl(B.A_MODIFIED_D,0)=0 then round(nvl(C.MK_DURATION,0),4)
                when nvl(A.A_MODIFIED_D,0)=0  then B.A_MODIFIED_D
                else A.A_MODIFIED_D  END as A_MODIFIED_D, --到期久期
              case
                when nvl(A.B_MODIFIED_D,0)=0 and nvl(B.B_MODIFIED_D,0)=0 then round(nvl(C.MK_DURATION,0),4)
                when nvl(A.B_MODIFIED_D,0)=0  then B.B_MODIFIED_D
                else A.B_MODIFIED_D  END as B_MODIFIED_D, --行权优先久期
              case
                when nvl(A.A_FULLPRICE,0)=0 and nvl(B.A_FULLPRICE,0)=0 then round(nvl(C.MK_TPRICE,0),4)
                when nvl(A.A_FULLPRICE,0)=0 then B.A_FULLPRICE
                else A.A_FULLPRICE END as A_FULLPRICE, --到期全价
              case
                when nvl(A.B_FULLPRICE,0)=0 and nvl(B.B_FULLPRICE,0)=0 then round(nvl(C.MK_TPRICE,0),4)
                when nvl(A.B_FULLPRICE,0)=0 then B.B_FULLPRICE
                else A.B_FULLPRICE  END as B_FULLPRICE, --行权优先全价
              case
                when nvl(A.A_NETPRICE,0)=0 and nvl(B.A_NETPRICE,0)=0 then round(nvl(C.MK_TPRICE,0)-nvl(C.MK_ACCRUAL,0),4)
                when nvl(A.A_NETPRICE,0)=0 then B.A_NETPRICE
                else A.A_NETPRICE END as A_NETPRICE, --到期净价
              case
                when nvl(A.B_NETPRICE,0)=0 and nvl(B.B_NETPRICE,0)=0 then round(nvl(C.MK_TPRICE,0)-nvl(C.MK_ACCRUAL,0),4)
                when nvl(A.B_NETPRICE,0)=0 then B.B_NETPRICE
                else A.B_NETPRICE  END as B_NETPRICE, --行权优先净价
              case
                when  nvl(A.A_YIELD,0)=0 and nvl(B.A_YIELD,0)=0  then round(nvl(C.MK_YIELD,0),6)
                when nvl(A.A_YIELD,0)=0 then B.A_YIELD
                else A.A_YIELD END as A_YIELD, --到期收益率
              case
                when  nvl(A.B_YIELD,0)=0 and nvl(B.B_YIELD,0)=0  then round(nvl(C.MK_YIELD,0),6)
                when nvl(A.B_YIELD,0)=0 then B.B_YIELD
                 else A.B_YIELD END as B_YIELD --行权优先收益率
          from
          (select BEG_DATE,I_CODE,A_TYPE,M_TYPE from ttrd_accounting_secu_obj
          where A_TYPE in('SPT_BD','SPT_ABS','SPT_CB') and REAL_AMOUNT !=0
          group by BEG_DATE,I_CODE,A_TYPE,M_TYPE
          union all
          select BEG_DATE,I_CODE,A_TYPE,M_TYPE from ttrd_accounting_secu_obj_his
          where A_TYPE in('SPT_BD','SPT_ABS','SPT_CB') and REAL_AMOUNT !=0
          group by BEG_DATE,I_CODE,A_TYPE,M_TYPE) O
          left join
         (
         select
     case when nvl(B.TERM,0)=0  then to_char(A.TERM,'fm9990.0000')
          when  nvl(A.TERM,0)>nvl(B.TERM,0)  then to_char(B.TERM,'fm9990.0000')||'+'||to_char((A.TERM-B.TERM),'fm9990.00')
          else  to_char(A.TERM,'fm9990.0000')||'+'||to_char((B.TERM-A.TERM),'fm9990.00')
          end as TERM,--行权剩余期限+到期剩余期限
         A.I_CODE,A.A_TYPE,A.M_TYPE,A.BEG_DATE,A.END_DATE,
        case when nvl(A.TERM,0)>nvl(B.TERM,0) then nvl(A.TERM,0)
          else nvl(B.TERM,0) END as A_TERM ,--到期剩余期限
        case when nvl(B.TERM,0)=0 then nvl(A.TERM,0)
            when  nvl(A.TERM,0)>nvl(B.TERM,0) then nvl(B.TERM,0)
          else nvl(A.TERM,0) END as B_TERM , --优先行权剩余期限

        case when A.TERM>nvl(B.TERM,0) then nvl(A.MODIFIED_D,0)
          else nvl(B.MODIFIED_D,0) END as A_MODIFIED_D ,--到期久期

        case when nvl(B.TERM,0)=0 then nvl(A.MODIFIED_D,0)
          when A.TERM>nvl(B.TERM,0) then nvl(B.MODIFIED_D,0)
          else nvl(A.MODIFIED_D,0) END as B_MODIFIED_D ,  --优先行权久期

       case when A.TERM>nvl(B.TERM,0) then nvl(A.NETPRICE,0)
          else nvl(B.NETPRICE,0) END as A_NETPRICE ,--到期净价

       case when nvl(B.TERM,0)=0 then nvl(A.NETPRICE,0)
         when A.TERM>nvl(B.TERM,0) then nvl(B.NETPRICE,0)
          else nvl(A.NETPRICE,0) END as B_NETPRICE ,  --优先行权净价

       case when A.TERM>nvl(B.TERM,0) then nvl(A.FULLPRICE,0)
          else nvl(B.FULLPRICE,0) END as A_FULLPRICE ,--到期全价

       case when nvl(B.TERM,0)=0 then nvl(A.FULLPRICE,0)
         when A.TERM>nvl(B.TERM,0) then nvl(B.FULLPRICE,0)
          else nvl(A.FULLPRICE,0) END as B_FULLPRICE ,  --优先行权全价

       case when A.TERM>nvl(B.TERM,0) then nvl(A.YIELD,0)
          else nvl(B.YIELD,0) END as A_YIELD ,--到期收益率
       case when nvl(B.TERM,0)=0 then nvl(A.YIELD,0)
         when A.TERM>nvl(B.TERM,0) then nvl(B.YIELD,0)
          else nvl(A.YIELD,0) END as B_YIELD  --优先行权收益率
        from TCB_BOND_EVAL A
        left join
        TCB_BOND_EVAL_UNRECOMMEND B
        on A.I_CODE=B.I_CODE and A.A_TYPE=B.A_TYPE and  A.M_TYPE=B.M_TYPE and A.BEG_DATE=B.BEG_DATE
          ) A
           on O.I_CODE = A.I_CODE
          and O.A_TYPE = A.A_TYPE
          and O.M_TYPE = A.M_TYPE
          and O.BEG_DATE = A.BEG_DATE
          --最新的中债估值
          left join
        (
         select
         A.I_CODE,A.A_TYPE,A.M_TYPE,A.BEG_DATE,A.END_DATE,
        case when nvl(A.TERM,0)>nvl(B.TERM,0) then nvl(A.TERM,0)
          else nvl(B.TERM,0) END as A_TERM ,--到期剩余期限
        case when nvl(B.TERM,0)=0 then nvl(A.TERM,0)
            when  nvl(A.TERM,0)>nvl(B.TERM,0) then nvl(B.TERM,0)
          else nvl(A.TERM,0) END as B_TERM , --优先行权剩余期限

        case when A.TERM>nvl(B.TERM,0) then nvl(A.MODIFIED_D,0)
          else nvl(B.MODIFIED_D,0) END as A_MODIFIED_D ,--到期久期

        case when nvl(B.TERM,0)=0 then nvl(A.MODIFIED_D,0)
          when A.TERM>nvl(B.TERM,0) then nvl(B.MODIFIED_D,0)
          else nvl(A.MODIFIED_D,0) END as B_MODIFIED_D ,  --优先行权久期

       case when A.TERM>nvl(B.TERM,0) then nvl(A.NETPRICE,0)
          else nvl(B.NETPRICE,0) END as A_NETPRICE ,--到期净价

       case when nvl(B.TERM,0)=0 then nvl(A.NETPRICE,0)
         when A.TERM>nvl(B.TERM,0) then nvl(B.NETPRICE,0)
          else nvl(A.NETPRICE,0) END as B_NETPRICE ,  --优先行权净价

       case when A.TERM>nvl(B.TERM,0) then nvl(A.FULLPRICE,0)
          else nvl(B.FULLPRICE,0) END as A_FULLPRICE ,--到期全价

       case when nvl(B.TERM,0)=0 then nvl(A.FULLPRICE,0)
         when A.TERM>nvl(B.TERM,0) then nvl(B.FULLPRICE,0)
          else nvl(A.FULLPRICE,0) END as B_FULLPRICE ,  --优先行权全价

       case when A.TERM>nvl(B.TERM,0) then nvl(A.YIELD,0)
          else nvl(B.YIELD,0) END as A_YIELD ,--到期收益率
       case when nvl(B.TERM,0)=0 then nvl(A.YIELD,0)
         when A.TERM>nvl(B.TERM,0) then nvl(B.YIELD,0)
          else nvl(A.YIELD,0) END as B_YIELD  --优先行权收益率
        from TCB_BOND_EVAL A
        left join
        TCB_BOND_EVAL_UNRECOMMEND B
        on A.I_CODE=B.I_CODE and A.A_TYPE=B.A_TYPE and  A.M_TYPE=B.M_TYPE
        where A.END_DATE='2050-12-31' and B.END_DATE='2050-12-31'
          ) B
          on O.I_CODE = B.I_CODE
          and O.A_TYPE = B.A_TYPE
          and O.M_TYPE = B.M_TYPE
          left join TBSI_IR C
          on O.I_CODE = C.I_CODE
          and O.A_TYPE = C.A_TYPE
          and O.M_TYPE = C.M_TYPE
          and O.BEG_DATE = C.BEG_DATE
/

