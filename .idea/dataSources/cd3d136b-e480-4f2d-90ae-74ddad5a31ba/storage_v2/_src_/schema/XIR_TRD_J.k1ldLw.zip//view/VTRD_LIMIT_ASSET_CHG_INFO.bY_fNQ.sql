create view VTRD_LIMIT_ASSET_CHG_INFO as
  SELECT
           2 AS SRC_TYPE,
               BLC.OBJ_ID AS SRC_ID,
               8 AS OCCUPY_OBJ_TYPE,
               BLC.I_CODE,
               BLC.A_TYPE,
               BLC.M_TYPE,
               INSTR.P_TYPE,
               INSTR.P_CLASS,
               CLS.CLS_CODE,
               CLS.CLS_NAME,
               BLC.SECU_ACCT_ID,
               BLC.EXT_SECU_ACCT_ID,
               AC.CASH_ACCID AS CASH_ACCT_ID,
               NULL AS EXE_CASH_ACCT_ID,
               BLC.TRADE_GRP_ID,
               -BLC.VOLUME AS BLC_SECU_VOLUME_KY,
               INSTR.CURRENCY,
               A.SET_DATE,
               NULL AS ORD_TOTAL_AMOUNT,
              NULL AS ORD_CANCEL_AMOUNT,
              NULL AS ORD_REMAIN_AMOUNT,
              0 AS MOCK_TYPE
          FROM (SELECT A.I_CODE,
                       A.A_TYPE,
                       A.M_TYPE,
                       A.AI_ADJUSTEDDELIVERYDATE AS SET_DATE
                  FROM TBSI_ASSETINFO A
                  WHERE A.AI_EXPIRY = 1
                UNION ALL
                SELECT P.I_CODE,
                       P.A_TYPE,
                       P.M_TYPE,
                       P.PI_PAYMENTDATE AS SET_DATE
                FROM TBSI_PAYMENTINFO P) A
          LEFT JOIN (SELECT
                            BLC1.OBJ_ID,
                            BLC1.I_CODE,
                            BLC1.A_TYPE,
                            BLC1.M_TYPE,
                            BLC1.VOLUME,
                            BLC1.SECU_ACCT_ID,
                            BLC1.EXT_SECU_ACCT_ID,
                            BLC1.TRADE_GRP_ID,
                            COALESCE(BLC2.I_CODE,BLC1.I_CODE) AS P_I_CODE,
                            COALESCE(BLC2.A_TYPE,BLC1.A_TYPE) AS P_A_TYPE,
                            COALESCE(BLC2.M_TYPE,BLC1.M_TYPE) AS P_M_TYPE
                       FROM TTRD_BLC_SECU_OBJ BLC1
                       LEFT JOIN TTRD_BLC_SECU_OBJ BLC2 ON BLC1.P_OBJ_ID =
                                                           BLC2.OBJ_ID
                       WHERE BLC1.BLC_TYPE IN (211,212,221,222,232)
                      ) BLC
                      ON BLC.P_I_CODE = A.I_CODE
                      AND BLC.P_A_TYPE = A.A_TYPE
                      AND BLC.P_M_TYPE = A.M_TYPE

            LEFT JOIN TTRD_ACC_SECU AC
      ON BLC.SECU_ACCT_ID = AC.ACCID

            INNER JOIN TTRD_INSTRUMENT INSTR ON BLC.I_CODE = INSTR.I_CODE
                                         AND BLC.A_TYPE = INSTR.A_TYPE
                                         AND BLC.M_TYPE = INSTR.M_TYPE
            LEFT JOIN TTRD_LIMIT_CLS_CODE CLS ON INSTR(CLS.P_TYPE,
                                                     INSTR.P_TYPE) > 0
           WHERE
               CLS.CLS_CODE = 10
               AND BLC.VOLUME!=0
               AND A.SET_DATE > INSTR.MTR_DATE
           UNION ALL
           SELECT
               T.SRC_TYPE AS SRC_TYPE,
               T.SRC_ID AS SRC_ID,
               T.OCCUPY_OBJ_TYPE AS OCCUPY_OBJ_TYPE,
               T.I_CODE,
               T.A_TYPE,
               T.M_TYPE,
               INSTR.P_TYPE,
               INSTR.P_CLASS,
               CLS.CLS_CODE,
               CLS.CLS_NAME,
               T.SECU_ACCT_ID,
               T.EXT_SECU_ACCT_ID,
               T.CASH_ACCT_ID AS CASH_ACCT_ID,
               NULL AS EXE_CASH_ACCT_ID,
               T.TRADE_GRP_ID,
               -T.BLC_SECU_VOLUME_KY,
               T.CURRENCY,
               T.SET_DATE,
               T.ORD_TOTAL_AMOUNT,
              T.ORD_CANCEL_AMOUNT,
              T.ORD_REMAIN_AMOUNT,
              0 AS MOCK_TYPE
           FROM VTRD_LIMIT_TRADE_INFO T
           INNER JOIN TTRD_INSTRUMENT INSTR ON T.I_CODE = INSTR.I_CODE
                                         AND T.A_TYPE = INSTR.A_TYPE
                                         AND T.M_TYPE = INSTR.M_TYPE
                       LEFT JOIN TTRD_LIMIT_CLS_CODE CLS ON INSTR(CLS.P_TYPE,
                                                     INSTR.P_TYPE) > 0
           WHERE CLS.CLS_CODE = 10
               AND T.BLC_SECU_VOLUME_KY!=0
               AND T.OCCUPY_OBJ_TYPE!=4
               AND T.OPR_STATE<0
/

