create view VTRD_CBGS_TIMESTAMP as
  SELECT 'CBGSINSTR'    AS TIMESTAMPTYPE, --时间戳类型
    MAX(A.UPDATETIME) AS TIMESTAMP --时间戳
FROM TTRD_CBGS_SETTLEBIZ_DETAIL A -- 查询详情返回表
WHERE A.REQUEST_CODE = 'BJ0300'
AND A.IR_STATUS='5'
AND A.BIZTYPE --通用结算指令返回
    IN ('BT01', --现券
        'BT02', --质押式回购
        'BT05', --债券借贷
        'BT06', --质押券置换
        'BT00', --普通分销
        'BT11', --转托管
        'BT03', --买断式回购
        'BT04', --债券远期
        'BT10', --投资人选择提前赎回
        'BT07', --BEPS质押
        'BT08', --BEPS解押
        'BT09', --BEPS质押券置换
        'BT23', --质押式回购到期
        'BT24', --买断式回购到期
        'BT25' --债券借贷到期
        )
UNION
--中债合同
SELECT 'CBGSCTRCT'    AS TIMESTAMPTYPE, --时间戳类型
    MAX(A.UPDATETIME) AS TIMESTAMP --时间戳
FROM TTRD_CBGS_SETTLEBIZ_DETAIL A -- 查询详情返回表
WHERE A.REQUEST_CODE = 'BJ0301'
AND A.IR_STATUS='5'
UNION
--DVP余额
SELECT 'DVPBAL' AS TIMESTAMPTYPE, --时间戳类型
    ''          AS TIMESTAMP --时间戳
FROM DUAL
UNION
--银行余额
SELECT 'BNKBAL' AS TIMESTAMPTYPE, --时间戳类型
    ''          AS TIMESTAMP --时间戳
FROM DUAL




/

