create view V_CAXT_CCSYSF as
  SELECT
    ACC.OBJ_ID,
    ACC.BEG_DATE,
    ACC.ACCNAME,
    ACC.SECU_ACCT_ID,
    ACC.CASH_ACCID,
    ACC.I_CODE,
    ACC.A_TYPE,
    ACC.M_TYPE,
    ACC.DJCS,--债券登记场所 'XSHE','深交所','XSHG','上交所','X_CNBD_QSS','清算所','X_CNBD_ZZD','中债登','基金或场外市场'
    ACC.I_NAME,
    DECODE(ACC.TERM,NULL,'-',0,'-',ACC.TERM)                        AS TERM,
    DECODE(ACC.ZQLX,NULL,'-',0,'-',ACC.ZQLX)                        AS ZQLX,--债券类型
    DECODE(ACC.DQJQ,NULL,'-',0,'-',TO_CHAR(ACC.DQJQ,'fm9990.0000')) AS DQJQ,--到期久期
    DECODE(ACC.XQJQ,NULL,'-',0,'-',TO_CHAR(ACC.XQJQ,'fm9990.0000')) AS XQJQ,--行权久期
    ACC.SFHQ, --是否含权
    DECODE(ACC.XQGZ,NULL,'-',0,'-',TO_CHAR(ACC.XQGZ*100,'fm9990.0000')||'%') AS XQGZ,--行权估值
    DECODE(ACC.DQGZ,NULL,'-',0,'-',TO_CHAR(ACC.DQGZ*100,'fm9990.0000')||'%') AS DQGZ ,--估值到期
    DECODE(ACC.ZJGZ,NULL,'-',0,'-',TO_CHAR(ACC.ZJGZ,'fm999999999990.00'))    AS ZJGZ,--总价估值
    DECODE(ACC.CCSL,NULL,'-',0,'-',TO_CHAR(ACC.CCSL,'fm999999999990.00'))    AS CCSL,--持仓量
    DECODE(ACC.KYSL,NULL,'-',0,'-' ,TO_CHAR(ACC.KYSL,'fm999999999990.00'))   AS KYSL,--可用量
    DECODE(ACC.ZCZB,NULL,'-',0,'-',TO_CHAR(ACC.ZCZB,'fm9990.0000'))          AS ZCZB,--资产占比
    ACC.B_ISSUER_CODE, --发行人代码
    ACC.B_ISSUER,
    TI.SW2,--申万二级行业代码
    TI.SW3,
    TI.SW2_NAME,--申万二级行业
    TI.ZJ2,--证监二级行业代码
    TI.ZJ2_NAME,--证监二级行业
    TI.ZX2,--资讯二级行业代码
    TI.ZX2_NAME,--资讯二级行业
    TR.GRADE             AS ZTPJ,--主体评级
    ER.B_GRADE           AS ZXPJ,--债项评级
    CBC.SCORE            AS NBDF,--内部打分
    CBC.INNER_GRADE_NAME AS NBPJ,--内部评级
    F.FV                 AS NET_FV,
    CASE
        WHEN ACC.ZQLX IN ('并购重组私募债券',
                          '非公开定向债务融资工具',
                          '非公开发行公司债券',
                          '中小企业集合私募债券',
                          '中小企业可交换私募债券',
                          '中小企业私募债券')
        AND ACC.A_TYPE IN ('SPT_BD',
                           'SPT_ABS')
        THEN '非公开'
        WHEN ACC.A_TYPE IN ('SPT_BD',
                            'SPT_ABS')
        THEN '公开'
        ELSE '-'
    END AS SFGK--是否公开发行
FROM
    -----开始前半部分持仓债券相关查询
    (
        SELECT
            A.OBJ_ID,
            A.BEG_DATE,
            C.ACCNAME,
            A.SECU_ACCT_ID,
            A.CASH_ACCID，
            A.I_CODE,
            A.A_TYPE,
            A.M_TYPE,
            decode（T.HOST_MARKET,
            'XSHE',
            '4',
            'XSHG',
            '3',
            'X_CNBD_QSS',
            '1',
            'X_CNBD_ZZD',
            '2',
            '5') AS DJCS,--债券登记场所 'XSHE','深交所','XSHG','上交所','X_CNBD_QSS','清算所','X_CNBD_ZZD','中债登','
    -- 基金或场外市场'
    A.I_NAME,
    E1.TERM,--期限
    A.P_CLASS AS ZQLX,--债券类型
    /*NET_FV,*/
    E1.A_MODIFIED_D AS DQJQ,--到期久期
    E1.B_MODIFIED_D XQJQ,--行权久期
    DECODE(T.B_EMBOPT_TYPE,'0010',1,'0100',1,0)                   AS SFHQ, --是否含权
    E1.B_YIELD                                                    AS XQGZ,--行权估值
    E1.A_YIELD                                                    AS DQGZ,--估值到期
    NVL(A.ASSET_AMOUNT,0)                                         AS ZJGZ,--总价估值
    A.REAL_VOLUME                                                 AS CCSL,--持仓量
    A.REAL_VOLUME +DECODE(B.FREEZE_VOLUME,NULL,0,B.FREEZE_VOLUME) AS KYSL, --可用量
    ROUND(DECODE(VN.ZCJZ,0,0,NVL(A.ASSET_AMOUNT,0)/VN.ZCJZ),4)    AS ZCZB,--资产占比
    T.B_ISSUER_CODE, --发行人代码
    T.B_ISSUER --发行人名称
FROM
    (
        SELECT
            OBJ_ID,
            BEG_DATE,
            SECU_ACCT_ID,
            CASH_ACCID,
            ACCNAME,
            ACCOUNTNAME,
            I_CODE,
            A_TYPE,
            M_TYPE,
            I_NAME,
            P_CLASS,
            ASSET_AMOUNT,
            REAL_VOLUME
        FROM
            V_ACCOUNTING_SECU_OBJ
        WHERE
            A_TYPE NOT IN ('SPT_BD',
                           'SPT_ABS',
                           'SPT_CB')
        AND P_TYPE IN ('0000',
                       '0220',
                       '1100',
                       '0702',
                       '0703',
                       '0704',
                       '0705',
                       '0706')
        AND ASSET_AMOUNT !=0
        AND I_CODE NOT IN('JYSBFJ',
                          'JYSBZJ',
                          'DJK',
                          'XTBZJJ')
        UNION ALL
        SELECT
            OBJ_ID,
            BEG_DATE,
            SECU_ACCT_ID,
            CASH_ACCID,
            ACCNAME,
            ACCOUNTNAME,
            I_CODE,
            A_TYPE,
            M_TYPE,
            I_NAME,
            P_CLASS,
            ASSET_AMOUNT,
            REAL_VOLUME
        FROM
            V_ACCOUNTING_BND_OBJ
        WHERE
            A_TYPE IN ('SPT_BD',
                       'SPT_ABS',
                       'SPT_CB')
        AND P_TYPE IN ('0000',
                       '0220',
                       '1100',
                       '0702',
                       '0703',
                       '0704',
                       '0705',
                       '0706')
        AND ASSET_AMOUNT !=0
        AND I_CODE NOT IN('JYSBFJ',
                          'JYSBZJ',
                          'DJK',
                          'XTBZJJ') ) A
LEFT JOIN
    (
        --冻结数量
        SELECT
            M.BEG_DATE,
            M.SECU_ACCT_ID,
            M.I_CODE,
            M.A_TYPE,
            M.M_TYPE,
            SUM(M.VOLUME) AS FREEZE_VOLUME
        FROM
            (
                SELECT
                    T.BEG_DATE,
                    T.SECU_ACCT_ID,
                    T.EXT_SECU_ACCT_ID,
                    T.VOLUME,
                    T.I_CODE,
                    T.A_TYPE,
                    T.M_TYPE
                FROM
                    TTRD_BLC_SECU_OBJ T
                WHERE
                    T.VOLUME < 0
                UNION ALL
                SELECT
                    T.BEG_DATE,
                    T.SECU_ACCT_ID,
                    T.EXT_SECU_ACCT_ID,
                    T.VOLUME,
                    T.I_CODE,
                    T.A_TYPE,
                    T.M_TYPE
                FROM
                    TTRD_BLC_SECU_OBJ_HIS T
                WHERE
                    T.VOLUME < 0 ) M
        GROUP BY
            M.BEG_DATE,
            M.SECU_ACCT_ID,
            M.I_CODE,
            M.A_TYPE,
            M.M_TYPE )B
ON
    A.I_CODE=B.I_CODE
AND A.A_TYPE=B.A_TYPE
AND A.M_TYPE=B.M_TYPE
AND A.SECU_ACCT_ID=B.SECU_ACCT_ID
AND A.BEG_DATE=B.BEG_DATE
LEFT JOIN
    (
        --资产净值和单位净值
        SELECT
            BEG_DATE,
            CASH_ACCID,
            CP_AMOUNT   AS ZCJZ,
            UNIT_CP_NAV AS DWJZ
        FROM
            V_UNIT_NAV ) VN
ON
    A.CASH_ACCID=VN.CASH_ACCID
AND A.BEG_DATE=VN.BEG_DATE
LEFT JOIN
    TTRD_ACC_CASH C
ON
    A.CASH_ACCID = C.ACCID
    --中债估值相关,对于转债没有中债估值
LEFT JOIN
    (
        SELECT
            A.I_CODE,
            A.A_TYPE,
            A.M_TYPE,
            A.BEG_DATE,
            A.END_DATE,
            CASE
                WHEN B.TERM IS NULL
                THEN TO_CHAR(A.TERM,'fm9990.0000')
                WHEN A.TERM>NVL(B.TERM,0)
                THEN TO_CHAR(B.TERM,'fm9990.0000')||'+'||TO_CHAR((A.TERM-B.TERM),'fm9990.00')
                ELSE TO_CHAR(A.TERM,'fm9990.0000')||'+'||TO_CHAR((B.TERM-A.TERM),'fm9990.00')
            END AS TERM,--行权剩余期限+到期剩余期限
            CASE
                WHEN A.TERM>NVL(B.TERM,0)
                THEN NVL(B.TERM,0)
                ELSE NVL(A.TERM,0)
            END AS B_TERM , --行权剩余期限
            CASE
                WHEN A.TERM>NVL(B.TERM,0)
                THEN NVL(A.TERM,0)
                ELSE NVL(B.TERM,0)
            END AS A_TERM ,--到期剩余期限
            CASE
                WHEN A.TERM>NVL(B.TERM,0)
                THEN NVL(A.MODIFIED_D,0)
                ELSE NVL(B.MODIFIED_D,0)
            END AS A_MODIFIED_D ,--到期久期
            CASE
                WHEN A.TERM>NVL(B.TERM,0)
                THEN NVL(B.MODIFIED_D,0)
                ELSE NVL(A.MODIFIED_D,0)
            END AS B_MODIFIED_D , --行权久期
            CASE
                WHEN A.TERM>NVL(B.TERM,0)
                THEN NVL(A.FULLPRICE,0)
                ELSE NVL(B.FULLPRICE,0)
            END AS A_FULLPRICE ,--到期全价
            CASE
                WHEN A.TERM>NVL(B.TERM,0)
                THEN NVL(B.FULLPRICE,0)
                ELSE NVL(A.FULLPRICE,0)
            END AS B_FULLPRICE , --行权全价
            CASE
                WHEN A.TERM>NVL(B.TERM,0)
                THEN NVL(A.YIELD,0)
                ELSE NVL(B.YIELD,0)
            END AS A_YIELD ,--到期收益率
            CASE
                WHEN A.TERM>NVL(B.TERM,0)
                THEN NVL(B.YIELD,0)
                ELSE NVL(A.YIELD,0)
            END AS B_YIELD --行权收益率
        FROM
            TCB_BOND_EVAL A
        LEFT JOIN
            TCB_BOND_EVAL_UNRECOMMEND B
        ON
            A.I_CODE=B.I_CODE
        AND A.A_TYPE=B.A_TYPE
        AND A.M_TYPE=B.M_TYPE
        AND A.BEG_DATE=B.BEG_DATE ) E1
ON
    A.I_CODE = E1.I_CODE
AND A.A_TYPE = E1.A_TYPE
AND A.M_TYPE = E1.M_TYPE
AND A.BEG_DATE=E1.BEG_DATE
LEFT JOIN
    TBND T
ON
    A.I_CODE = T.I_CODE
AND A.A_TYPE=T.A_TYPE
AND A.M_TYPE=T.M_TYPE ) ACC
--结束持仓数据查询
LEFT JOIN
--发行人行业
(
    SELECT
        CASE
            WHEN A.COMP_CODE IS NULL
            AND B.COMP_CODE IS NULL
            THEN C.COMP_CODE
            WHEN A.COMP_CODE IS NULL
            AND C.COMP_CODE IS NULL
            THEN B.COMP_CODE
            WHEN B.COMP_CODE IS NULL
            AND C.COMP_CODE IS NULL
            THEN A.COMP_CODE
            ELSE A.COMP_CODE
        END               AS COMP_CODE,
        A.INDUSTRY_CODE_2 AS SW2,
        A.INDUSTRY_CODE_3 AS SW3,
        A.NAME            AS SW2_NAME,
        B.INDUSTRY_CODE_2 AS ZJ2,
        B.NAME            AS ZJ2_NAME,
        C.INDUSTRY_CODE_2 AS ZX2,
        C.NAME            AS ZX2_NAME
    FROM
        (
            SELECT
                *
            FROM
                TCOMPANY_INDUSTRY A --申万行业分类
            LEFT JOIN
                TINDUSTRY_CLASS TC1
            ON
                A.INDUSTRY_CODE_2 = TC1.CODE
            WHERE
                A.INDUSTRY_SOURCE = 'SW14'
            AND A.END_DATE = '2050-12-31'
            AND TC1.SOURCE = 'SW14') A
    FULL JOIN
        (
            SELECT
                *
            FROM
                TCOMPANY_INDUSTRY B --证监会行业分类
            LEFT JOIN
                TINDUSTRY_CLASS TC2
            ON
                B.INDUSTRY_CODE_2 = TC2.CODE
            WHERE
                B.INDUSTRY_SOURCE = 'SAC12'
            AND B.END_DATE = '2050-12-31'
            AND TC2.SOURCE = 'SAC12') B
    ON
        A.COMP_CODE = B.COMP_CODE
    FULL JOIN
        (
            SELECT
                *
            FROM
                TCOMPANY_INDUSTRY C --衡泰资讯行业分类
            LEFT JOIN
                TINDUSTRY_CLASS TC3
            ON
                C.INDUSTRY_CODE_2 = TC3.CODE
            WHERE
                C.INDUSTRY_SOURCE = 'xQuantdata(integrate)'
            AND C.END_DATE = '2050-12-31'
            AND TC3.SOURCE = 'xQuantdata(integrate)') C
    ON
        B.COMP_CODE = C.COMP_CODE ) TI ON ACC.B_ISSUER_CODE = TI.COMP_CODE LEFT JOIN
(
    SELECT
        *
    FROM
        TCOMPANY_RATING
    WHERE
        END_DATE='2050-12-31') TR --主体评级
ON ACC.B_ISSUER = TR.COMP_NAME LEFT JOIN TTRD_CAT_BONDCREDIT CBC --取内部评分
ON ACC.I_CODE= CBC.I_CODE
AND
ACC.A_TYPE=CBC.A_TYPE
AND
ACC.M_TYPE=CBC.M_TYPE LEFT JOIN
(
    SELECT
        P.I_CODE,
        P.A_TYPE,
        P.M_TYPE,
        I.NODE_NAME
    FROM
        TTRD_BOND_POOL P
    LEFT JOIN
        TREE_NODE_INFO I
    ON
        P.TREE_ID = I.NODE_ID
    AND I.TREE_CODE = 'BONDPOOL'
    WHERE
        I.PARENT_ID=67 ) TBP--内部评级
ON ACC.I_CODE = TBP.I_CODE
AND
ACC.A_TYPE = TBP.A_TYPE
AND
ACC.M_TYPE = TBP.M_TYPE LEFT JOIN
(
    SELECT
        *
    FROM
        TBND_EXT_RATING
    WHERE
        END_DATE='2050-12-31') ER --债券评级
ON ACC.I_CODE=ER.I_CODE
AND
ACC.A_TYPE=ER.A_TYPE
AND
ACC.M_TYPE=ER.M_TYPE LEFT JOIN
(
    SELECT
        *
    FROM
        V_TP_INSTRUMENT_IMP_FV
    WHERE
        END_DATE='2050-12-31') F ON ACC.I_CODE=F.I_CODE
AND
ACC.A_TYPE= F.A_TYPE
AND
ACC.M_TYPE= F.M_TYPE
/

