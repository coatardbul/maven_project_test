create view VREPO_FIXING as
  SELECT NULL AS I_CODE,
    NULL    AS A_TYPE,
    NULL    AS M_TYPE,
    NULL    AS RATE
FROM DUAL




/

