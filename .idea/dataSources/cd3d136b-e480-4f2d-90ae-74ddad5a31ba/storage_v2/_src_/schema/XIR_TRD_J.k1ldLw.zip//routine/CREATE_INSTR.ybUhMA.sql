create PROCEDURE             "CREATE_INSTR"(p_sysordid NUMBER)
is
  v_par_value ttrd_instrument.par_value%type;
  v_cgbs ttrd_cbgs_settlebiz_detail%rowtype;
  v_ins_ext ttrd_set_instruction_exe%rowtype;
  v_cbgs_bond ttrd_cbgs_bond%rowtype;
  v_trade ttrd_otc_trade%rowtype;
  t_varchar varchar(50);
begin
  select * into v_trade from ttrd_otc_trade where sysordid = p_sysordid;
  --序号
  select S_AUTOINC_CBGS_CID.Nextval into v_cgbs.cid from dual;
  --操作人
  v_cgbs.IR_OPERATOR:='';
  --操作时间
  v_cgbs.IR_OPERATOR_TIME:='';
  --操作状态
  v_cgbs.IR_STATUS:='';
  --报文版本标识号
  v_cgbs.VRSNID:='01';
  --发送方标识
  v_cgbs.SNDRID:='0000007798';
  --发送方系统标识号
  v_cgbs.SNDRSYSID:='DS';
  --接收方标识
  v_cgbs.RCVRID:='0000001411';
  --接收系统标识
  v_cgbs.RCVRSYSID:='DI';
  --报文原始发起人
  v_cgbs.MSG_ORGNLSNDR:='0000007798';
  --报文最终接收人
  v_cgbs.MSG_FNLRCVR:='0000001411';
  --报文发起时间
  v_cgbs.MSG_SND_DATETIME:='2014-03-28T175005.46';
  --报文类型
  v_cgbs.MSG_TYPE:='CSBS.002.001.01';
  --报文标识号
  v_cgbs.MSG_ID:='00000077982011113000151464';
  --报文参考号
  v_cgbs.MSG_REFID:='00000077982011113000151464';
  --报文校验值
  v_cgbs.MSG_BODY_CHCKSUM:='NULLL';
  --结算成员签名
  v_cgbs.STTLMMMBSGNTR:='';
  --CSBS签名
  v_cgbs.CSBS_SGNTR:='';
  --交易流水标识
  select to_char(systimestamp,'YYYYMMDDHH24MISSFF3') into v_cgbs.TXFLOWID from dual;
  --经办人
  v_cgbs.OPERATOR:='';
  --复核人
  v_cgbs.CHECKER:='';
  --优先级
  v_cgbs.PRIORITY:='PT01';
  --报文创建时间
  select to_char(sysdate,'YYYY-MM-DD HH24:MI') into v_cgbs.CREATE_DATE from dual;
  --请求类别码 BJ0300 指令查询  BJ0301  合同查询
  v_cgbs.REQUEST_CODE:='BJ0300';
  --操作码 OS00：创建 OS01：确认;OS02：拒绝;OS03：批量;OS04：详情;OS05：付券方确认;OS06：收券方确认;OS07: 总对账单;OS08:明细对账单
  v_cgbs.OPERATOR_CODE:='OS04';
  --结算指令来源IO00：国债公司中心应急端IO01：成员客户端IO02：公开市场系统IO03：第三方外汇交易中心IO04：柜台系统
  v_cgbs.INSTR_ORIGIN:='IO01';
  --业务类别 BT01：现券
  v_cgbs.BIZTYPE:='BT01';
  --结算指令标识
  select substr(('00000000000'||abs(dbms_random.random())),-11) into v_cgbs.INSTR_ID from dual;

  select t.exhacc,t.accname
  into v_cgbs.accid,v_cgbs.accname
  from ttrd_acc_secu_ext t where accid = v_trade.secu_ext_accid;

  if substr(v_trade.trdtype,-1)='0' then
    --付券方账户编号
    v_cgbs.GIV_ACC_ID:=v_trade.partyid;
    --付券方账户名称
    select i_name into v_cgbs.GIV_ACC_NAME from ttrd_institution where i_id = v_trade.partyid;
    --收券方账户编号
    v_cgbs.TAK_ACC_ID:=v_cgbs.accid;
    --收券方账户名称
    v_cgbs.TAK_ACC_NAME:=v_cgbs.accname;
  else
    --付券方账户编号
    v_cgbs.GIV_ACC_ID:=v_cgbs.accid;
    --付券方账户名称
    v_cgbs.GIV_ACC_NAME:=v_cgbs.accname;
    --收券方账户编号
    v_cgbs.TAK_ACC_ID:=v_trade.partyid;
    --收券方账户名称
    select i_name into v_cgbs.TAK_ACC_NAME from ttrd_institution where i_id = v_trade.partyid;
  end if;


  --结算方式1ST00：纯券过户（FOP）ST01：见款付券（DAP）ST02：见券付款（PAD）ST03：券款对付（DVP）
  v_cgbs.SETTLEMENT1:='ST01';
  v_cgbs.SETTLEMENT2:='';
  --债券代码
  v_cgbs.I_CODE1:=v_trade.i_code;
  --ISIN编码
  v_cgbs.ISIN1:='';
  --资产类型
  v_cgbs.A_TYPE1:=v_trade.a_type;
  --市场类型
  v_cgbs.M_TYPE1:=v_trade.m_type;
  --债券简称
  v_cgbs.I_NAME1:=v_trade.i_name;
  --券面总额
  select par_value into v_par_value from ttrd_instrument
  where i_code=v_trade.i_code and a_type =v_trade.a_type and m_type = v_trade.m_type;
  v_cgbs.TRDFV1:=v_trade.ordcount/10000;
  --债券质押率
  v_cgbs.BD_COLL_RATE1:='0.000000';
  --应计利息
  v_cgbs.AI1:=v_trade.bnd_aiamount/v_trade.ordcount;
  --
  v_cgbs.S_TRDFV1:=v_cgbs.TRDFV1;
  v_cgbs.S_BD_COLL_RATE1:='';
  v_cgbs.S_AI1:=v_cgbs.ai1;
  v_cgbs.AI_DATE1:=v_trade.setdate;

  v_cgbs.PRICE1_1:=v_trade.bnd_netprice;
  v_cgbs.PRICE1_2:=v_trade.ordprice;
  v_cgbs.S_PRICE1_1:=v_cgbs.PRICE1_1;
  v_cgbs.S_PRICE1_2:=v_cgbs.PRICE1_2;
  v_cgbs.I_CODE2:='';
  v_cgbs.ISIN2:='';
  v_cgbs.A_TYPE2:='';
  v_cgbs.M_TYPE2:='';
  v_cgbs.I_NAME2:='';
  v_cgbs.TRDFV2:='0.000000';
  v_cgbs.BD_COLL_RATE2:='0.000000';
  v_cgbs.AI2:='0.000000000000';
  v_cgbs.S_TRDFV2:='';
  v_cgbs.S_BD_COLL_RATE2:='';
  v_cgbs.S_AI2:='';
  v_cgbs.AI_DATE2:='';
  v_cgbs.PRICE2_1:='0.00000000';
  v_cgbs.PRICE2_2:='0.00000000';
  v_cgbs.S_PRICE2_1:='';
  v_cgbs.S_PRICE2_2:='';
  --金额
  v_cgbs.AMOUNT1:=v_trade.ordamount-v_trade.bnd_aiamount;
  v_cgbs.AMOUNT2:=v_trade.ordamount;
  v_cgbs.AMOUNT3:=v_trade.bnd_aiamount;
  v_cgbs.AMOUNT4:='0.000000';
  v_cgbs.FV_TOTALAMT:='0.000000';
  v_cgbs.RATE:='0.000000';
  v_cgbs.S_AMOUNT1:=v_cgbs.amount1;
  v_cgbs.S_AMOUNT2:=v_cgbs.amount2;
  v_cgbs.S_AMOUNT3:=v_cgbs.amount3;
  v_cgbs.S_AMOUNT4:='';
  v_cgbs.S_FV_TOTALAMT:='';
  v_cgbs.S_RATE:='';
  v_cgbs.TERMS:='';
  v_cgbs.DATE1:=v_trade.setdate;
  v_cgbs.DATE2:='';
  v_cgbs.SG_TYPE1:='';
  v_cgbs.SG_I_CODE1:='';
  v_cgbs.SG_ISIN1:='';
  v_cgbs.SG_I_NAME1:='';
  v_cgbs.SG_TRDFV1:='0.000000';
  v_cgbs.SG_RATE1:='0.000000';
  v_cgbs.S_SG_TRDFV1:='';
  v_cgbs.S_SG_RATE1:='';
  v_cgbs.SG_CASH1:='';
  v_cgbs.SG_AMOUNT1:='0.000000';
  v_cgbs.S_SG_AMOUNT1:='';
  v_cgbs.SG_TYPE2:='';
  v_cgbs.SG_I_CODE2:='';
  v_cgbs.SG_ISIN2:='';
  v_cgbs.SG_I_NAME2:='';
  v_cgbs.SG_TRDFV2:='0.000000';
  v_cgbs.SG_RATE2:='0.000000';
  v_cgbs.S_SG_TRDFV2:='';
  v_cgbs.S_SG_RATE2:='';
  v_cgbs.SG_CASH2:='';
  v_cgbs.SG_AMOUNT2:='0.000000';
  v_cgbs.S_SG_AMOUNT2:='';
  v_cgbs.ORIGIN_INSTR_ID:='';
  v_cgbs.ORIGIN_CTRCT_ID:='';
  v_cgbs.CT_NAME:='';
  v_cgbs.CT_OUT_ACC_ID:='';
  v_cgbs.CT_OUT_ACC_NAME:='';
  v_cgbs.CT_IN_ACC_ID:='';
  v_cgbs.CT_IN_ACC_NAME:='';
  v_cgbs.TXID:=v_trade.extordid;
  --内部经办人
  v_cgbs.OPERATOR2:='admin';
  --内部复核人
  v_cgbs.CHECKER2:='admin';
  --确认人
  v_cgbs.CONFIRMOR:='';
  v_cgbs.GIV_NAME:='';
  v_cgbs.GIV_ID:='';
  v_cgbs.GIV_TYPE:='';
  v_cgbs.TAK_NAME:='';
  v_cgbs.TAK_ID:='';
  v_cgbs.TAK_TYPE:='';
  --指令处理状态 IS00：成功  IS01：待复核 IS02：已复核 IS03：待确认 IS04：已确认 IS05：合法 IS06：非法 IS07：作废 IS08：撤销
  v_cgbs.INSTR_STATUS:='IS00';
  --指令处理结果返回码
  v_cgbs.INSTR_RESULT_CODE:='BJ000000';
  v_cgbs.INSTR_INFO:='';
  v_cgbs.INITIATOR_CONFIRM:='';
  v_cgbs.CP_CONFIRM:='';
  v_cgbs.CTRCT_ID1:='';
  v_cgbs.CTRCT_STATUS1:='CS00';
  v_cgbs.CTRCT_BLOCK_STATUS1:='';
  v_cgbs.CTRCT_FAILED1:='';
  v_cgbs.LAST_UPDATE_TIME1:='';
  v_cgbs.CTRCT_RESULT_CODE1:='';
  v_cgbs.CTRCT_RESULT_INFO1:='';
  v_cgbs.CTRCT_ID2:='';
  v_cgbs.CTRCT_STATUS2:='';
  v_cgbs.CTRCT_BLOCK_STATUS2:='';
  v_cgbs.CTRCT_FAILED2:='';
  v_cgbs.LAST_UPDATE_TIME2:='';
  v_cgbs.CTRCT_RESULT_CODE2:='';
  v_cgbs.CTRCT_RESULT_INFO2:='';
  v_cgbs.EXEC_DATE:='';
  v_cgbs.CASH_SETTLE_DIRECTION:='';
  v_cgbs.CASH_SETTLE_AMT:='';
  v_cgbs.S_CASH_SETTLE_AMT:='';
  v_cgbs.ERRORCODE:='0';
  v_cgbs.ERRORMSG:='';
  --本方账户名称
  --v_cgbs.ACCID:='A0074000001';
  --v_cgbs.ACCNAME:='';
  v_cgbs.XTNSN1:='';
  v_cgbs.XTNSN2:='';
  v_cgbs.XTNSN3:='';
  v_cgbs.XTNSN4:='';
  v_cgbs.XTNSN5:='';
  v_cgbs.XTNSN6:='';
  select S_AUTOINC_CBGS_CID.Nextval into v_cgbs.ACTION from dual;
  select to_char(systimestamp,'YYYYMMDDHH24MISSFF3') into v_cgbs.SERIALNO from dual;
  select to_char(sysdate,'YYYY-MM-DD HH24:MI:SS') into v_cgbs.UPDATETIME from dual;
  v_cgbs.FILENAME:='';

  insert into ttrd_cbgs_settlebiz_detail values v_cgbs;

  --插入外部指令表
  --v_ins_ext.instr_id:=   v_cgbs.instr_id;
  --select S_AUTOINC_CBGS_CID.Nextval into v_ins_ext.exe_id from dual;
  --v_ins_ext.opr_status := 1;
  --insert into ttrd_set_instruction_exe values v_ins_ext;

  v_cbgs_bond.cid := v_cgbs.cid;
  v_cbgs_bond.flag := '1';
  v_cbgs_bond.row_id := '0';
  v_cbgs_bond.i_code := v_cgbs.i_code1;
  v_cbgs_bond.a_type := v_cgbs.a_type1;
  v_cbgs_bond.m_type := v_cgbs.m_type1;
  v_cbgs_bond.i_name := v_cgbs.i_name1;
  v_cbgs_bond.trdfv := v_cgbs.trdfv1;
  v_cbgs_bond.ai := v_cgbs.ai1;
  v_cbgs_bond.price1 :=v_cgbs.PRICE1_1;
  v_cbgs_bond.price2 :=v_cgbs.PRICE1_2;
  v_cbgs_bond.s_trdfv := v_cgbs.trdfv1;
  v_cbgs_bond.s_ai := v_cgbs.ai1;
  v_cbgs_bond.s_price1 := v_cgbs.PRICE1_1;
  v_cbgs_bond.s_price2 := v_cgbs.PRICE1_2;
  insert into ttrd_cbgs_bond values v_cbgs_bond;


  --插入合同
  select S_AUTOINC_CBGS_CID.Nextval into v_cgbs.cid from dual;
  --请求类别码 BJ0300 指令查询  BJ0301  合同查询
  v_cgbs.REQUEST_CODE:='BJ0301';
  insert into ttrd_cbgs_settlebiz_detail values v_cgbs;

  v_cbgs_bond.cid := v_cgbs.cid;
  insert into ttrd_cbgs_bond values v_cbgs_bond;
end create_instr;




/

