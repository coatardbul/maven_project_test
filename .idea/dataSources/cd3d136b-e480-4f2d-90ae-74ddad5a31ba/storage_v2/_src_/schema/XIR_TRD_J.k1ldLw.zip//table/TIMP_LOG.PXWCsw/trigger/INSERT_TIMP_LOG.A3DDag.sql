create trigger INSERT_TIMP_LOG
  before insert
  on TIMP_LOG
  for each row
  BEGIN
    select S_TIMP_LOG.nextval into :NEW.SERIAL_NO from dual;
END;















/

