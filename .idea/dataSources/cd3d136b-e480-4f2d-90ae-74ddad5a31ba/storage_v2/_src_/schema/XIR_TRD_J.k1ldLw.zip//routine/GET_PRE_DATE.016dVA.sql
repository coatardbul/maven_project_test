create function "GET_PRE_DATE"
RETURN VARCHAR2
IS
  return_date varchar2(10);
begin
  select TO_CHAR(TO_DATE(CURR_DATE, 'yyyy-MM-dd') - 1, 'yyyy-MM-dd') into return_date from
      TTRD_TSK_CURRDATE;
  return return_date;
end;
/

