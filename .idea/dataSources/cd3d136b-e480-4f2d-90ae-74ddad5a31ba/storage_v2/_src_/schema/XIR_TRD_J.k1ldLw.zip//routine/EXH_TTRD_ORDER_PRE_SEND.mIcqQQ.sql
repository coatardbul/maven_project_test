create PROCEDURE EXH_TTRD_ORDER_PRE_SEND(
                                                     P_ORDIDS    IN VARCHAR2,  --传入委托编号字符串
                                                     PO_TOSENDIDS OUT VARCHAR2 --返回需要发送的
                                                     ) AS
    /*
     1） 检查委托的状态是否为“待报”，否则不发送该笔委托；
     2） 然后修改委托的状态为“正报”；
    注：第1、2步要在一个存储过程里实现，减少数据库的操作次数，考虑应用服务集群或多线程的情况，可能存在对同一笔委托发送的情况，需要对这些委托记录加锁，以免重复发送委托。

    3）  发送委托到MQ，如果发送失败，则修改委托的状态为“废单”。
     */

  TYPE TYPE_TABLE_EXH_ORDER_ID IS TABLE OF NUMBER(16) INDEX BY BINARY_INTEGER;

  TMP_EXH_ORDER_TABLE TYPE_TABLE_EXH_ORDER_ID;

  SQL_TEXT VARCHAR2(6000);

  I NUMBER DEFAULT 1;
BEGIN

    PO_TOSENDIDS := '';

    -- 锁住“待报”的委托记录，并拷贝到表变量中
    SQL_TEXT := 'SELECT SYSORDID FROM TTRD_EXH_ORDER WHERE ORDSTATUS = 0 AND SYSORDID IN (' || P_ORDIDS || ') FOR UPDATE';
    execute immediate SQL_TEXT bulk collect into TMP_EXH_ORDER_TABLE;

    -- 修改委托状态为“正报”
    SQL_TEXT := 'UPDATE TTRD_EXH_ORDER SET ORDSTATUS = 1 WHERE ORDSTATUS = 0 AND SYSORDID IN (' || P_ORDIDS || ')';
    execute immediate SQL_TEXT;

    -- 返回需要发送的委托
    FOR I IN 1..TMP_EXH_ORDER_TABLE.COUNT LOOP
        IF I = 1 THEN
           PO_TOSENDIDS := TMP_EXH_ORDER_TABLE(I);
        ELSE
           PO_TOSENDIDS := PO_TOSENDIDS || ',' || TMP_EXH_ORDER_TABLE(I);
        END IF;
    END LOOP;
END;
/

