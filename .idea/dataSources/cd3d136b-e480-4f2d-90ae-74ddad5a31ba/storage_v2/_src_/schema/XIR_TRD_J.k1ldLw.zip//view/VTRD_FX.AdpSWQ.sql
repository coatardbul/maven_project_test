create view VTRD_FX as
  SELECT T1.I_CODE,
       T1.A_TYPE,
       T1.M_TYPE,
       T1.I_NAME,
       T2.B_CURR,
       T2.Q_CURR,
       T2.Q_TYPE,
       T2.SETTLE_DAYS,
       T2.SETTLE_BIZDAY_CONV,
       T2.B_FACTOR,
       T1.P_CLASS,
       T1.P_TYPE,
       T2.S_TYPE,
       T2.CLEARING_CALENDAR,
       T2.CLEARING_CURR,
       '3' AS TRADABLE_TYPE,
       '' AS PIPE_ID,
       '' AS IMP_DATE,
       '' AS IMP_TIME
  FROM TTRD_INSTRUMENT T1
 INNER JOIN TFX T2
    ON T1.CURRENCY = T2.B_CURR
   AND T1.Q_CURRENCY = T2.Q_CURR
   AND T1.P_TYPE IN ('1302')




/

