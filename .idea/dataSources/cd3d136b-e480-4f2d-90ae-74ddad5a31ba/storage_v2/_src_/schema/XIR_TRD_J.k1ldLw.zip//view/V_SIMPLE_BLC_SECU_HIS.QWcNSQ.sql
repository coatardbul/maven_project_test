create view V_SIMPLE_BLC_SECU_HIS as
  SELECT MAX(OBJ_ID) AS OBJ_ID,
    SECU_ACCT_ID,
    EXT_SECU_ACCT_ID,
    BLC_TYPE,
    I_CODE,
    A_TYPE,
    M_TYPE,
    BEG_DATE,
    SET_DATE,
    TRADE_GRP_ID,
    SUM(VOLUME) AS VOLUME,
    SUM(NEXT_VOLUME) AS NEXT_VOLUME
FROM (
     SELECT A.OBJ_ID,
            A.SECU_ACCT_ID,
            A.EXT_SECU_ACCT_ID,
            A.BLC_TYPE,
            A.I_CODE,
            A.A_TYPE,
            A.M_TYPE,
            A.BEG_DATE,
            CASE
                WHEN A.SET_DATE = '1900-01-01'
                THEN A.BEG_DATE
                ELSE A.SET_DATE
            END SET_DATE,
            A.TRADE_GRP_ID,
            A.VOLUME,
            SUM(CASE WHEN A.SET_DATE = TO_CHAR(TO_DATE(A.BEG_DATE,'yyyy-MM-dd') + 1,'yyyy-MM-dd')
                     THEN A.VOLUME
                     ELSE 0 END) OVER(PARTITION BY A.I_CODE,A.A_TYPE,A.M_TYPE,A.SECU_ACCT_ID,A.EXT_SECU_ACCT_ID,A.BEG_DATE,A.BLC_TYPE) AS NEXT_VOLUME
       FROM TTRD_BLC_SECU_OBJ_HIS A
               )
WHERE SET_DATE = BEG_DATE
GROUP BY SECU_ACCT_ID,
    EXT_SECU_ACCT_ID,
    BLC_TYPE,
    I_CODE,
    A_TYPE,
    M_TYPE,
    BEG_DATE,
    SET_DATE,
    TRADE_GRP_ID
/

