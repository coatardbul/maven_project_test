create view VDED_INFO as
  SELECT C.I_CODE,
    C.A_TYPE,
    C.M_TYPE,
    C.CURRENCY,
    C.EXT_CASH_ACCT_ID,
    C.START_DATE,
    C.PAY_FREQ,
    C.PAY_MONTH,
    C.PAY_DAY,
    C.DAYCOUNT,
    C.PAYMENT_BIZ_CONV,
    C.CALC_BIZ_CONV,
    C.COMPOUNDING_METHOD,
    C.CALENDAR_CODE,
    A.P_TYPE,
    A.P_CLASS,
    CASE
        WHEN TO_DATE(COALESCE(C.MTR_DATE,'2099-12-31'),'YYYY-MM-DD')-TO_DATE(CURR_DATE,'YYYY-MM-DD'
            )<365
        THEN C.MTR_DATE
        ELSE TO_CHAR(TO_DATE(CURR_DATE,'YYYY-MM-DD')+365,'YYYY-MM-DD')
    END AS MTR_DATE,
    PRINCIPAL_FINAL_EXCHANGE,
    NULL,
    NULL AS MTRDATE_BIZ_CONV,
    NULL AS FST_PAY_DATE,
    NULL AS S_TYPE,
    NULL AS RATE_FIXING_OFFSET
FROM TTRD_INSTRUMENT A,
    TTRD_CURRDATE B,
    (SELECT ACCID||
            '_' ||
                CURRENCY AS I_CODE,
            'SPT_DED'    AS A_TYPE,
            A.MARKETS    AS M_TYPE,
            CURRENCY,--币种
            ACCID     AS EXT_CASH_ACCT_ID,
            OPEN_DATE AS START_DATE,--  起息日
            CASE
                WHEN PAYMENT_FREQ IS NULL
                THEN '3M'
                WHEN PAYMENT_FREQ ='-1'
                THEN '0D'
                ELSE PAYMENT_FREQ
            END AS PAY_FREQ,--支付频率
            CASE
                WHEN PAY_MONTH IS NULL
                THEN 3
                ELSE PAY_MONTH
            END AS PAY_MONTH,
            CASE
                WHEN PAY_DAY IS NULL
                THEN 21
                ELSE PAY_DAY
            END          AS PAY_DAY,
            'ACTUAL/360' AS DAYCOUNT,--计息天数基准
            --'Unadjusted' AS BIZ_CONV, --支付日调整规则
            'Unadjusted' AS PAYMENT_BIZ_CONV, --表示支付调整规则
            'Unadjusted' AS CALC_BIZ_CONV, --表示计息调整规则
            --'REAL_DED' AS P_TYPE,
            0          AS COMPOUNDING_METHOD,
            'CHINA_IB' AS CALENDAR_CODE,--支付日历
            -- '0300' AS P_TYPE,
            -- '活期存款' AS P_CLASS,--产品类型
            '2099-12-31' AS MTR_DATE,
            0            AS PRINCIPAL_FINAL_EXCHANGE
       FROM TTRD_ACC_CASH_EXT A
  UNION ALL
        --每日开放理财产品
     SELECT A.I_CODE,
            A.A_TYPE,
            A.M_TYPE,
            B.CURRENCY,
            NULL AS EXT_CASH_ACCT_ID,
            A.START_DATE,
            A.PAYMENT_FREQ AS PAY_FREQ,
            A.PAY_MONTH,
            A.PAY_DAY,
            A.DAYCOUNT,
            --A.PAYMENT_CONV AS BIZ_CONV,
            A.PAYMENT_CONV AS PAYMENT_BIZ_CONV, --表示支付调整规则
            CASE
                WHEN A.IS_ACCRUAL_BY_PAYMENT=1
                THEN A.PAYMENT_CONV
                ELSE 'Unadjusted'
            END        AS CALC_BIZ_CONV, --表示计息调整规则
            0          AS COMPOUNDING_METHOD,
            'CHINA_IB' AS CALENDAR_CODE,
            -- A.P_TYPE,
            -- '理财产品' AS P_CLASS,
            A.MTR_DATE,
            1 AS PRINCIPAL_FINAL_EXCHANGE
       FROM TTRD_WMPS_DEFINE A
 INNER JOIN TTRD_INSTRUMENT B
         ON A.I_CODE=B.I_CODE
        AND A.A_TYPE=B.A_TYPE
        AND A.M_TYPE=B.M_TYPE
        AND A.A_TYPE='SPT_DED'
  UNION ALL --理财产品费用 --按产品设置
     SELECT FEE.I_CODE,
            FEE.A_TYPE,
            FEE.M_TYPE,
            UNIT.CURRENCY,
            NULL AS EXT_CASH_ACCT_ID,
            FEE.START_DATE,
            FEE.PAY_FREQ,
            FEE.PAY_MONTH,
            FEE.PAY_DAY,
            FEE.DAYCOUNT,
            --FEE.BIZ_CONV,
            FEE.BIZ_CONV      AS PAYMENT_BIZ_CONV, --表示支付调整规则
            FEE.CALC_BIZ_CONV AS CALC_BIZ_CONV, --表示计息调整规则
            0                 AS COMPOUNDING_METHOD,
            'CHINA_IB'        AS CALENDAR_CODE,
            -- '0302' AS P_TYPE,
            -- '理财费用' AS P_CLASS,
            CASE
                WHEN FEE.TOGETHER_MTR='1'
                THEN DF.MTR_DATE
                ELSE '2099-12-31'
            END AS MTR_DATE,
            0   AS PRINCIPAL_FINAL_EXCHANGE
       FROM TTRD_WMPS_FEE FEE ,
            (
        SELECT TO_CHAR(UNIT_ID) AS UNIT_ID, MTR_DATE, I_CODE, A_TYPE, M_TYPE
                FROM TTRD_WMPS_DEFINE
                UNION
                SELECT UNIT_ID, MTR_DATE, I_CODE, A_TYPE, M_TYPE
                FROM TTRD_WMPS_DEFINE_MAIN
      ) DF,
            TTRD_WMPS_UNIT UNIT
      WHERE FEE.FEE_LEVEL='1'
        AND FEE.W_I_CODE=DF.I_CODE
        AND FEE.W_A_TYPE=DF.A_TYPE
        AND FEE.W_M_TYPE=DF.M_TYPE
        AND DF.UNIT_ID=UNIT.UNIT_ID
  UNION ALL--理财产品费用 --按业务单元设置
     SELECT FEE.I_CODE,
            FEE.A_TYPE,
            FEE.M_TYPE,
            'CNY' AS CURRENCY,
            NULL  AS EXT_CASH_ACCT_ID,
            FEE.START_DATE,
            FEE.PAY_FREQ,
            FEE.PAY_MONTH,
            FEE.PAY_DAY,
            FEE.DAYCOUNT,
            --FEE.BIZ_CONV,
            FEE.BIZ_CONV      AS PAYMENT_BIZ_CONV, --表示支付调整规则
            FEE.CALC_BIZ_CONV AS CALC_BIZ_CONV, --表示计息调整规则
            0                 AS COMPOUNDING_METHOD,
            'CHINA_IB'        AS CALENDAR_CODE,
            --'0302' AS P_TYPE,
            --'理财费用' AS P_CLASS,
            CASE
                WHEN COALESCE(FEE.TOGETHER_MTR,0)=1
                THEN DF.MTR_DATE
                ELSE '2099-12-31'
            END AS MTR_DATE,
            0   AS PRINCIPAL_FINAL_EXCHANGE
       FROM TTRD_WMPS_FEE FEE
  LEFT JOIN
            ( SELECT UNIT_ID,
                    MAX(MTR_DATE) AS MTR_DATE
               FROM (
          SELECT TO_CHAR(UNIT_ID) AS UNIT_ID, MTR_DATE
          FROM TTRD_WMPS_DEFINE
          UNION
          SELECT UNIT_ID, MTR_DATE
          FROM TTRD_WMPS_DEFINE_MAIN
         )
           GROUP BY UNIT_ID ) DF
         ON FEE.UNIT_ID=DF.UNIT_ID
      WHERE FEE.FEE_LEVEL='2'
  UNION ALL--货币基金
     SELECT I_CODE,
            'SPT_MMF' AS A_TYPE,
            M_TYPE,
            CURRENCY,
            NULL         AS EXT_CASH_ACCT_ID,
            '2010-01-01' AS START_DATE,
            '0D'         AS PAY_FREQ,
            0            AS PAY_MONTH,
            0            AS PAY_DAY,
            'ACTUAL/360' AS DAYCOUNT,
            --'Following' AS BIZ_CONV,
            'Following' AS PAYMENT_BIZ_CONV, --表示支付调整规则
            'Following' AS CALC_BIZ_CONV, --表示计息调整规则
            0           AS COMPOUNDING_METHOD,
            CASE
                WHEN M_TYPE IN ('X_CNBD',
                                'NONE',
        'OTHER')
                THEN 'CHINA_IB'
                ELSE 'CHINA_EX'
            END AS CALENDAR_CODE,--银行间与基金市场默认取银行间交易日历，剩余的取交易所
            --'0400' AS P_TYPE,
            --P_CLASS,
            '2099-12-31' AS MTR_DATE,
            0            AS PRINCIPAL_FINAL_EXCHANGE
       FROM TFND A
      WHERE A_TYPE = 'SPT_MMF'
  UNION ALL --通道费用 --4：按通道 5：按通道＋资产明细"
     SELECT FEE.I_CODE,
            FEE.A_TYPE,
            FEE.M_TYPE,
            'CNY' AS CURRENCY,
            NULL  AS EXT_CASH_ACCT_ID,
            FEE.START_DATE,
            FEE.PAY_FREQ,
            FEE.PAY_MONTH,
            FEE.PAY_DAY,
            FEE.DAYCOUNT,
            --FEE.BIZ_CONV,
            FEE.BIZ_CONV      AS PAYMENT_BIZ_CONV, --表示支付调整规则
            FEE.CALC_BIZ_CONV AS CALC_BIZ_CONV, --表示计息调整规则
            0                 AS COMPOUNDING_METHOD,
            'CHINA_IB'        AS CALENDAR_CODE,
            --'0400' AS P_TYPE,
            --P_CLASS,
            '2099-12-31' AS MTR_DATE,
            0            AS PRINCIPAL_FINAL_EXCHANGE
       FROM TTRD_WMPS_FEE FEE
      WHERE FEE.FEE_LEVEL IN ('4',
                              '5') ) C
WHERE A.I_CODE=C.I_CODE
AND A.A_TYPE=C.A_TYPE
AND A.M_TYPE=C.M_TYPE
/

