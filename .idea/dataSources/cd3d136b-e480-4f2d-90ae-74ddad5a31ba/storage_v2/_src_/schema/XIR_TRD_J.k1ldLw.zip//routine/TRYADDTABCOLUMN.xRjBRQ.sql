create procedure TRYADDTABCOLUMN(tabName in varchar2, colName in varchar2, colType in varchar2) is
        n_col int;
        stmt VARCHAR(2000);
        begin
          select count(*) into n_col from cols
                 where table_name = upper(tabName) and column_name = upper(colName);
          if n_col<1 then
            stmt :='alter table '||tabName||' add '||colName||' '||colType;
            execute immediate stmt;
          end if;
        end TRYADDTABCOLUMN;




/

