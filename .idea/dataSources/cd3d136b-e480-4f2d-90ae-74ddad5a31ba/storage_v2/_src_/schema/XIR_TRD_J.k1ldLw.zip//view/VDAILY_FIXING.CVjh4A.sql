create view VDAILY_FIXING as
  select
   I_CODE,
   A_TYPE,
   M_TYPE,
   DP_CLOSE,
   BEG_DATE,
   END_DATE
from
   TIR_SERIES
UNION
select
   I_CODE,
   A_TYPE,
   M_TYPE,
   DP_MID as DP_CLOSE,
   BEG_DATE,
   END_DATE
from
   TFX_SERIES
UNION
select
   I_CODE,
   A_TYPE,
   M_TYPE,
   DP_CLOSE,
   BEG_DATE,
   END_DATE
from
   TCMDT_SERIES
UNION
select
   I_CODE,
   A_TYPE,
   M_TYPE,
   DP_CLOSE,
   BEG_DATE,
   END_DATE
from
   TIDX_SERIES
UNION
select
   I_CODE,
   A_TYPE,
   M_TYPE,
   DP_CLOSE,
   BEG_DATE,
   END_DATE
from
   TEXG_DAILYPRICE
/

comment on table VDAILY_FIXING
is '定盘视图'
/

