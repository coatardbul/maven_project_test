create view VTRD_LIMIT_ACC_PKGREF_SECU as
  select m.packageid, m.component as accid
  from ttrd_acc_package_ref m
 left join ttrd_acc_package_component mc
    on m.component = mc.component
   and mc.componenttype = '0'
/

