create view VDED_NOTIONAL_SCHEDULE as
  SELECT SCHEDULE.I_CODE,
    SCHEDULE.A_TYPE,
    SCHEDULE.M_TYPE,
    SCHEDULE.P_TYPE,
    SCHEDULE.LEG_ID,
    SCHEDULE.BEG_DATE,
    SCHEDULE.END_DATE,
    CASE
        WHEN SCHEDULE.BEG_DATE >= INFO.MTR_DATE
        THEN 0
        ELSE SCHEDULE.AMOUNT
    END AS AMOUNT,
    SCHEDULE.TSK_ID
FROM (SELECT --活期存款 从核算余额取数据
            T2.TSK_ID,
            T1.accid ||
            '_' ||
                T1.CURRENCY AS I_CODE,
            'SPT_DED'       AS A_TYPE,
            T1.MARKETS      AS M_TYPE,
            '0300'          AS P_TYPE,
            T2.CASH_ACCT_ID AS LEG_ID,
            T2.BEG_DATE,
            T2.END_DATE,
            T2.REAL_AMOUNT AS AMOUNT
       FROM TTRD_ACC_CASH_EXT T1
 INNER JOIN
            (SELECT TSK_ID,
                    CASH_ACCT_ID,
                    BEG_DATE,
                    END_DATE,
                    CASE
                        WHEN REAL_AMOUNT<=0
                        THEN 0
                        ELSE REAL_AMOUNT
                    END AS REAL_AMOUNT,
                    EXT_CASH_ACCT_ID
               FROM TTRD_ACCOUNTING_CASH_OBJ
          UNION ALL
             SELECT TSK_ID,
                    CASH_ACCT_ID,
                    BEG_DATE,
                    END_DATE,
                    CASE
                        WHEN REAL_AMOUNT<=0
                        THEN 0
                        ELSE REAL_AMOUNT
                    END AS REAL_AMOUNT,
                    EXT_CASH_ACCT_ID
               FROM TTRD_ACCOUNTING_CASH_OBJ_HIS) T2
         ON T1.ACCID = T2.EXT_CASH_ACCT_ID
      WHERE T1.PAYMENT_FREQ<>'-1'
  UNION ALL --货币基金 从核算余额取数据
     SELECT BLC.TSK_ID,
            FND.I_CODE AS I_CODE,
            FND.A_TYPE AS A_TYPE,
            FND.M_TYPE AS M_TYPE,
            '0706'  AS P_TYPE,
            BLC.SECU_ACCT_ID AS LEG_ID,
            BLC.BEG_DATE,
            BLC.END_DATE,
            BLC.REAL_VOLUME AS AMOUNT
       FROM TFND FND
 INNER JOIN
            (SELECT TSK_ID,
                    I_CODE,
                    A_TYPE,
                    M_TYPE,
                    SECU_ACCT_ID,
                    BEG_DATE,
                    END_DATE,
                    REAL_VOLUME,
                    REAL_CP
               FROM TTRD_ACCOUNTING_SECU_OBJ
          UNION ALL
             SELECT TSK_ID,
                    I_CODE,
                    A_TYPE,
                    M_TYPE,
                    SECU_ACCT_ID,
                    BEG_DATE,
                    END_DATE,
                    REAL_VOLUME,
                    REAL_CP
               FROM TTRD_ACCOUNTING_SECU_OBJ_HIS) BLC
         ON (
                FND.I_CODE = BLC.I_CODE
            AND FND.M_TYPE = BLC.M_TYPE
            AND FND.A_TYPE = BLC.A_TYPE
                --and fnd.ext_secu_acct_id = blc.ext_secu_acct_id
            )
      WHERE FND.A_TYPE = 'SPT_MMF'
  UNION ALL --每日开放理财产品
     SELECT BLC.TSK_ID,
            WMPS.I_CODE AS I_CODE,
            WMPS.A_TYPE AS A_TYPE,
            WMPS.M_TYPE AS M_TYPE,
            WMPS.P_TYPE,
            BLC.SECU_ACCT_ID AS LEG_ID,
            BLC.BEG_DATE,
            BLC.END_DATE,
            BLC.REAL_VOLUME AS AMOUNT
       FROM TTRD_WMPS_DEFINE WMPS
 INNER JOIN
            (SELECT TSK_ID,
                    I_CODE,
                    A_TYPE,
                    M_TYPE,
                    SECU_ACCT_ID,
                    BEG_DATE,
                    END_DATE,
                    REAL_VOLUME
               FROM TTRD_ACCOUNTING_SECU_OBJ
          UNION ALL
             SELECT TSK_ID,
                    I_CODE,
                    A_TYPE,
                    M_TYPE,
                    SECU_ACCT_ID,
                    BEG_DATE,
                    END_DATE,
                    REAL_VOLUME
               FROM TTRD_ACCOUNTING_SECU_OBJ_HIS) BLC
         ON (
                WMPS.I_CODE = BLC.I_CODE
            AND WMPS.M_TYPE = BLC.M_TYPE
            AND WMPS.A_TYPE = BLC.A_TYPE
            AND WMPS.P_TYPE = '0301')
  UNION ALL --理财产品费用--1：按产品设置 ；2：计算基数为发行量或日终余额
     SELECT BLC.TSK_ID,
            FEE.I_CODE       AS I_CODE,
            FEE.A_TYPE       AS A_TYPE,
            FEE.M_TYPE       AS M_TYPE,
            '0302'           AS P_TYPE,
            BLC.SECU_ACCT_ID AS LEG_ID,
            BLC.BEG_DATE,
            BLC.END_DATE,
            BLC.REAL_VOLUME AS AMOUNT
       FROM TTRD_WMPS_FEE FEE
  LEFT JOIN (
        SELECT TO_CHAR(UNIT_ID) AS UNIT_ID, I_CODE, A_TYPE, M_TYPE
                FROM TTRD_WMPS_DEFINE
                UNION
                SELECT UNIT_ID, I_CODE, A_TYPE, M_TYPE
                FROM TTRD_WMPS_DEFINE_MAIN
      ) WD
         ON FEE.W_I_CODE = WD.I_CODE
        AND FEE.W_A_TYPE = WD.A_TYPE
        AND FEE.W_M_TYPE = WD.M_TYPE
 INNER JOIN
            (SELECT TSK_ID,
                    I_CODE,
                    A_TYPE,
                    M_TYPE,
                    SECU_ACCT_ID,
                    BEG_DATE,
                    END_DATE,
                    REAL_VOLUME
               FROM TTRD_ACCOUNTING_SECU_OBJ
          UNION ALL
             SELECT TSK_ID,
                    I_CODE,
                    A_TYPE,
                    M_TYPE,
                    SECU_ACCT_ID,
                    BEG_DATE,
                    END_DATE,
                    REAL_VOLUME
               FROM TTRD_ACCOUNTING_SECU_OBJ_HIS) BLC
         ON (
                WD.I_CODE = BLC.I_CODE
            AND WD.M_TYPE = BLC.M_TYPE
            AND WD.A_TYPE = BLC.A_TYPE) --使用理财产品代号关联
  UNION ALL --理财业务单元费用  1:2：按资产池设置  2：计算基数为发行量或日终余额
     SELECT BLC.TSK_ID,
            FEE.I_CODE       AS I_CODE,
            FEE.A_TYPE       AS A_TYPE,
            FEE.M_TYPE       AS M_TYPE,
            '0302'           AS P_TYPE,
            BLC.SECU_ACCT_ID AS LEG_ID,
            BLC.BEG_DATE,
            BLC.END_DATE,
            SUM(BLC.REAL_VOLUME) AS AMOUNT
       FROM TTRD_WMPS_FEE FEE
 INNER JOIN TTRD_WMPS_UNIT WU
         ON WU.UNIT_ID = FEE.UNIT_ID
 INNER JOIN (
        SELECT TO_CHAR(UNIT_ID) AS UNIT_ID, I_CODE, A_TYPE, M_TYPE
                FROM TTRD_WMPS_DEFINE
                UNION
                SELECT UNIT_ID, I_CODE, A_TYPE, M_TYPE
                FROM TTRD_WMPS_DEFINE_MAIN
      ) WD
         ON WU.UNIT_ID = WD.UNIT_ID
 INNER JOIN
            (SELECT TSK_ID,
                    I_CODE,
                    A_TYPE,
                    M_TYPE,
                    SECU_ACCT_ID,
                    BEG_DATE,
                    END_DATE,
                    REAL_VOLUME
               FROM TTRD_ACCOUNTING_SECU_OBJ
          UNION ALL
             SELECT TSK_ID,
                    I_CODE,
                    A_TYPE,
                    M_TYPE,
                    SECU_ACCT_ID,
                    BEG_DATE,
                    END_DATE,
                    REAL_VOLUME
               FROM TTRD_ACCOUNTING_SECU_OBJ_HIS) BLC
         ON (
                WD.I_CODE = BLC.I_CODE
            AND WD.M_TYPE = BLC.M_TYPE
            AND WD.A_TYPE = BLC.A_TYPE) --使用理财产品代号关联
      WHERE FEE.FEE_LEVEL = '2'
        AND FEE.FEE_BASE IN ('1',
                             '2')
   GROUP BY BLC.TSK_ID,
            FEE.I_CODE,
            FEE.A_TYPE,
            FEE.M_TYPE,
            BLC.BEG_DATE,
            BLC.END_DATE,
            BLC.SECU_ACCT_ID
  UNION ALL --通道费用  FEE_LEVEL  费用层次：1：按产品设置；2：按资产池设置 3：超额管理费 4：按通道 5：按通道＋资产明细" --Add by
        -- xiaofang.mei 20150107
     SELECT BLC.TSK_ID,
            INST.I_CODE,
            INST.A_TYPE,
            INST.M_TYPE,
            INST.P_TYPE,
            BLC.SECU_ACCT_ID AS LEG_ID,
            BLC.BEG_DATE,
            BLC.END_DATE,
            SUM(ABS(
                CASE
                    WHEN FEE.FEE_BASE=41
                    THEN MKT_VALUE
                    WHEN FEE.FEE_BASE=42
                    THEN REAL_AMOUNT
                    WHEN FEE.FEE_BASE=43
                    THEN FULL_CP
                    WHEN FEE.FEE_BASE=43
                    THEN NET_CP
                END)*-1 ) AS AMOUNT
       FROM TTRD_WMPS_FEE FEE
 INNER JOIN TTRD_INSTRUMENT INST
         ON FEE.I_CODE=INST.I_CODE
        AND FEE.A_TYPE=INST.A_TYPE
        AND FEE.M_TYPE=INST.M_TYPE
 INNER JOIN
            (SELECT TSK_ID,
                    I_CODE,
                    A_TYPE,
                    M_TYPE,
                    C.ACCID AS SECU_ACCT_ID,
                    BEG_DATE,
                    END_DATE,
                    A.REAL_CP+A.AMRT_IR+A.AI+A.CHG_FV AS MKT_VALUE,
                    A.REAL_AMOUNT,
                    A.REAL_CP+A.AMRT_IR      AS NET_CP,
                    A.REAL_CP+A.AMRT_IR+A.AI AS FULL_CP,
                    A.TRADE_GRP_ID,
                    B.CASH_ACCID
               FROM TTRD_ACCOUNTING_SECU_OBJ A,
                    TTRD_ACC_SECU B,
                    TTRD_ACC_SECU C
              WHERE A.SECU_ACCT_ID=B.ACCID
                AND B.CASH_ACCID=C.CASH_ACCID
                AND COALESCE(C.ACTING_TYPE,'0')='5'
                AND A.TRADE_GRP_ID IS NOT NULL
          UNION ALL
             SELECT TSK_ID,
                    I_CODE,
                    A_TYPE,
                    M_TYPE,
                    C.ACCID AS SECU_ACCT_ID,
                    BEG_DATE,
                    END_DATE,
                    A.REAL_CP+A.AMRT_IR+A.AI+A.CHG_FV AS MKT_VALUE,
                    A.REAL_AMOUNT,
                    A.REAL_CP+A.AMRT_IR      AS NET_CP,
                    A.REAL_CP+A.AMRT_IR+A.AI AS FULL_CP,
                    A.TRADE_GRP_ID,
                    B.CASH_ACCID
               FROM TTRD_ACCOUNTING_SECU_OBJ_HIS A,
                    TTRD_ACC_SECU B,
                    TTRD_ACC_SECU C
              WHERE A.SECU_ACCT_ID=B.ACCID
                AND B.CASH_ACCID=C.CASH_ACCID
                AND COALESCE(C.ACTING_TYPE,'0')='5'
                AND A.TRADE_GRP_ID IS NOT NULL ) BLC
         ON FEE.UNIT_ID=BLC.TRADE_GRP_ID
      WHERE FEE.FEE_LEVEL IN ('4')
   GROUP BY BLC.TSK_ID,
            INST.I_CODE,
            INST.A_TYPE,
            INST.M_TYPE,
            INST.P_TYPE,
            BLC.BEG_DATE,
            BLC.END_DATE,
            BLC.SECU_ACCT_ID
  UNION ALL -- 理财产品费用基数为资产总额 所发行的所有产品的资产的账面价值 ---理财业务单元费用  1:2：按资产池设置  2：计算基数为账面价值  ---
        -- 只支持过去账面价值，不能取今天，所以只从历史表取数据
     SELECT ASO.TSK_ID,
            FEE.I_CODE AS I_CODE,
            FEE.A_TYPE AS A_TYPE,
            FEE.M_TYPE AS M_TYPE,
            '0302'     AS P_TYPE,
            LEG.ACCID  AS LEG_ID,
            ASO.BEG_DATE,
            ASO.END_DATE,
            CASE
                WHEN SUM(ASO.N_AMOUNT) < 0
                THEN 0
                ELSE SUM(ASO.N_AMOUNT) * -1
            END AS AMOUNT
       FROM TTRD_WMPS_FEE FEE
 INNER JOIN TTRD_ACC_SECU LEG
         ON FEE.UNIT_ID = LEG.PS1
 INNER JOIN
            (SELECT ACCID AS SECU_ACCT_ID,
                    CASH_ACCID
               FROM TTRD_ACC_SECU SECU
              WHERE SECU.PS1 = '0'
                AND SECU.PS2 <> '0'
          UNION ALL
             SELECT ACCID AS SECU_ACCT_ID,
                    ACCID AS CASH_ACCID
               FROM TTRD_ACC_CASH) SECU
         ON SECU.CASH_ACCID IN
            (SELECT ACCID
               FROM TTRD_ACC_CASH C1,
                    TTRD_WMPS_UNIT U1
              WHERE C1.PC1 = U1.UNIT_ID
                AND U1.UNIT_GPR_ID = FEE.UNIT_ID)
 INNER JOIN
            (SELECT A.REAL_CP + A.AI + A.CHG_FV + A.AMRT_IR + A.DUE_CP + A.DUE_AI + A.DUE_FEE AS
                    N_AMOUNT,
                    A.SECU_ACCT_ID,
                    A.END_DATE                                                   AS BEG_DATE,
                    TO_CHAR(TO_DATE(A.END_DATE, 'YYYY-MM-DD') + 1, 'YYYY-MM-DD') AS END_DATE,
                    A.TSK_ID
               FROM TTRD_ACCOUNTING_SECU_OBJ_HIS A
          UNION ALL
             SELECT A.REAL_AMOUNT                                                AS N_AMOUNT,
                    A.CASH_ACCT_ID                                               AS SECU_ACCT_ID,
                    A.END_DATE                                                   AS BEG_DATE,
                    TO_CHAR(TO_DATE(A.END_DATE, 'YYYY-MM-DD') + 1, 'YYYY-MM-DD') AS END_DATE,
                    A.TSK_ID
               FROM TTRD_ACCOUNTING_CASH_OBJ_HIS A
          UNION ALL
             SELECT A.PAY_AMOUNT + A.RECEIVE_AMOUNT                              AS N_AMOUNT,
                    C.CASH_ACCT_ID                                               AS SECU_ACCT_ID,
                    A.END_DATE                                                   AS BEG_DATE,
                    TO_CHAR(TO_DATE(A.END_DATE, 'YYYY-MM-DD') + 1, 'YYYY-MM-DD') AS END_DATE,
                    A.TSK_ID
               FROM TTRD_ACCOUNTING_DUE_OBJ_HIS A,
                    TTRD_SET_INSTRUCTION B,
                    TTRD_SET_INSTRUCTION_CASH C
              WHERE A.PRMR_INST_ID = B.INST_ID
                AND B.INST_ID = C.INST_ID
                AND (
                        B.H_I_CODE, B.H_A_TYPE, B.H_M_TYPE) NOT IN
                    (SELECT I_CODE,
                            A_TYPE,
                            M_TYPE
                       FROM TTRD_WMPS_DEFINE)) ASO
         ON SECU.SECU_ACCT_ID = ASO.SECU_ACCT_ID
      WHERE FEE.FEE_LEVEL = '2'
        AND FEE.FEE_BASE = '3'
   GROUP BY ASO.TSK_ID,
            FEE.I_CODE,
            FEE.A_TYPE,
            FEE.M_TYPE,
            ASO.BEG_DATE,
            ASO.END_DATE,
            LEG.ACCID) SCHEDULE,
    VDED_INFO INFO
WHERE SCHEDULE.I_CODE = INFO.I_CODE
AND SCHEDULE.A_TYPE = INFO.A_TYPE
AND SCHEDULE.M_TYPE = INFO.M_TYPE



/

