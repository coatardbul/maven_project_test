create PROCEDURE tryDropTable(tableName IN varchar2) is
      stmt VARCHAR2(2000);
      row1 number;
      begin
        select count(table_name) into row1 from user_tables where table_name=upper(tableName);
        IF (row1>0) THEN
          stmt :='DROP TABLE '|| tableName;
          execute immediate stmt;
        END IF;
      END tryDropTable;





/

