create PROCEDURE DEL_TABLE_CONSTRAINT (tb_name       VARCHAR2)
IS
   con_count   NUMBER;
   con_name    VARCHAR2 (32);
BEGIN
   con_name := '';
   con_count := 0;

   SELECT COUNT (DISTINCT constraint_name)
     INTO con_count
     FROM user_constraints
    WHERE     table_name = UPPER (tb_name)
          and constraint_type ='P';

   IF con_count > 0
   THEN
      SELECT DISTINCT constraint_name
        INTO con_name
        FROM user_constraints
       WHERE     table_name = UPPER (tb_name)
             and constraint_type ='P';

      EXECUTE IMMEDIATE
         'alter table ' || tb_name || ' drop constraint ' || con_name;
   END IF;
END;
/

