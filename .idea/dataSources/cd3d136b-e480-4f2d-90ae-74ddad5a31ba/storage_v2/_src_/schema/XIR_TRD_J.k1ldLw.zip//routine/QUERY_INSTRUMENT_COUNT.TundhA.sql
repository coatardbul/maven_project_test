create function QUERY_INSTRUMENT_COUNT(iCode in varchar2, aType in varchar2, mType in varchar2,
          calc_date in varchar2)
return number
as
       res number;
  begin
  SELECT RES1 into res FROM (
    SELECT SUM(CASE WHEN SUBSTR(C.TRDTYPE, LENGTH(TRDTYPE)) = '0' THEN ORDCOUNT ELSE -1 * ORDCOUNT END) AS RES1
          FROM TTRD_OTC_TRADE C
          WHERE C.ORDDATE <= calc_date AND C.ORDSTATUS IN (-2, 0, 4)
                and i_code = iCode and a_type = aType and m_type = mType);

    return res;
  end;



/

