create trigger TRG_TPRT_DEFINE
  before insert or update
  on TPRT_DEFINE
  for each row
  BEGIN
  :NEW.UPDATE_TIME := SYSDATE;
END;















/

