create view VTRD_LIMIT_SPV_ASSET_CHG_MOCK as
  SELECT
	   		   SRC_TYPE,
               SRC_ID,
               OCCUPY_OBJ_TYPE,
               T.I_CODE,
               T.A_TYPE,
               T.M_TYPE,
               T.P_TYPE,
               T.P_CLASS,
               T.CLS_CODE,
               T.CLS_NAME,
               R.SECU_ACCT_ID,
               T.EXT_SECU_ACCT_ID,
               T.CASH_ACCT_ID AS CASH_ACCT_ID,
               T.EXE_CASH_ACCT_ID,
               T.TRADE_GRP_ID,
               T.BLC_SECU_VOLUME_KY*R.RATIO AS BLC_SECU_VOLUME_KY,
               T.CURRENCY,
               T.SET_DATE,
               T.ORD_TOTAL_AMOUNT*R.RATIO AS ORD_TOTAL_AMOUNT,
       		   T.ORD_CANCEL_AMOUNT*R.RATIO AS ORD_CANCEL_AMOUNT,
       		   T.ORD_REMAIN_AMOUNT*R.RATIO AS ORD_REMAIN_AMOUNT
FROM VTRD_LIMIT_ASSET_CHG_INFO T
INNER JOIN VTRD_LIMIT_SPV_RATIO_PER_ACCT R
ON T.CASH_ACCT_ID = R.SPV_UNIT_CASH_ACCT_ID
/

