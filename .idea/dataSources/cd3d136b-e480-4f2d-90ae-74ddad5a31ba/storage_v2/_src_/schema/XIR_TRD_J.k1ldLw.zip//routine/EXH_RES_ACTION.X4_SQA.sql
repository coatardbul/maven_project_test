create PROCEDURE EXH_RES_ACTION(PI_CHANNELNO IN VARCHAR2,    -- 通道号
                                           PI_SYSORDID IN NUMBER,       -- 系统委托号
                                           PI_ACTID  IN NUMBER,         -- 操作序号（初次发送委托操作后填写，后续委托操作回报不需要填写）
                                           PI_M_TYPE    IN VARCHAR2,    -- 市场类型
                                           PI_EXTORDID  IN VARCHAR2,    -- 外部委托序号
                                           PI_ACTFLAG   IN CHAR,        -- 操作类型
                                           PI_ACTSTATUS IN INTEGER,     -- 新委托操作状态
                                           PI_LS        IN CHAR,        -- 多空标识
                                           PI_IS_CHECK  IN NUMBER,      -- 是否验资验券（0,1）
                                           PI_ERRCODE   IN NUMBER,      -- 错误号
                                           PI_ERRINFO   IN VARCHAR2,    -- 错误信息
                                           PO_ACTID     OUT NUMBER,     -- 委托操作回报时返回操作序号
                                           PO_SYSORDID     OUT NUMBER,  -- 委托操作回报时返回原系统委托号
                                           PO_INSID     OUT VARCHAR2,   -- 指令号
                                           PO_BATCHID   OUT NUMBER,     -- 批次号
                                           PO_ERRCODE   OUT NUMBER,     -- 输出错误号
                                           PO_ERRINFO   OUT VARCHAR2    -- 输出错误信息
                                           ) AS
/*
   1） 初次委托操作，根据操作序号，处理委托操作失败，PI_ACTSTATUS = 2
   2） 处理撤单成功，PI_ACTSTATUS = 6
*/

/*
  错误号定义：（负号表示错误，正号表示警告，0表示正确），委托应答以“14”开头
     +14001 = 原委托不存在
     +14002 = 非已报和部成委托
     -14003 = 委托操作不存在
     -14011 = 资金余额不存在
     -14013 = 股份余额不存在
*/

  -- 解冻数
  V_UNFREEZE_CNT       NUMBER;
  V_UNFREEZE_AMT       NUMBER;
  V_UNFREEZE_FEE       NUMBER;

  -- 操作序号（自动撤单时生成）
  V_ACTID NUMBER;
  -- 委托状态
  V_ORDSTATUS INTEGER;

  -- 定义委托表、委托操作表光标集
  CURSOR CUR_ORDER(P_SYSORDID IN NUMBER, P_CHANNEL_NO IN VARCHAR2, P_M_TYPE IN VARCHAR2, P_EXTORDID IN VARCHAR2) IS
     SELECT *
     FROM TTRD_EXH_ORDER
     WHERE (P_SYSORDID > 0 AND SYSORDID = P_SYSORDID) OR
           (P_SYSORDID <= 0 AND EXTORDID = P_EXTORDID AND CHANNEL_NO = P_CHANNEL_NO AND M_TYPE = P_M_TYPE)
     FOR UPDATE;

  CURSOR CUR_ACTION(P_ACTID IN NUMBER, P_O_SYSORDID IN NUMBER) IS
     SELECT *
     FROM TTRD_EXH_ORDER_ACTION
     WHERE (P_ACTID > 0 AND ACTID = P_ACTID) OR
           (P_ACTID <= 0 AND O_SYSORDID = P_O_SYSORDID AND ACTSTATUS IN (0, 1, 5))
     ORDER BY ACTID DESC
       FOR UPDATE;

  -- 定义委托表、委托操作表记录集
  REC_ORDER  TTRD_EXH_ORDER%ROWTYPE;
  REC_ACTION TTRD_EXH_ORDER_ACTION%ROWTYPE;

BEGIN
   PO_SYSORDID := 0;
   PO_ACTID := 0;
   PO_INSID := '';
   PO_BATCHID := 0;
   PO_ERRCODE := 0;
   PO_ERRINFO := '';

   -- 打开委托表光标集
   OPEN CUR_ORDER(PI_SYSORDID, PI_CHANNELNO, PI_M_TYPE, PI_EXTORDID);
   FETCH CUR_ORDER INTO REC_ORDER;
   IF CUR_ORDER%NOTFOUND THEN
      PO_ERRCODE := +14001;
      PO_ERRINFO := '操作应答，原委托不存在，系统委托号='|| TO_CHAR(PI_SYSORDID) || '，通道号=' || PI_CHANNELNO || '，市场类型=' || PI_M_TYPE || '，外部委托号=' || PI_EXTORDID;
      GOTO LABLE_QUIT;
   END IF;

   -- 打开委托操作光标集
   OPEN CUR_ACTION(PI_ACTID, REC_ORDER.SYSORDID);
   FETCH CUR_ACTION INTO REC_ACTION;

   -- 返回委托号、指令号、批次号、委托操作序号
   PO_SYSORDID := REC_ORDER.SYSORDID;
   PO_INSID := REC_ORDER.INSID;
   PO_BATCHID := REC_ORDER.BATCHID;
   IF CUR_ACTION%FOUND THEN
      PO_ACTID := REC_ACTION.ACTID;
   END IF;


   -- 1） 处理委托操作失败，把撤单操作置为失败，填写失败信息，并修改撤单标记为“无”
   IF PI_ACTSTATUS = 2 OR PI_ACTSTATUS = 3 THEN

      -- 更新委托撤单标记
      UPDATE TTRD_EXH_ORDER SET WTHFLAG = 0, WTH_ERRCODE = PI_ERRCODE, WTH_ERRINFO = PI_ERRINFO WHERE WTHFLAG = 1 AND SYSORDID = REC_ORDER.SYSORDID;

      -- 更新委托操作失败信息
      IF CUR_ACTION%FOUND THEN
         UPDATE TTRD_EXH_ORDER_ACTION SET ACTSTATUS = PI_ACTSTATUS, ERRCODE = PI_ERRCODE, ERRINFO = PI_ERRINFO WHERE CURRENT OF CUR_ACTION;
      END IF;
   END IF;


   IF PI_ACTSTATUS <> 6 THEN
      GOTO LABLE_QUIT;
   END IF;


   -- 2） 处理撤单成功，PI_ACTSTATUS = 6
   -- 5=已报、6=部成才处理撤单成功
   IF REC_ORDER.ORDSTATUS <> 5 AND REC_ORDER.ORDSTATUS <> 6 THEN
      PO_ERRCODE := +14002;
      PO_ERRINFO := '操作应答，原委托状态为' || TO_CHAR(REC_ORDER.ORDSTATUS) || '，不需处理';
      GOTO LABLE_QUIT;
   END IF;

   -- 判断委托操作是否存在，如果不存在，则插入委托操作
   IF CUR_ACTION%NOTFOUND THEN
      -- 生成自动撤单记录
      EXH_SEED_NEXT_VALUE('S_AOTOINC_EXH_ACTION_ID', V_ACTID, 1);
      INSERT INTO TTRD_EXH_ORDER_ACTION(ACTDATE, ACTTIME, ACTID, ACTFLAG, CHANNEL_NO, O_ORDDATE, O_SYSORDID, EXTORDID,
         EXTACTID, ACTSOURCE, OPERATOR, ACTSTATUS, ERRCODE, ERRINFO)
      VALUES(REC_ORDER.ORDDATE, '00:00:00', V_ACTID, PI_ACTFLAG, PI_CHANNELNO, REC_ORDER.ORDDATE ,REC_ORDER.SYSORDID, PI_EXTORDID,
         '', 'E', '外部撤单', 6, 0, '');

      -- 返回操作序号
      PO_ACTID := V_ACTID;
   ELSE
      UPDATE TTRD_EXH_ORDER_ACTION SET ACTSTATUS = PI_ACTSTATUS WHERE CURRENT OF CUR_ACTION;
   END IF;

    -- 解冻资金股份
   IF PI_IS_CHECK <> 0 THEN
      V_UNFREEZE_AMT := -1 * ABS(REC_ORDER.ORDFROZENAMT);
      V_UNFREEZE_FEE := -1 * ABS(REC_ORDER.ORDFROZENFEE);
      V_UNFREEZE_CNT := 0;
      IF REC_ORDER.OCFLAG = 'C' THEN
         V_UNFREEZE_CNT := -1 * ABS(REC_ORDER.ORDCOUNT - REC_ORDER.DEACOUNT);
      END IF;

      EXH_FREEZE_CASH_SECU(REC_ORDER.CASH_EXT_ACCID, REC_ORDER.SECU_EXT_ACCID, REC_ORDER.I_CODE, REC_ORDER.A_TYPE, REC_ORDER.M_TYPE,
                           PI_LS, V_UNFREEZE_CNT, V_UNFREEZE_AMT, V_UNFREEZE_FEE, 0, PO_ERRCODE, PO_ERRINFO);

      IF PO_ERRCODE < 0 THEN
         PO_ERRCODE := PO_ERRCODE - 4000;
      END IF;

   END IF;


   -- 1、修改委托状态为9=外部撤单或8=部分撤单
   -- 2、修改撤单标记为已撤
   IF REC_ORDER.DEACOUNT > 0 THEN
      V_ORDSTATUS := 8;
   ELSE
      V_ORDSTATUS := 9;
   END IF;

   UPDATE TTRD_EXH_ORDER
      SET ORDSTATUS    = V_ORDSTATUS,
          WTHFLAG      = 2,
          WTH_ERRCODE  = 0,
          WTH_ERRINFO  = '',
          WTHCOUNT     = REC_ORDER.ORDCOUNT - REC_ORDER.DEACOUNT
   WHERE CURRENT OF CUR_ORDER;

   -- 退出标签
   <<LABLE_QUIT>>

   -- 关闭游标
   IF CUR_ORDER%ISOPEN THEN
      CLOSE CUR_ORDER;
   END IF;
   IF CUR_ACTION%ISOPEN THEN
      CLOSE CUR_ACTION;
   END IF;

END;
/

