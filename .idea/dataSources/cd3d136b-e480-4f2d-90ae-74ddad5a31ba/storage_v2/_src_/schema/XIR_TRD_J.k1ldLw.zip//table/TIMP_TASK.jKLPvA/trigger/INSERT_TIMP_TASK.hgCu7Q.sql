create trigger INSERT_TIMP_TASK
  before insert
  on TIMP_TASK
  for each row
  BEGIN
    select S_TIMP_TASK.nextval into :NEW.TASK_ID from dual;
END;















/

