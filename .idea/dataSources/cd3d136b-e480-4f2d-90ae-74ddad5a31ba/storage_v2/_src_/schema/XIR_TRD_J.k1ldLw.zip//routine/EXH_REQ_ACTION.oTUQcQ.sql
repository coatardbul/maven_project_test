create PROCEDURE EXH_REQ_ACTION(PI_ACTDATE IN CHAR,       -- 操作日期
                                           PI_ACTID   IN NUMBER,     -- 操作序号
                                           PO_ERRCODE OUT NUMBER,    -- 返回错误号
                                           PO_ERRINFO OUT VARCHAR2   -- 返回错误信息
                                           ) AS
/*
   1） 检查委托状态是否为最终状态，如果委托状态为内部撤单、外部撤单、全部成交、部分撤单以及废单等，则把操作状态该为“错误”；
   2） 检查委托状态是否为“正报”，如果委托状态为正报，则作为内部撤单处理，修改委托状态为内部撤单，撤单标记为已撤，撤单操作状态为成功；
   3） 修改撤单操作状态为已报
   4） 发送撤单至外部接口，发送失败、通讯不通以及外部接口返回错误信息等，把撤单操作置为失败，填写失败信息，并修改撤单标记为“无”
   5） 对改变的委托状态信息发送到MQ，通知应用服务
*/

/*
  错误号定义：（负号表示错误，正号表示警告，0表示正确），委托操作请求以“13”开头
     +13001 = 内部撤单
     -13002 = 委托操作不存在
     -13003 = 原委托不存在
     -13004 = 原委托为最终状态
*/

  -- 定义委托操作表、委托表游标集
  CURSOR CUR_ACTION(P_ACTID IN NUMBER) IS
     SELECT *
     FROM TTRD_EXH_ORDER_ACTION
     WHERE ACTID = P_ACTID
       FOR UPDATE;

  CURSOR CUR_ORDER(P_SYSORDID IN NUMBER) IS
     SELECT *
     FROM TTRD_EXH_ORDER
     WHERE SYSORDID = P_SYSORDID
       FOR UPDATE;

  -- 定义委托操作表、委托表记录集
  REC_ACTION TTRD_EXH_ORDER_ACTION%ROWTYPE;
  REC_ORDER  TTRD_EXH_ORDER%ROWTYPE;

BEGIN
   PO_ERRCODE := 0;
   PO_ERRINFO := '';

   -- 打开委托表光标集
   OPEN CUR_ACTION(PI_ACTID);
   FETCH CUR_ACTION INTO REC_ACTION;
   IF CUR_ACTION%NOTFOUND THEN
      PO_ERRCODE := -13002;
      PO_ERRINFO := '委托操作不存在，操作日期=' || PI_ACTDATE || '，操作序号=' || TO_CHAR(PI_ACTID);
      GOTO LABLE_QUIT;
   END IF;

   -- 打开委托表光标集
   OPEN CUR_ORDER(REC_ACTION.O_SYSORDID);
   FETCH CUR_ORDER INTO REC_ORDER;
   IF CUR_ORDER%NOTFOUND THEN
      PO_ERRCODE := -13003;
      PO_ERRINFO := '原委托不存在，委托日期=' || REC_ACTION.O_ORDDATE || '，委托号=' || TO_CHAR(REC_ACTION.O_SYSORDID);
      UPDATE TTRD_EXH_ORDER_ACTION SET ACTSTATUS = 2, ERRCODE = PO_ERRCODE, ERRINFO = PO_ERRINFO WHERE CURRENT OF CUR_ACTION;
      GOTO LABLE_QUIT;
   END IF;

   -- 2=废单；3=内部撤单；7=全成；8=部撤；9=全撤
   -- 委托终止，撤单失败
   IF REC_ORDER.ORDSTATUS = 2 OR REC_ORDER.ORDSTATUS = 3 OR REC_ORDER.ORDSTATUS = 8 OR REC_ORDER.ORDSTATUS = 9 THEN
      PO_ERRCODE := -13004;
      PO_ERRINFO := '原委托已为最终状态，无法撤单，原委托状态=' || TO_CHAR(REC_ORDER.ORDSTATUS);
      UPDATE TTRD_EXH_ORDER_ACTION SET ACTSTATUS = 2, ERRCODE = PO_ERRCODE, ERRINFO = PO_ERRINFO WHERE CURRENT OF CUR_ACTION;
      GOTO LABLE_QUIT;
   END IF;

   -- 1=正报
   -- 内部撤单：委托状态=3（内部撤单），撤单标记=2（已撤）；委托操作状态=6（成功），给出警告信息
   IF REC_ORDER.ORDSTATUS = 1 THEN
      PO_ERRCODE := +13001;
      PO_ERRINFO := '内部撤单，委托日期=' || REC_ACTION.O_ORDDATE || '，委托号=' || TO_CHAR(REC_ACTION.O_SYSORDID);
      UPDATE TTRD_EXH_ORDER SET ORDSTATUS = 3, WTHFLAG = 2, WTHCOUNT = ORDCOUNT - DEACOUNT WHERE CURRENT OF CUR_ORDER;
      UPDATE TTRD_EXH_ORDER_ACTION SET ACTSTATUS = 6 WHERE CURRENT OF CUR_ACTION;
   ELSE
      UPDATE TTRD_EXH_ORDER_ACTION SET ACTSTATUS = 5 WHERE CURRENT OF CUR_ACTION;
   END IF;

   -- 退出标签
   <<LABLE_QUIT>>

   -- 关闭游标
   IF CUR_ORDER%ISOPEN THEN
      CLOSE CUR_ORDER;
   END IF;

   IF CUR_ACTION%ISOPEN THEN
      CLOSE CUR_ACTION;
   END IF;

END;
/

