create view VTRD_CBGS_CTRCT_DETAIL as
  SELECT A.TXFLOWID AS TXFLOWID, --交易流水标识
    A.INSTR_ID, --中债指令编号
    A.CTRCT_ID1           AS CTRCT_ID, --合同编号
    A.CTRCT_STATUS1       AS CTRCT_STATUS, --合同状态
    A.CTRCT_BLOCK_STATUS1 AS CTRCT_BLOCK_STATUS, --合同冻结状态
    A.TXID                AS EXTORDID, --外汇交易中心外部成交编号
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN
                (SELECT MAP_VALUE
                   FROM VTRD_CBGS_SYS_CONVERT_MAP ---判断买入卖出视图
                  WHERE MAP_ITEM = 'CBGS_CTRDBIZTYPE_MAP'
                    AND MAP_KEY = A.BIZTYPE ||
                        '_SELFGIV') --现券卖出
            ELSE
                  (SELECT MAP_VALUE
                 FROM VTRD_CBGS_SYS_CONVERT_MAP ---判断买入卖出视图
                WHERE MAP_ITEM = 'CBGS_CTRDBIZTYPE_MAP'
                  AND MAP_KEY = A.BIZTYPE ||
                      '_SELFTAK') --现券买入
        END)  BIZTYPE, ------ 业务类别
    A.ACCID   AS ZZDACCCODE, ------  本方托管账号
    A.ACCNAME AS ZZDACCNAME, ------  本方托管账号名称
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.TAK_ACC_ID --收券账户
            ELSE A.GIV_ACC_ID --付券账户
        END) PARTY_ZZDACCCODE, ------ 对手方托管账号
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.TAK_ACC_NAME --收券账户名称
            ELSE A.GIV_ACC_NAME --付券账户名称
        END)         PARTY_ZZDACCNAME, ------对手方托管账户名称
    A.DATE1          SETDATE, ------结算日期
    A.SETTLEMENT1    SETTYPE, ------结算方式
    0             AS NETAMOUNT, ------净价结算金额(DOUBLE)
    ''            AS NETAMOUNT_STR, ------净价结算金额(STRING)
    0             AS AIAMOUNT, ------应计利息(DOUBLE)
    ''            AS AIAMOUNT_STR, ------应计利息(STRING)
    0             AS AMOUNT, ------全价结算金额(DOUBLE)
    ''            AS AMOUNT_STR, ------全价结算金额(STRING)
    A.SG_TYPE1       RESERVETYPE, ------担保方式
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_TYPE1
            ELSE A.SG_TYPE2
        END) AS SG_TYPE, ----本方结算保证方式
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_I_CODE1
            ELSE A.SG_I_CODE2
        END) AS SG_I_CODE, ----本方结算保证债券代码
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_ISIN1
            ELSE A.SG_ISIN2
        END) AS SG_ISIN, ----本方结算保证ISIN编码
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_I_NAME1
            ELSE A.SG_I_NAME2
        END) AS SG_I_NAME, ----本方结算保证债券简称
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_TRDFV1*10000
            ELSE A.SG_TRDFV2*10000
        END) AS SG_TRDFV, ----本方结算保证券面总额(DOUBLE)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.S_SG_TRDFV1
            ELSE A.S_SG_TRDFV2
        END) AS SG_TRDFV_STR, ----本方结算保证券面总额(STRING)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_RATE1
            ELSE A.SG_RATE2
        END) AS SG_RATE, ----本方结算保证债券质押率(DOUBLE)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.S_SG_RATE1
            ELSE A.S_SG_RATE2
        END) AS SG_RATE_STR, ----本方结算保证债券质押率(STRING)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_CASH1
            ELSE A.SG_CASH2
        END) AS SG_CASH, ----本方结算保证金保管地
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_AMOUNT1
            ELSE A.SG_AMOUNT2
        END) AS SG_AMOUNT, ----本方结算保证金金额(DOUBLE)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.S_SG_AMOUNT1
            ELSE A.S_SG_AMOUNT2
        END) AS SG_AMOUNT_STR, ----本方结算保证金金额(STRING)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_TYPE2
            ELSE A.SG_TYPE1
        END) AS CP_SG_TYPE, ----对手方结算保证方式
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_I_CODE2
            ELSE A.SG_I_CODE1
        END) AS CP_SG_I_CODE, ----对手方结算保证债券代码
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_ISIN2
            ELSE A.SG_ISIN1
        END) AS CP_SG_ISIN, ----对手方结算保证ISIN编码
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_I_NAME2
            ELSE A.SG_I_NAME1
        END) AS CP_SG_I_NAME, ----对手方结算保证债券简称
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_TRDFV2*10000
            ELSE A.SG_TRDFV1*10000
        END) AS CP_SG_TRDFV, ----对手方结算保证券面总额(DOUBLE)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.S_SG_TRDFV2
            ELSE A.S_SG_TRDFV1
        END) AS CP_SG_TRDFV_STR, ----对手方结算保证券面总额(STRING)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_RATE2
            ELSE A.SG_RATE1
        END) AS CP_SG_RATE, ----对手方结算保证债券质押率(DOUBLE)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.S_SG_RATE2
            ELSE A.S_SG_RATE1
        END) AS CP_SG_RATE_STR, ----对手方结算保证债券质押率(STRING)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_CASH2
            ELSE A.SG_CASH1
        END) AS CP_SG_CASH, ----对手方结算保证金保管地
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.SG_AMOUNT2
            ELSE A.SG_AMOUNT1
        END) AS CP_SG_AMOUNT, ----对手方结算保证金金额(DOUBLE)
    (
        CASE
            WHEN A.GIV_ACC_ID = A.ACCID --为本方托管账号
            THEN A.S_SG_AMOUNT2
            ELSE A.S_SG_AMOUNT1
        END) AS CP_SG_AMOUNT_STR, ----对手方结算保证金金额(STRING)
    A.UPDATETIME ---更新时间
FROM TTRD_CBGS_SETTLEBIZ_DETAIL A -- 查询详情返回表
WHERE A.REQUEST_CODE = 'BJ0301'




/

