create view V_ACCOUNTING_SECU_OBJ_TRL as
  SELECT
    CASE
        WHEN C.P_TYPE='0300'
        THEN 'DED' ||
                A.EXT_SECU_ACCT_ID ||
                A.SECU_ACCT_ID
        ELSE A.OBJ_ID
    END AS OBJ_ID,
    A.TSK_ID,
    A.BEG_DATE,
    A.END_DATE,
    A.EXT_SECU_ACCT_ID,
    A.SECU_ACCT_ID,
    A.TRADE_GRP_ID,
    A.I_CODE,
    A.A_TYPE,
    A.M_TYPE,
    A.TRADE_ID,
    A.REAL_VOLUME + COALESCE(B.REAL_AMOUNT, 0) AS REAL_VOLUME,
    A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) AS REAL_AMOUNT,
    A.REAL_CP + COALESCE(B.REAL_AMOUNT, 0)     AS REAL_CP,
    AI,
    AI_COST,
    CHG_FV,
    DUE_AMOUNT,
    DUE_CP,
    DUE_AI,
    DUE_FEE,
    AMRT_DATE,
    AMRT_YTM,
    AMRT_IR,
    IMPAIR,
    PRFT_FV,
    PRFT_TRD,
    PRFT_IR,
    PRFT_FEE,
    A.OPEN_TIME,
    C.I_NAME,
    C.P_CLASS,
    C.P_TYPE,
    C.MTR_DATE,
    D.P_TYPE_NAME,
    E.CASH_ACCID,
    ACCOUNTNAME,
    ACCNAME,
    (AMRT_COST_AI+AMRT_COST_CP)                                                        AS AMRT_COST,
    A.REAL_CP + A.DUE_CP + A.AMRT_IR + A.CHG_FV + A.AI + A.DUE_AI+ COALESCE(B.REAL_AMOUNT, 0) AS
                                                                 ASSET_AMOUNT,
    A.DUE_AMOUNT + A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) AS ALL_AMOUNT,
    A.DUE_AI + A.AI                                           AS ALL_AI,
    A.DUE_CP + A.REAL_CP + COALESCE(B.REAL_AMOUNT, 0)         AS ALL_CP,
    A.TRIAL_ID,
    A.DATA_TYPE,
    E.ACTING_TYPE
FROM ( SELECT REAL_CP_NOAMRT,
            CHG_FV_NOAMRT,
            PRFT_FV_NOAMRT,
            PRFT_TRD_NOAMRT,
            OBJ_ID,
            TSK_ID,
            TRIAL_ID,
            DATA_TYPE,
            BEG_DATE,
            END_DATE,
            EXT_SECU_ACCT_ID,
            SECU_ACCT_ID,
            TRADE_GRP_ID,
            I_CODE,
            A_TYPE,
            M_TYPE,
            TRADE_ID,
            EXTRA_DIM,
            REAL_VOLUME,
            REAL_AMOUNT,
            REAL_CP,
            PRFT_FEE,
            AI,
            AI_COST,
            CHG_FV,
            DUE_AMOUNT,
            DUE_CP,
            DUE_AI,
            AMRT_COUNT,
            AMRT_DATE,
            AMRT_IR,
            PRFT_FV,
            PRFT_TRD,
            PRFT_IR,
            PRFT_IR_AI,
            PRFT_IR_AMRT,
            PRFT_IR_AI_HLD,
            PRFT_IR_AMRT_HLD,
            RECLASS_PRFT_FV,
            IMPAIR,
            PRFT_IMPAIR,
            REAL_MARGIN,
            RECEIVED_AI,
            OPEN_TIME,
            UPDATE_TIME,
            DUE_FEE,
            FEE,
            AMRT_IR_HP,
            AMRT_YTM,
            AMRT_COST_CP,
            AMRT_COST_AI,
            INVEST_YTM,
            OPEN_YTM
       FROM TTRD_ACCTG_SECU_OBJ_TRL
  UNION ALL
     SELECT 0 AS REAL_CP_NOAMRT,
            0 AS CHG_FV_NOAMRT,
            0 AS PRFT_FV_NOAMRT,
            0 AS PRFT_TRD_NOAMRT,
            OBJ_ID,
            TSK_ID,
            TRIAL_ID,
            DATA_TYPE,
            BEG_DATE,
            END_DATE,
            A.EXT_CASH_ACCT_ID AS EXT_SECU_ACCT_ID,
            A.CASH_ACCT_ID     AS SECU_ACCT_ID,
            ''                 AS TRADE_GRP_ID,
            I_CODE,
            A_TYPE,
            M_TYPE,
            ''  AS TRADE_ID,
            ''  AS EXTRA_DIM,
            0   AS REAL_VOLUME,
            0   AS REAL_AMOUNT,
            0   AS REAL_CP,
            0   AS PRFT_FEE,
            0   AS AI,
            0   AS AI_COST,
            0   AS CHG_FV,
            0   AS DUE_AMOUNT,
            0   AS DUE_CP,
            0   AS DUE_AI,
            0   AS AMRT_COUNT,
            ''  AS AMRT_DATE,
            0   AS AMRT_IR,
            0   AS PRFT_FV,
            0   AS PRFT_TRD,
            0   AS PRFT_IR,
            0   AS PRFT_IR_AI,
            0   AS PRFT_IR_AMRT,
            0   AS PRFT_IR_AI_HLD,
            0   AS PRFT_IR_AMRT_HLD,
            0   AS RECLASS_PRFT_FV,
            0   AS IMPAIR,
            0   AS PRFT_IMPAIR,
            0   AS REAL_MARGIN,
            0   AS RECEIVED_AI,
            ''  AS OPEN_TIME,
            ''  AS UPDATE_TIME,
            0   AS DUE_FEE,
            0   AS FEE,
            0   AS AMRT_IR_HP,
            0AS    AMRT_YTM,
            0   AS AMRT_COST_CP,
            0   AS AMRT_COST_AI,
            0   AS INVEST_YTM,
            0   AS OPEN_YTM
       FROM TTRD_ACCTG_CASH_OBJ_TRL A,
            VDED_INFO B
      WHERE A.EXT_CASH_ACCT_ID = B.EXT_CASH_ACCT_ID
        AND (
                A.TSK_ID, A.TRIAL_ID, A.DATA_TYPE,A.EXT_CASH_ACCT_ID,A.CASH_ACCT_ID, A.BEG_DATE)
            NOT IN
            (SELECT TSK_ID,
                    TRIAL_ID,
                    DATA_TYPE,
                    EXT_SECU_ACCT_ID,
                    SECU_ACCT_ID,
                    BEG_DATE
               FROM TTRD_ACCTG_SECU_OBJ_TRL) ) A
LEFT JOIN TTRD_ACCTG_CASH_OBJ_TRL B
 ON A.TSK_ID = B.TSK_ID
AND A.BEG_DATE = B.BEG_DATE
AND A.TRIAL_ID = B.TRIAL_ID
AND A.DATA_TYPE = B.DATA_TYPE
AND A.EXT_SECU_ACCT_ID = B.EXT_CASH_ACCT_ID
AND A.SECU_ACCT_ID = B.CASH_ACCT_ID
LEFT JOIN TTRD_INSTRUMENT C
 ON A.I_CODE = C.I_CODE
AND A.A_TYPE = C.A_TYPE
AND A.M_TYPE = C.M_TYPE
LEFT JOIN TTRD_P_CLASS D
 ON C.P_TYPE = D.P_TYPE
AND C.A_TYPE = D.A_TYPE
AND C.P_CLASS = D.P_CLASS
INNER JOIN
    (SELECT A.ACCID,
            A.CASH_ACCID,
            A.ACCNAME                      AS ACCOUNTNAME,
            COALESCE(B.ACCNAME, A.ACCNAME) AS ACCNAME,
            A.ACTING_TYPE
       FROM TTRD_ACC_SECU A
  LEFT JOIN TTRD_ACC_SECU B
         ON A.PS2 = B.ACCID
  UNION ALL
     SELECT ACCID,
            ACCID   AS CASH_ACCID,
            ACCNAME AS ACCOUNTNAME,
            '业务单元'  AS ACCNAME,
            '0'     AS ACTING_TYPE
       FROM TTRD_ACC_CASH) E
 ON A.SECU_ACCT_ID = E.ACCID




/

