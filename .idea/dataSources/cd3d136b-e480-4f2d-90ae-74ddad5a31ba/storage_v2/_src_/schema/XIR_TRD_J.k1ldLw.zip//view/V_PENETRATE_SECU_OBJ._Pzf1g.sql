create view V_PENETRATE_SECU_OBJ as
  SELECT A.OBJ_ID,
       A.TSK_ID,
       A.BEG_DATE,
       A.END_DATE,
       A.EXT_SECU_ACCT_ID,
       A.SECU_ACCT_ID,
       A.TRADE_GRP_ID,
       A.I_CODE AS PEN_I_CODE, -- 穿透路径 i_code
       A.A_TYPE AS PEN_A_TYPE, -- 穿透路径 i_code
       A.M_TYPE AS PEN_M_TYPE, -- 穿透路径 i_code
       F.I_NAME AS PEN_I_NAME, -- 穿透路径 i_code
       CASE
         WHEN PEN_SECU.OBJ_ID != PEN_SECU.PENETRATE_OBJ_ID THEN F.I_NAME
           ELSE NULL
       END AS PEN_PATH, -- 穿透路径
       PEN_OBJ.I_CODE, -- 底层 i_code
       PEN_OBJ.A_TYPE, -- 底层 i_code
       PEN_OBJ.M_TYPE, -- 底层 i_code
       PEN_OBJ.SECU_ACCT_ID as PEN_SECU_ACCT_ID,--底层证券账户
       A.TRADE_ID,
       PEN_SECU.REAL_VOLUME AS REAL_VOLUME,
       PEN_SECU.REAL_AMOUNT AS REAL_AMOUNT,
       PEN_SECU.REAL_CP AS REAL_CP,
       PEN_SECU.AI,
       A.AI_COST,
       PEN_SECU.CHG_FV,
       PEN_SECU.DUE_AMOUNT,
       CASE WHEN PEN_SECU.SET_DATE = '2100-12-31'
            THEN 0
            ELSE PEN_SECU.DUE_CP END AS DUE_CP,
       CASE WHEN PEN_SECU.SET_DATE = '2100-12-31'
            THEN 0
            ELSE PEN_SECU.DUE_AI END AS DUE_AI,
       PEN_SECU.DUE_FEE,
       A.AMRT_DATE,
       A.AMRT_YTM,
       A.AMRT_IR,
       A.IMPAIR,
       PEN_SECU.PRFT_FV,
       PEN_SECU.PRFT_TRD,
       PEN_SECU.PRFT_IR,
       PEN_SECU.PRFT_FEE,
       A.OPEN_TIME,
       C.I_NAME,
       C.P_CLASS,
       C.P_TYPE,
       C.MTR_DATE,
       D.P_TYPE_NAME,
       E.CASH_ACCID,
       H.ACCOUNTNAME,
       H.ACCNAME,
       A.AMRT_COST_CP + A.AMRT_COST_AI AS AMRT_COST,
       PEN_SECU.DUE_FEE + PEN_SECU.REAL_CP
       + CASE WHEN PEN_SECU.SET_DATE = '2100-12-31'
              THEN 0
              ELSE PEN_SECU.DUE_CP END
       + PEN_SECU.AMRT_IR + PEN_SECU.CHG_FV + PEN_SECU.AI
       + CASE WHEN PEN_SECU.SET_DATE = '2100-12-31'
              THEN 0
              ELSE PEN_SECU.DUE_AI END AS ASSET_AMOUNT,
       PEN_SECU.DUE_AMOUNT + PEN_SECU.REAL_AMOUNT AS ALL_AMOUNT,
       PEN_SECU.DUE_AI + PEN_SECU.AI AS ALL_AI,
       PEN_SECU.DUE_CP + PEN_SECU.REAL_CP AS ALL_CP,
       A.AMRT_COST_CP,
       A.OPEN_YTM,
       PEN_SECU.IS_HANDING,-- 是否是挂账数据
       PEN_SECU.SET_DATE
  FROM TTRD_PENETRATE_SECU_OBJ PEN_SECU
  INNER JOIN TTRD_ACCOUNTING_SECU_OBJ A -- 本条余额数据
    ON PEN_SECU.OBJ_ID = A.OBJ_ID
  LEFT JOIN TTRD_ACCOUNTING_SECU_OBJ PEN_OBJ -- 底层穿透余额数据
    ON PEN_SECU.PENETRATE_OBJ_ID = PEN_OBJ.OBJ_ID
  LEFT JOIN TTRD_INSTRUMENT C
    ON PEN_OBJ.I_CODE = C.I_CODE
   AND PEN_OBJ.A_TYPE = C.A_TYPE
   AND PEN_OBJ.M_TYPE = C.M_TYPE
  LEFT JOIN TTRD_P_CLASS D
    ON C.P_TYPE = D.P_TYPE
   AND C.A_TYPE = D.A_TYPE
   AND C.P_CLASS = D.P_CLASS
  INNER JOIN (SELECT A.ACCID,
                    A.CASH_ACCID,
                    A.ACCNAME AS ACCOUNTNAME,
                    COALESCE(B.ACCNAME, A.ACCNAME) AS ACCNAME
               FROM TTRD_ACC_SECU A
              INNER JOIN TTRD_ACC_SECU B
                 ON A.PS2 = B.ACCID) E
    ON A.SECU_ACCT_ID = E.ACCID
  LEFT JOIN TTRD_INSTRUMENT F
    ON A.I_CODE = F.I_CODE
   AND A.A_TYPE = F.A_TYPE
   AND A.M_TYPE = F.M_TYPE
  LEFT JOIN TTRD_ACC_SECU_EXT G
   ON A.EXT_SECU_ACCT_ID = G.ACCID
  LEFT JOIN (SELECT A.ACCID,
                    A.CASH_ACCID,
                    A.ACCNAME AS ACCOUNTNAME,
                    COALESCE(B.ACCNAME, A.ACCNAME) AS ACCNAME
               FROM TTRD_ACC_SECU A
              INNER JOIN TTRD_ACC_SECU B
                 ON A.PS2 = B.ACCID) H
    ON PEN_OBJ.SECU_ACCT_ID = H.ACCID
  WHERE PEN_SECU.IS_HANDING != '1'  /* 排除挂账穿透数据 */
    AND PEN_SECU.IS_LEAF = 1         /* 叶子节点 */
    AND NOT EXISTS (
      /* 排除余额表内活期利息 */
      SELECT 1 FROM TTRD_ACC_CASH WHERE PEN_OBJ.SECU_ACCT_ID = ACCID
    )
    AND (G.ACCTYPE IS NULL OR G.ACCTYPE != '2')   -- 排除 标准券账户

UNION ALL

-- 活期利息穿透数据,(底层SPV利息汇总), 穿透数据已包含底层活期利息穿透和自身活期利息
SELECT A.OBJ_ID,
       A.TSK_ID,
       A.BEG_DATE,
       A.END_DATE,
       A.EXT_SECU_ACCT_ID,
       A.SECU_ACCT_ID,
       A.TRADE_GRP_ID,
       A.I_CODE AS PEN_I_CODE, -- 穿透路径 i_code
       A.A_TYPE AS PEN_A_TYPE, -- 穿透路径 i_code
       A.M_TYPE AS PEN_M_TYPE, -- 穿透路径 i_code
       F.I_NAME AS PEN_I_NAME, -- 穿透路径 i_code
       CASE
         WHEN PEN_SECU.OBJ_ID != PEN_SECU.PENETRATE_OBJ_ID THEN F.I_NAME
           ELSE NULL
       END AS PEN_PATH, -- 穿透路径
       PEN_OBJ.I_CODE, -- 底层 i_code
       PEN_OBJ.A_TYPE, -- 底层 i_code
       PEN_OBJ.M_TYPE, -- 底层 i_code
       PEN_OBJ.SECU_ACCT_ID as PEN_SECU_ACCT_ID,--底层证券账户
       A.TRADE_ID,
       PEN_SECU.REAL_VOLUME + COALESCE(B.REAL_AMOUNT, 0) +
       COALESCE(PEN_CASH.REAL_AMOUNT, 0) AS REAL_VOLUME,
       PEN_SECU.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) +
       COALESCE(PEN_CASH.REAL_AMOUNT, 0) AS REAL_AMOUNT,
       PEN_SECU.REAL_CP + COALESCE(B.REAL_AMOUNT, 0) +
       COALESCE(PEN_CASH.REAL_AMOUNT, 0) AS REAL_CP,
       COALESCE(H.AI, 0) AS AI,
       A.AI_COST,
       PEN_SECU.CHG_FV,
       PEN_SECU.DUE_AMOUNT,
       PEN_SECU.DUE_CP,
       COALESCE(H.DUE_AI, 0) AS DUE_AI,
       PEN_SECU.DUE_FEE,
       A.AMRT_DATE,
       A.AMRT_YTM,
       A.AMRT_IR,
       A.IMPAIR,
       PEN_SECU.PRFT_FV,
       PEN_SECU.PRFT_TRD,
       COALESCE(H.PRFT_IR, 0) AS PRFT_IR,
       PEN_SECU.PRFT_FEE,
       A.OPEN_TIME,
       C.I_NAME,
       C.P_CLASS,
       C.P_TYPE,
       C.MTR_DATE,
       D.P_TYPE_NAME,
       E.CASH_ACCID,
       J.ACCOUNTNAME,
       J.ACCNAME,
       A.AMRT_COST_CP + A.AMRT_COST_AI AS AMRT_COST,
       PEN_SECU.DUE_FEE + PEN_SECU.REAL_CP + PEN_SECU.DUE_CP +
       PEN_SECU.AMRT_IR + PEN_SECU.CHG_FV + COALESCE(H.AI, 0) + COALESCE(H.DUE_AI, 0) +COALESCE(B.REAL_AMOUNT, 0) + COALESCE(PEN_CASH.REAL_AMOUNT, 0) AS ASSET_AMOUNT,
       PEN_SECU.DUE_AMOUNT + PEN_SECU.REAL_AMOUNT +
       COALESCE(B.REAL_AMOUNT, 0) + COALESCE(PEN_CASH.REAL_AMOUNT, 0) AS ALL_AMOUNT,
       COALESCE(H.DUE_AI, 0) + COALESCE(H.AI,0) AS ALL_AI,
       PEN_SECU.DUE_CP + PEN_SECU.REAL_CP + COALESCE(B.REAL_AMOUNT, 0) +
       COALESCE(PEN_CASH.REAL_AMOUNT, 0) AS ALL_CP,
       A.AMRT_COST_CP,
       A.OPEN_YTM,
       PEN_SECU.IS_HANDING, -- 是否是挂账数据
       PEN_SECU.SET_DATE
  FROM TTRD_PENETRATE_SECU_OBJ PEN_SECU
 INNER JOIN TTRD_ACCOUNTING_SECU_OBJ A -- 本条余额数据
    ON PEN_SECU.OBJ_ID = A.OBJ_ID
  LEFT JOIN TTRD_ACCOUNTING_SECU_OBJ PEN_OBJ -- 底层穿透余额数据
    ON PEN_SECU.PENETRATE_OBJ_ID = PEN_OBJ.OBJ_ID
  LEFT JOIN TTRD_ACCOUNTING_CASH_OBJ B
    ON A.TSK_ID = B.TSK_ID
   AND A.BEG_DATE = B.BEG_DATE
   AND A.EXT_SECU_ACCT_ID = B.EXT_CASH_ACCT_ID
   AND A.SECU_ACCT_ID = B.CASH_ACCT_ID
  LEFT JOIN TTRD_PENETRATE_CASH_OBJ PEN_CASH
    ON B.OBJ_ID = PEN_CASH.OBJ_ID
  LEFT JOIN TTRD_INSTRUMENT C
    ON PEN_OBJ.I_CODE = C.I_CODE
   AND PEN_OBJ.A_TYPE = C.A_TYPE
   AND PEN_OBJ.M_TYPE = C.M_TYPE
  LEFT JOIN TTRD_P_CLASS D
    ON C.P_TYPE = D.P_TYPE
   AND C.A_TYPE = D.A_TYPE
   AND C.P_CLASS = D.P_CLASS
 INNER JOIN (
   SELECT ACCID,
        ACCID AS CASH_ACCID,
        ACCNAME AS ACCOUNTNAME,
        '业务单元' AS ACCNAME
   FROM TTRD_ACC_CASH
   ) E
    ON A.SECU_ACCT_ID = E.ACCID
  LEFT JOIN TTRD_INSTRUMENT F
    ON A.I_CODE = F.I_CODE
   AND A.A_TYPE = F.A_TYPE
   AND A.M_TYPE = F.M_TYPE
 LEFT JOIN (
     /* 穿透活期利息账户汇总 */
      SELECT SELF_AI.CASH_ACCT_ID,
               SELF_AI.ACCNAME AS CASH_ACC_NAME,
               SELF_AI.EXT_SECU_ACCT_ID,
               SELF_AI.AI + COALESCE(SPV_AI.AI, 0) AS AI,
               SELF_AI.DUE_AI + COALESCE(SPV_AI.DUE_AI, 0) AS DUE_AI,
               SELF_AI.PRFT_IR + COALESCE(SPV_AI.PRFT_IR, 0) AS PRFT_IR
          FROM (
                 -- 自身利息
                 SELECT C.ACCID AS CASH_ACCT_ID,
                       C.ACCNAME,
                       B.EXT_SECU_ACCT_ID,
                       SUM(A.AI) AS AI,
                       SUM(A.DUE_AI) AS DUE_AI,
                       SUM(A.PRFT_IR) AS PRFT_IR
                  FROM TTRD_PENETRATE_SECU_OBJ A
                 INNER JOIN TTRD_ACCOUNTING_SECU_OBJ B
                    ON A.OBJ_ID = B.OBJ_ID
                 INNER JOIN TTRD_ACC_CASH C
                    ON B.SECU_ACCT_ID = C.ACCID
                 WHERE A.IS_LEAF = '1'
                   AND A.IS_HANDING != '1'
                   AND A.PENETRATE_OBJ_ID = A.OBJ_ID
                 GROUP BY C.ACCID, C.ACCNAME, B.EXT_SECU_ACCT_ID
             )
          SELF_AI
            LEFT JOIN (
                     -- SPV穿透利息，默认SPV利息记在资金托管账户
                     SELECT C.CASH_EXT_ACCID, ALL_AI.*
                       FROM (SELECT E.ACCID AS CASH_ACCT_ID,
                                     E.ACCNAME,
                                     SUM(A.AI) AS AI,
                                     SUM(A.DUE_AI) AS DUE_AI,
                                     SUM(A.PRFT_IR) AS PRFT_IR
                                FROM TTRD_PENETRATE_SECU_OBJ A
                               INNER JOIN TTRD_ACCOUNTING_SECU_OBJ PEN_OBJ -- 底层穿透余额数据
                                  ON A.PENETRATE_OBJ_ID = PEN_OBJ.OBJ_ID
                               INNER JOIN TTRD_ACC_CASH B
                                  ON PEN_OBJ.SECU_ACCT_ID = B.ACCID
                               INNER JOIN TTRD_ACCOUNTING_SECU_OBJ C -- 本条穿透余额数据
                                  ON A.OBJ_ID = C.OBJ_ID
                               INNER JOIN TTRD_ACC_SECU D
                                  ON C.SECU_ACCT_ID = D.ACCID
                               INNER JOIN TTRD_ACC_CASH E
                                  ON D.CASH_ACCID = E.ACCID
                               WHERE A.IS_LEAF = '1'
                                 AND A.IS_HANDING != '1'
                                 AND A.PENETRATE_OBJ_ID != A.OBJ_ID
                               GROUP BY E.ACCID, E.ACCNAME) ALL_AI
                      INNER JOIN TTRD_ACC_CASH B
                         ON ALL_AI.CASH_ACCT_ID = B.ACCID
                      INNER JOIN TTRD_WMPS_UNIT C
                         ON B.PC1 = C.UNIT_ID
             ) SPV_AI
            ON SELF_AI.CASH_ACCT_ID = SPV_AI.CASH_ACCT_ID
           AND SELF_AI.EXT_SECU_ACCT_ID = SPV_AI.CASH_EXT_ACCID

  ) H
    ON E.CASH_ACCID = H.CASH_ACCT_ID
   AND A.EXT_SECU_ACCT_ID = H.EXT_SECU_ACCT_ID
 LEFT JOIN (
   SELECT ACCID,
        ACCID AS CASH_ACCID,
        ACCNAME AS ACCOUNTNAME,
        '业务单元' AS ACCNAME
   FROM TTRD_ACC_CASH
   ) J
    ON PEN_OBJ.SECU_ACCT_ID = J.ACCID
 WHERE PEN_SECU.IS_LEAF = 1
   AND PEN_SECU.PENETRATE_LEVEL < 1
   AND PEN_SECU.IS_HANDING != '1'  /* 排除挂账穿透数据 */
   AND EXISTS (
     /* 活期利息券账户 */
     SELECT 1 FROM TTRD_ACC_CASH WHERE PEN_OBJ.SECU_ACCT_ID = ACCID
   )

UNION ALL

-- 余额表未穿透数据
SELECT A.OBJ_ID,
       A.TSK_ID,
       A.BEG_DATE,
       A.END_DATE,
       A.EXT_SECU_ACCT_ID,
       A.SECU_ACCT_ID,
       A.TRADE_GRP_ID,
       '' AS PEN_I_CODE, -- 穿透路径 i_code
       '' AS PEN_A_TYPE, -- 穿透路径 i_code
       '' AS PEN_M_TYPE, -- 穿透路径 i_code
       '' AS PEN_I_NAME, -- 穿透路径 i_code
       '' AS PEN_PATH, -- 穿透路径
       A.I_CODE,
       A.A_TYPE,
       A.M_TYPE,
       A.SECU_ACCT_ID AS PEN_SECU_ACCT_ID,--底层证券账户
       A.TRADE_ID,
       A.REAL_VOLUME + COALESCE(B.REAL_AMOUNT, 0) AS REAL_VOLUME,
       A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) AS REAL_AMOUNT,
       A.REAL_CP + COALESCE(B.REAL_AMOUNT, 0) AS REAL_CP,
       A.AI,
       A.AI_COST,
       A.CHG_FV,
       A.DUE_AMOUNT,
       CASE WHEN  A.SET_DATE = '2100-01-01'
            THEN 0
            ELSE A.DUE_CP END AS  DUE_CP,
       CASE WHEN A.SET_DATE = '2100-01-01'
            THEN 0
            ELSE A.DUE_AI END AS DUE_AI,
       A.DUE_FEE,
       A.AMRT_DATE,
       A.AMRT_YTM,
       A.AMRT_IR,
       A.IMPAIR,
       A.PRFT_FV,
       A.PRFT_TRD,
       A.PRFT_IR,
       A.PRFT_FEE,
       A.OPEN_TIME,
       C.I_NAME,
       C.P_CLASS,
       C.P_TYPE,
       C.MTR_DATE,
       D.P_TYPE_NAME,
       E.CASH_ACCID,
       E.ACCOUNTNAME,
       E.ACCNAME,
       AMRT_COST_CP + AMRT_COST_AI AS AMRT_COST,
       A.DUE_FEE + A.REAL_CP
       + CASE WHEN A.SET_DATE = '2100-12-31'
              THEN  0
            ELSE A.DUE_CP END
        + A.AMRT_IR + A.CHG_FV + A.AI
        + CASE WHEN A.SET_DATE = '2100-12-31'
               THEN 0
               ELSE A.DUE_AI END  + COALESCE(B.REAL_AMOUNT, 0) AS ASSET_AMOUNT,
       A.DUE_AMOUNT + A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) AS ALL_AMOUNT,
       A.DUE_AI + A.AI AS ALL_AI,
       A.DUE_CP + A.REAL_CP + COALESCE(B.REAL_AMOUNT, 0) AS ALL_CP,
       A.AMRT_COST_CP,
       A.OPEN_YTM,
       '0' AS IS_HANDING, -- 是否是挂账数据
       A.SET_DATE
  FROM TTRD_ACCOUNTING_SECU_OBJ A
  LEFT JOIN TTRD_ACCOUNTING_CASH_OBJ B
    ON A.TSK_ID = B.TSK_ID
   AND A.BEG_DATE = B.BEG_DATE
   AND A.EXT_SECU_ACCT_ID = B.EXT_CASH_ACCT_ID
   AND A.SECU_ACCT_ID = B.CASH_ACCT_ID
  LEFT JOIN TTRD_INSTRUMENT C
    ON A.I_CODE = C.I_CODE
   AND A.A_TYPE = C.A_TYPE
   AND A.M_TYPE = C.M_TYPE
  LEFT JOIN TTRD_P_CLASS D
    ON C.P_TYPE = D.P_TYPE
   AND C.A_TYPE = D.A_TYPE
   AND C.P_CLASS = D.P_CLASS
 INNER JOIN
   (SELECT A.ACCID,
           A.CASH_ACCID,
           A.ACCNAME AS ACCOUNTNAME,
           COALESCE(B.ACCNAME, A.ACCNAME) AS ACCNAME
     FROM TTRD_ACC_SECU A
    INNER JOIN TTRD_ACC_SECU B
       ON A.PS2 = B.ACCID
   UNION ALL
   SELECT ACCID,
          ACCID AS CASH_ACCID,
          ACCNAME AS ACCOUNTNAME,
          '业务单元' AS ACCNAME
     FROM TTRD_ACC_CASH
    ) E
    ON A.SECU_ACCT_ID = E.ACCID
 INNER JOIN TTRD_ACC_SECU F
    ON A.SECU_ACCT_ID = F.ACCID
 INNER JOIN TTRD_ACC_CASH H
    ON F.CASH_ACCID = H.ACCID
 INNER JOIN TTRD_WMPS_UNIT I
    ON H.PC1 = I.UNIT_ID
 INNER JOIN TTRD_ACC_SECU_EXT G
   ON A.EXT_SECU_ACCT_ID = G.ACCID
 WHERE A.A_TYPE != 'SPT_NWMPORT'
   AND A.EXTRA_DIM = 'S'
   AND I.UNIT_TYPE NOT IN ('09', '10')
   AND
     (
       D.P_TYPE IS NULL OR G.ACCTYPE = 2  -- 标准券账户
       OR D.P_TYPE NOT IN ('0123', '0150', '0122', '0132','0220')   -- 排除正回购和拆入,在核算余额表内也为S
     )

UNION ALL

-- 当日余额表内未开仓利息数据
SELECT NULL AS OBJ_ID,
       A.TSK_ID,
       A.BEG_DATE,
       A.END_DATE,
       A.EXT_CASH_ACCT_ID AS EXT_SECU_ACCT_ID,
       A.CASH_ACCT_ID AS SECU_ACCT_ID,
       NULL AS TRADE_GRP_ID,
       NULL AS PEN_I_CODE, -- 穿透路径 I_CODE
       NULL AS PEN_A_TYPE, -- 穿透路径 I_CODE
       NULL AS PEN_M_TYPE, -- 穿透路径 I_CODE
       NULL AS PEN_I_NAME, -- 穿透路径 I_CODE
       NULL AS PEN_PATH, -- 穿透路径
       C.I_CODE, -- 底层 I_CODE
       C.A_TYPE, -- 底层 I_CODE
       C.M_TYPE, -- 底层 I_CODE
       A.CASH_ACCT_ID AS PEN_SECU_ACCT_ID,--底层证券账户
       NULL AS TRADE_ID,
       0 AS REAL_VOLUME,
       A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0)  AS REAL_AMOUNT,
       A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0)  AS REAL_CP,
       0 AS AI,
       0 AS AI_COST,
       0 AS CHG_FV,
       0 AS DUE_AMOUNT,
       0 AS DUE_CP,
       0 AS DUE_AI,
       0 AS DUE_FEE,
       '' AS AMRT_DATE,
       0 AS AMRT_YTM,
       0 AS AMRT_IR,
       0 AS IMPAIR,
       0 AS PRFT_FV,
       0 AS PRFT_TRD,
       0 AS PRFT_IR,
       0 AS PRFT_FEE,
       A.OPEN_TIME,
       C.I_NAME,
       C.P_CLASS,
       C.P_TYPE,
       C.MTR_DATE,
       D.P_TYPE_NAME,
       E.CASH_ACCID,
       E.ACCOUNTNAME,
       E.ACCNAME,
       0 AS AMRT_COST,
       A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) AS ASSET_AMOUNT,
       0 AS ALL_AMOUNT,
       0 AS ALL_AI,
       0 AS ALL_CP,
       0 AS AMRT_COST_CP,
       0 AS OPEN_YTM,
       '0' AS IS_HANDING,
       '1900-01-01' AS SET_DATE
  FROM TTRD_ACCOUNTING_CASH_OBJ A
  LEFT JOIN TTRD_PENETRATE_CASH_OBJ B
    ON A.OBJ_ID = B.OBJ_ID
 INNER JOIN VDED_INFO VDED
    ON A.EXT_CASH_ACCT_ID = VDED.EXT_CASH_ACCT_ID
  LEFT JOIN TTRD_INSTRUMENT C
    ON VDED.I_CODE = C.I_CODE
   AND VDED.A_TYPE = C.A_TYPE
   AND VDED.M_TYPE = C.M_TYPE
  LEFT JOIN TTRD_P_CLASS D
    ON C.P_TYPE = D.P_TYPE
   AND C.A_TYPE = D.A_TYPE
   AND C.P_CLASS = D.P_CLASS
 INNER JOIN (
     SELECT ACCID,
            ACCID AS CASH_ACCID,
            ACCNAME AS ACCOUNTNAME,
            '业务单元' AS ACCNAME,
      PC1
     FROM TTRD_ACC_CASH
  ) E
    ON A.CASH_ACCT_ID = E.ACCID
  LEFT JOIN TTRD_WMPS_UNIT F
    ON E.PC1 = F.UNIT_ID
 WHERE NOT EXISTS (SELECT 1
          FROM TTRD_ACCOUNTING_SECU_OBJ
         WHERE A.CASH_ACCT_ID = SECU_ACCT_ID
           AND A.EXT_CASH_ACCT_ID = EXT_SECU_ACCT_ID
         )
    AND F.UNIT_TYPE NOT IN ('09', '10')

UNION ALL

-- 上层挂账数据穿透
SELECT A.OBJ_ID,
       A.TSK_ID,
       A.BEG_DATE,
       A.END_DATE,
       A.EXT_SECU_ACCT_ID,
       A.SECU_ACCT_ID,
       A.TRADE_GRP_ID,
       A.I_CODE AS PEN_I_CODE, -- 穿透路径 i_code
       A.A_TYPE AS PEN_A_TYPE, -- 穿透路径 i_code
       A.M_TYPE AS PEN_M_TYPE, -- 穿透路径 i_code
       F.I_NAME AS PEN_I_NAME, -- 穿透路径 i_code
       CASE
         WHEN PEN_SECU.OBJ_ID != PEN_SECU.PENETRATE_OBJ_ID THEN F.I_NAME
           ELSE NULL
       END AS PEN_PATH, -- 穿透路径
       PEN_OBJ.INST_I_CODE, -- 底层 i_code
       PEN_OBJ.INST_A_TYPE, -- 底层 i_code
       PEN_OBJ.INST_M_TYPE, -- 底层 i_code
       PEN_OBJ.INST_INT_ACCT_ID as PEN_SECU_ACCT_ID,--底层证券账户
       A.TRADE_ID,
       PEN_SECU.REAL_VOLUME AS REAL_VOLUME,
       PEN_SECU.REAL_AMOUNT AS REAL_AMOUNT,
       PEN_SECU.REAL_CP AS REAL_CP,
       PEN_SECU.AI,
       A.AI_COST,
       PEN_SECU.CHG_FV,
       PEN_SECU.DUE_AMOUNT,
       PEN_SECU.DUE_CP,
       PEN_SECU.DUE_AI,
       PEN_SECU.DUE_FEE,
       A.AMRT_DATE,
       A.AMRT_YTM,
       A.AMRT_IR,
       A.IMPAIR,
       PEN_SECU.PRFT_FV,
       PEN_SECU.PRFT_TRD,
       PEN_SECU.PRFT_IR,
       PEN_SECU.PRFT_FEE,
       A.OPEN_TIME,
       C.I_NAME,
       C.P_CLASS,
       C.P_TYPE,
       C.MTR_DATE,
       D.P_TYPE_NAME,
       E.CASH_ACCID,
       G.ACCOUNTNAME,
       G.ACCNAME,
       A.AMRT_COST_CP + A.AMRT_COST_AI AS AMRT_COST,
       PEN_SECU.DUE_FEE + PEN_SECU.REAL_CP + PEN_SECU.DUE_CP +
       PEN_SECU.AMRT_IR + PEN_SECU.CHG_FV + PEN_SECU.AI + PEN_SECU.DUE_AI AS ASSET_AMOUNT,
       PEN_SECU.DUE_AMOUNT + PEN_SECU.REAL_AMOUNT AS ALL_AMOUNT,
       PEN_SECU.DUE_AI + PEN_SECU.AI AS ALL_AI,
       PEN_SECU.DUE_CP + PEN_SECU.REAL_CP AS ALL_CP,
       A.AMRT_COST_CP,
       A.OPEN_YTM,
       PEN_SECU.IS_HANDING,    -- 是否是挂账数据
       PEN_SECU.SET_DATE
  FROM TTRD_PENETRATE_SECU_OBJ PEN_SECU
  INNER JOIN TTRD_ACCOUNTING_SECU_OBJ A -- 本条余额数据
    ON PEN_SECU.OBJ_ID = A.OBJ_ID
  INNER JOIN TTRD_ACCOUNTING_DUE_OBJ PEN_OBJ -- 底层穿透余额数据
    ON PEN_SECU.PENETRATE_OBJ_ID = PEN_OBJ.OBJ_ID
  LEFT JOIN TTRD_INSTRUMENT C
    ON PEN_OBJ.INST_I_CODE = C.I_CODE
   AND PEN_OBJ.INST_A_TYPE = C.A_TYPE
   AND PEN_OBJ.INST_M_TYPE = C.M_TYPE
  LEFT JOIN TTRD_P_CLASS D
    ON C.P_TYPE = D.P_TYPE
   AND C.A_TYPE = D.A_TYPE
   AND C.P_CLASS = D.P_CLASS
 INNER JOIN (
   SELECT A.ACCID,
          A.CASH_ACCID,
          A.ACCNAME AS ACCOUNTNAME,
          COALESCE(B.ACCNAME, A.ACCNAME) AS ACCNAME
     FROM TTRD_ACC_SECU A
    INNER JOIN TTRD_ACC_SECU B
       ON A.PS2 = B.ACCID
   ) E
    ON A.SECU_ACCT_ID = E.ACCID
  LEFT JOIN TTRD_INSTRUMENT F
    ON A.I_CODE = F.I_CODE
   AND A.A_TYPE = F.A_TYPE
   AND A.M_TYPE = F.M_TYPE
 LEFT JOIN (
   SELECT A.ACCID,
          A.CASH_ACCID,
          A.ACCNAME AS ACCOUNTNAME,
          COALESCE(B.ACCNAME, A.ACCNAME) AS ACCNAME
     FROM TTRD_ACC_SECU A
    INNER JOIN TTRD_ACC_SECU B
       ON A.PS2 = B.ACCID
   ) G
 ON PEN_OBJ.INST_INT_ACCT_ID = G.ACCID
 WHERE PEN_SECU.IS_LEAF = 1         -- 叶子节点
   AND PEN_SECU.IS_HANDING = '1' AND PEN_SECU.OBJ_ID != PEN_SECU.PENETRATE_OBJ_ID  -- 上层挂账数据穿透
   AND PEN_SECU.DUE_CP != 0

UNION ALL

-- 底层挂账数据穿透
SELECT G.OBJ_ID,
       G.TSK_ID,
       G.BEG_DATE,
       G.END_DATE,
       G.EXT_SECU_ACCT_ID,
       G.SECU_ACCT_ID,
       '' AS TRADE_GRP_ID,
       '' AS PEN_I_CODE, -- 穿透路径 i_code
       '' AS PEN_A_TYPE, -- 穿透路径 i_code
       '' AS PEN_M_TYPE, -- 穿透路径 i_code
       '' AS PEN_I_NAME, -- 穿透路径 i_code
       '' AS PEN_PATH, -- 穿透路径
       G.I_CODE,
       G.A_TYPE,
       G.M_TYPE,
       G.SECU_ACCT_ID as PEN_SECU_ACCT_ID,--底层证券账户
       '' AS TRADE_ID,
       0 AS REAL_VOLUME,
       0 AS REAL_AMOUNT,
       0 AS REAL_CP,
       0 AS AI,
       0 AS AI_COST,
       0 AS CHG_FV,
       G.DUE_CP AS DUE_AMOUNT,
       G.DUE_CP,
       0 AS DUE_AI,
       0 AS DUE_FEE,
       '' AS AMRT_DATE,
       0 AS AMRT_YTM,
       0 AS AMRT_IR,
       0 AS IMPAIR,
       0 AS PRFT_FV,
       0 AS PRFT_TRD,
       0 AS PRFT_IR,
       0 AS PRFT_FEE,
       '' AS OPEN_TIME,
       G.I_NAME,
       G.P_CLASS,
       G.P_TYPE,
       G.MTR_DATE,
       G.P_TYPE_NAME,
       G.CASH_ACCT_ID AS CASH_ACCID,
       H.ACCOUNTNAME,
       H.ACCNAME,
       0 AS AMRT_COST,
       G.DUE_CP AS ASSET_AMOUNT,
       G.DUE_CP AS ALL_AMOUNT,
       0 AS ALL_AI,
       G.DUE_CP AS ALL_CP,
       0 AS AMRT_COST_CP,
       0 AS OPEN_YTM,
       '1' AS IS_HANDING,
       '1900-01-01' AS SET_DATE
  FROM (SELECT A.OBJ_ID,
               B.TSK_ID,
               B.BEG_DATE,
               B.END_DATE,
               B.PAY_AMOUNT + B.RECEIVE_AMOUNT AS DUE_CP,
               C.EXT_SECU_ACCT_ID,
               C.SECU_ACCT_ID,
               D.CASH_ACCT_ID,
               F.P_TYPE_NAME,
               E.MTR_DATE,
               E.I_NAME,
               E.P_TYPE,
               E.P_CLASS,
               E.I_CODE,
               E.A_TYPE,
               E.M_TYPE
          FROM TTRD_PENETRATE_SECU_OBJ A
         INNER JOIN TTRD_ACCOUNTING_DUE_OBJ B
            ON A.OBJ_ID = B.OBJ_ID
         INNER JOIN TTRD_SET_INSTRUCTION_SECU C
            ON B.PRMR_INST_ID = C.SECU_INST_ID
         INNER JOIN TTRD_SET_INSTRUCTION D
            ON C.INST_ID = D.INST_ID
         INNER JOIN TTRD_INSTRUMENT E
            ON B.INST_I_CODE = E.I_CODE
           AND B.INST_A_TYPE = E.A_TYPE
           AND B.INST_M_TYPE = E.M_TYPE
         LEFT JOIN TTRD_P_CLASS F
            ON E.P_TYPE = F.P_TYPE
           AND E.A_TYPE = F.A_TYPE
           AND E.P_CLASS = F.P_CLASS
         WHERE A.IS_LEAF = '1' -- 叶子结点
           AND A.OBJ_ID = A.PENETRATE_OBJ_ID AND A.IS_HANDING = '1' -- 底层挂账数据
           AND A.PENETRATE_LEVEL < 1
        UNION ALL
        SELECT A.OBJ_ID,
               B.TSK_ID,
               B.BEG_DATE,
               B.END_DATE,
               B.PAY_AMOUNT + B.RECEIVE_AMOUNT AS DUE_CP,
               C.EXT_SECU_ACCT_ID,
               C.SECU_ACCT_ID,
               D.CASH_ACCT_ID,
               F.P_TYPE_NAME,
               E.MTR_DATE,
               E.I_NAME,
               E.P_TYPE,
               E.P_CLASS,
               E.I_CODE,
               E.A_TYPE,
               E.M_TYPE
          FROM TTRD_PENETRATE_SECU_OBJ_HIS A
         INNER JOIN TTRD_ACCOUNTING_DUE_OBJ_HIS B
            ON A.OBJ_ID = B.OBJ_ID
           AND A.BEG_DATE = B.BEG_DATE
         INNER JOIN TTRD_SET_INSTRUCTION_SECU C
            ON B.PRMR_INST_ID = C.SECU_INST_ID
         INNER JOIN TTRD_SET_INSTRUCTION D
            ON C.INST_ID = D.INST_ID
         INNER JOIN TTRD_INSTRUMENT E
            ON B.INST_I_CODE = E.I_CODE
           AND B.INST_A_TYPE = E.A_TYPE
           AND B.INST_M_TYPE = E.M_TYPE
         LEFT JOIN TTRD_P_CLASS F
            ON E.P_TYPE = F.P_TYPE
           AND E.A_TYPE = F.A_TYPE
           AND E.P_CLASS = F.P_CLASS
         WHERE A.IS_LEAF = '1' -- 叶子结点
           AND A.OBJ_ID = A.PENETRATE_OBJ_ID AND A.IS_HANDING = '1' -- 底层挂账数据
           AND A.PENETRATE_LEVEL < 1
        ) G
 INNER JOIN (
       SELECT H1.ACCID,
              H1.ACCNAME AS ACCOUNTNAME,
              COALESCE(H2.ACCNAME, H1.ACCNAME) AS ACCNAME
         FROM TTRD_ACC_SECU H1
         LEFT JOIN TTRD_ACC_SECU H2
           ON H1.PS2 = H2.ACCID
       ) H
    ON G.SECU_ACCT_ID = H.ACCID

UNION ALL

-- 历史数据穿透
-- 历史数据 余额，费用的数据穿透
SELECT A.OBJ_ID,
       A.TSK_ID,
       A.BEG_DATE,
       A.END_DATE,
       A.EXT_SECU_ACCT_ID,
       A.SECU_ACCT_ID,
       A.TRADE_GRP_ID,
       A.I_CODE AS PEN_I_CODE, -- 穿透路径 i_code
       A.A_TYPE AS PEN_A_TYPE, -- 穿透路径 i_code
       A.M_TYPE AS PEN_M_TYPE, -- 穿透路径 i_code
       F.I_NAME AS PEN_I_NAME, -- 穿透路径 i_code
       CASE
         WHEN PEN_SECU.OBJ_ID != PEN_SECU.PENETRATE_OBJ_ID THEN F.I_NAME
           ELSE NULL
       END AS PEN_PATH, -- 穿透路径
       PEN_OBJ.I_CODE, -- 底层 i_code
       PEN_OBJ.A_TYPE, -- 底层 i_code
       PEN_OBJ.M_TYPE, -- 底层 i_code
       PEN_OBJ.SECU_ACCT_ID as PEN_SECU_ACCT_ID,--底层证券账户
       A.TRADE_ID,
       PEN_SECU.REAL_VOLUME AS REAL_VOLUME,
       PEN_SECU.REAL_AMOUNT AS REAL_AMOUNT,
       PEN_SECU.REAL_CP AS REAL_CP,
       PEN_SECU.AI,
       A.AI_COST,
       PEN_SECU.CHG_FV,
       PEN_SECU.DUE_AMOUNT,
       CASE WHEN PEN_SECU.SET_DATE = '2100-12-31'
            THEN 0
            ELSE PEN_SECU.DUE_CP END AS DUE_CP,
       CASE WHEN PEN_SECU.SET_DATE = '2100-12-31'
            THEN 0
            ELSE PEN_SECU.DUE_AI END AS DUE_AI,
       PEN_SECU.DUE_FEE,
       A.AMRT_DATE,
       A.AMRT_YTM,
       A.AMRT_IR,
       A.IMPAIR,
       PEN_SECU.PRFT_FV,
       PEN_SECU.PRFT_TRD,
       PEN_SECU.PRFT_IR,
       PEN_SECU.PRFT_FEE,
       A.OPEN_TIME,
       C.I_NAME,
       C.P_CLASS,
       C.P_TYPE,
       C.MTR_DATE,
       D.P_TYPE_NAME,
       E.CASH_ACCID,
       H.ACCOUNTNAME,
       H.ACCNAME,
       A.AMRT_COST_CP + A.AMRT_COST_AI AS AMRT_COST,
       PEN_SECU.DUE_FEE + PEN_SECU.REAL_CP
       + CASE WHEN PEN_SECU.SET_DATE = '2100-12-31'
              THEN 0
            ELSE PEN_SECU.DUE_CP END  +
       PEN_SECU.AMRT_IR + PEN_SECU.CHG_FV + PEN_SECU.AI
       + CASE WHEN PEN_SECU.SET_DATE = '2100-12-31'
              THEN 0
            ELSE PEN_SECU.DUE_AI END AS ASSET_AMOUNT,
       PEN_SECU.DUE_AMOUNT + PEN_SECU.REAL_AMOUNT AS ALL_AMOUNT,
       PEN_SECU.DUE_AI + PEN_SECU.AI AS ALL_AI,
       PEN_SECU.DUE_CP + PEN_SECU.REAL_CP AS ALL_CP,
       A.AMRT_COST_CP,
       A.OPEN_YTM,
       PEN_SECU.IS_HANDING, -- 是否是挂账数据
       PEN_SECU.SET_DATE
  FROM TTRD_PENETRATE_SECU_OBJ_HIS PEN_SECU
  INNER JOIN TTRD_ACCOUNTING_SECU_OBJ_HIS A -- 本条余额数据
    ON PEN_SECU.OBJ_ID = A.OBJ_ID
   AND PEN_SECU.BEG_DATE = A.BEG_DATE
  LEFT JOIN TTRD_ACCOUNTING_SECU_OBJ_HIS PEN_OBJ -- 底层穿透余额数据
    ON PEN_SECU.PENETRATE_OBJ_ID = PEN_OBJ.OBJ_ID
  AND PEN_SECU.BEG_DATE = PEN_OBJ.BEG_DATE
  LEFT JOIN TTRD_INSTRUMENT C
    ON PEN_OBJ.I_CODE = C.I_CODE
   AND PEN_OBJ.A_TYPE = C.A_TYPE
   AND PEN_OBJ.M_TYPE = C.M_TYPE
  LEFT JOIN TTRD_P_CLASS D
    ON C.P_TYPE = D.P_TYPE
   AND C.A_TYPE = D.A_TYPE
   AND C.P_CLASS = D.P_CLASS
  INNER JOIN (SELECT A.ACCID,
                    A.CASH_ACCID,
                    A.ACCNAME AS ACCOUNTNAME,
                    COALESCE(B.ACCNAME, A.ACCNAME) AS ACCNAME
               FROM TTRD_ACC_SECU A
              INNER JOIN TTRD_ACC_SECU B
                 ON A.PS2 = B.ACCID) E
    ON A.SECU_ACCT_ID = E.ACCID
  LEFT JOIN TTRD_INSTRUMENT F
    ON A.I_CODE = F.I_CODE
   AND A.A_TYPE = F.A_TYPE
   AND A.M_TYPE = F.M_TYPE
  LEFT JOIN TTRD_ACC_SECU_EXT G
    ON A.EXT_SECU_ACCT_ID = G.ACCID
  LEFT JOIN (SELECT A.ACCID,
                    A.CASH_ACCID,
                    A.ACCNAME AS ACCOUNTNAME,
                    COALESCE(B.ACCNAME, A.ACCNAME) AS ACCNAME
               FROM TTRD_ACC_SECU A
              INNER JOIN TTRD_ACC_SECU B
                 ON A.PS2 = B.ACCID) H
    ON PEN_OBJ.SECU_ACCT_ID = H.ACCID
  WHERE PEN_SECU.IS_HANDING != '1'  /* 排除挂账穿透数据 */
    AND PEN_SECU.IS_LEAF = 1         /* 叶子节点 */
    AND NOT EXISTS (
      /* 排除余额表内活期利息 */
      SELECT 1 FROM TTRD_ACC_CASH WHERE PEN_OBJ.SECU_ACCT_ID = ACCID
    )
    AND (G.ACCTYPE IS NULL OR G.ACCTYPE != '2')

UNION ALL

--历史数据  活期利息穿透数据,(底层SPV利息汇总), 穿透数据已包含底层活期利息穿透和自身活期利息
SELECT A.OBJ_ID,
       A.TSK_ID,
       A.BEG_DATE,
       A.END_DATE,
       A.EXT_SECU_ACCT_ID,
       A.SECU_ACCT_ID,
       A.TRADE_GRP_ID,
       A.I_CODE AS PEN_I_CODE, -- 穿透路径 i_code
       A.A_TYPE AS PEN_A_TYPE, -- 穿透路径 i_code
       A.M_TYPE AS PEN_M_TYPE, -- 穿透路径 i_code
       F.I_NAME AS PEN_I_NAME, -- 穿透路径 i_code
       CASE
         WHEN PEN_SECU.OBJ_ID != PEN_SECU.PENETRATE_OBJ_ID THEN F.I_NAME
           ELSE NULL
       END AS PEN_PATH, -- 穿透路径
       PEN_OBJ.I_CODE, -- 底层 i_code
       PEN_OBJ.A_TYPE, -- 底层 i_code
       PEN_OBJ.M_TYPE, -- 底层 i_code
       PEN_OBJ.SECU_ACCT_ID as PEN_SECU_ACCT_ID,--底层证券账户
       A.TRADE_ID,
       PEN_SECU.REAL_VOLUME + COALESCE(B.REAL_AMOUNT, 0) +
       COALESCE(PEN_CASH.REAL_AMOUNT, 0) AS REAL_VOLUME,
       PEN_SECU.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) +
       COALESCE(PEN_CASH.REAL_AMOUNT, 0) AS REAL_AMOUNT,
       PEN_SECU.REAL_CP + COALESCE(B.REAL_AMOUNT, 0) +
       COALESCE(PEN_CASH.REAL_AMOUNT, 0) AS REAL_CP,
       H.AI, /* PEN_SECU.AI, */
       A.AI_COST,
       PEN_SECU.CHG_FV,
       PEN_SECU.DUE_AMOUNT,
       PEN_SECU.DUE_CP,
       H.DUE_AI, /*PEN_SECU.DUE_AI,*/
       PEN_SECU.DUE_FEE,
       A.AMRT_DATE,
       A.AMRT_YTM,
       A.AMRT_IR,
       A.IMPAIR,
       PEN_SECU.PRFT_FV,
       PEN_SECU.PRFT_TRD,
       H.PRFT_IR, /*PEN_SECU.PRFT_IR,*/
       PEN_SECU.PRFT_FEE,
       A.OPEN_TIME,
       C.I_NAME,
       C.P_CLASS,
       C.P_TYPE,
       C.MTR_DATE,
       D.P_TYPE_NAME,
       E.CASH_ACCID,
       J.ACCOUNTNAME,
       J.ACCNAME,
       A.AMRT_COST_CP + A.AMRT_COST_AI AS AMRT_COST,
       PEN_SECU.DUE_FEE + PEN_SECU.REAL_CP + PEN_SECU.DUE_CP +
       PEN_SECU.AMRT_IR + PEN_SECU.CHG_FV + H.AI /*PEN_SECU.AI*/ +H.DUE_AI /*PEN_SECU.DUE_AI*/ +COALESCE(B.REAL_AMOUNT, 0) + COALESCE(PEN_CASH.REAL_AMOUNT, 0) AS ASSET_AMOUNT,
       PEN_SECU.DUE_AMOUNT + PEN_SECU.REAL_AMOUNT +
       COALESCE(B.REAL_AMOUNT, 0) + COALESCE(PEN_CASH.REAL_AMOUNT, 0) AS ALL_AMOUNT,
       H.DUE_AI /*PEN_SECU.DUE_AI*/ +H.AI /*PEN_SECU.AI*/ AS ALL_AI,
       PEN_SECU.DUE_CP + PEN_SECU.REAL_CP + COALESCE(B.REAL_AMOUNT, 0) +
       COALESCE(PEN_CASH.REAL_AMOUNT, 0) AS ALL_CP,
       A.AMRT_COST_CP,
       A.OPEN_YTM,
       PEN_SECU.IS_HANDING, -- 是否是挂账数据
       PEN_SECU.SET_DATE
  FROM TTRD_PENETRATE_SECU_OBJ_HIS PEN_SECU
 INNER JOIN TTRD_ACCOUNTING_SECU_OBJ_HIS A -- 本条余额数据
    ON PEN_SECU.OBJ_ID = A.OBJ_ID
  AND PEN_SECU.BEG_DATE = A.BEG_DATE
  LEFT JOIN TTRD_ACCOUNTING_SECU_OBJ_HIS PEN_OBJ -- 底层穿透余额数据
    ON PEN_SECU.PENETRATE_OBJ_ID = PEN_OBJ.OBJ_ID
  AND PEN_SECU.BEG_DATE = PEN_OBJ.BEG_DATE
  LEFT JOIN TTRD_ACCOUNTING_CASH_OBJ_HIS B
    ON A.TSK_ID = B.TSK_ID
   AND A.BEG_DATE = B.BEG_DATE
   AND A.EXT_SECU_ACCT_ID = B.EXT_CASH_ACCT_ID
   AND A.SECU_ACCT_ID = B.CASH_ACCT_ID
  LEFT JOIN TTRD_PENETRATE_CASH_OBJ_HIS PEN_CASH
    ON B.OBJ_ID = PEN_CASH.OBJ_ID
  AND B.BEG_DATE = PEN_CASH.BEG_DATE
  LEFT JOIN TTRD_INSTRUMENT C
    ON PEN_OBJ.I_CODE = C.I_CODE
   AND PEN_OBJ.A_TYPE = C.A_TYPE
   AND PEN_OBJ.M_TYPE = C.M_TYPE
  LEFT JOIN TTRD_P_CLASS D
    ON C.P_TYPE = D.P_TYPE
   AND C.A_TYPE = D.A_TYPE
   AND C.P_CLASS = D.P_CLASS
 INNER JOIN (
   SELECT ACCID,
        ACCID AS CASH_ACCID,
        ACCNAME AS ACCOUNTNAME,
        '业务单元' AS ACCNAME
   FROM TTRD_ACC_CASH
   ) E
    ON A.SECU_ACCT_ID = E.ACCID
  LEFT JOIN TTRD_INSTRUMENT F
    ON A.I_CODE = F.I_CODE
   AND A.A_TYPE = F.A_TYPE
   AND A.M_TYPE = F.M_TYPE
 INNER JOIN (
     /* 历史穿透活期利息账户汇总 */
      SELECT SELF_AI.CASH_ACCT_ID,
               SELF_AI.BEG_DATE,
               SELF_AI.ACCNAME AS CASH_ACC_NAME,
               SELF_AI.EXT_SECU_ACCT_ID,
               SELF_AI.AI + COALESCE(SPV_AI.AI, 0) AS AI,
               SELF_AI.DUE_AI + COALESCE(SPV_AI.DUE_AI, 0) AS DUE_AI,
               SELF_AI.PRFT_IR + COALESCE(SPV_AI.PRFT_IR, 0) AS PRFT_IR
          FROM (
                 -- 自身利息
                 SELECT C.ACCID AS CASH_ACCT_ID,
                       C.ACCNAME,
                       A.BEG_DATE,
                       B.EXT_SECU_ACCT_ID,
                       SUM(A.AI) AS AI,
                       SUM(A.DUE_AI) AS DUE_AI,
                       SUM(A.PRFT_IR) AS PRFT_IR
                  FROM TTRD_PENETRATE_SECU_OBJ_HIS A
                 INNER JOIN TTRD_ACCOUNTING_SECU_OBJ_HIS B
                    ON A.OBJ_ID = B.OBJ_ID
                   AND A.BEG_DATE = B.BEG_DATE
                 INNER JOIN TTRD_ACC_CASH C
                    ON B.SECU_ACCT_ID = C.ACCID
                 WHERE A.IS_LEAF = '1'
                   AND A.IS_HANDING != '1'
                   AND A.PENETRATE_OBJ_ID = A.OBJ_ID
                 GROUP BY C.ACCID, C.ACCNAME, B.EXT_SECU_ACCT_ID, A.BEG_DATE
             )
          SELF_AI
            LEFT JOIN (
                     -- SPV穿透利息，默认SPV利息记在资金托管账户
                     SELECT C.CASH_EXT_ACCID, ALL_AI.*
                       FROM (SELECT E.ACCID AS CASH_ACCT_ID,
                                     E.ACCNAME,
                                     A.BEG_DATE,
                                     SUM(A.AI) AS AI,
                                     SUM(A.DUE_AI) AS DUE_AI,
                                     SUM(A.PRFT_IR) AS PRFT_IR
                                FROM TTRD_PENETRATE_SECU_OBJ_HIS A
                               INNER JOIN TTRD_ACCOUNTING_SECU_OBJ_HIS PEN_OBJ -- 底层穿透余额数据
                                  ON A.PENETRATE_OBJ_ID = PEN_OBJ.OBJ_ID
                                 AND A.BEG_DATE = PEN_OBJ.BEG_DATE
                               INNER JOIN TTRD_ACC_CASH B
                                  ON PEN_OBJ.SECU_ACCT_ID = B.ACCID
                               INNER JOIN TTRD_ACCOUNTING_SECU_OBJ_HIS C -- 本条穿透余额数据
                                  ON A.OBJ_ID = C.OBJ_ID
                                 AND A.BEG_DATE = C.BEG_DATE
                               INNER JOIN TTRD_ACC_SECU D
                                  ON C.SECU_ACCT_ID = D.ACCID
                               INNER JOIN TTRD_ACC_CASH E
                                  ON D.CASH_ACCID = E.ACCID
                               WHERE A.IS_LEAF = '1'
                                 AND A.IS_HANDING != '1'
                                 AND A.PENETRATE_OBJ_ID != A.OBJ_ID
                               GROUP BY E.ACCID, E.ACCNAME, A.BEG_DATE) ALL_AI
                      INNER JOIN TTRD_ACC_CASH B
                         ON ALL_AI.CASH_ACCT_ID = B.ACCID
                      INNER JOIN TTRD_WMPS_UNIT C
                         ON B.PC1 = C.UNIT_ID
             ) SPV_AI
            ON SELF_AI.CASH_ACCT_ID = SPV_AI.CASH_ACCT_ID
           AND SELF_AI.EXT_SECU_ACCT_ID = SPV_AI.CASH_EXT_ACCID
           AND SELF_AI.BEG_DATE = SPV_AI.BEG_DATE
  ) H
    ON E.CASH_ACCID = H.CASH_ACCT_ID
   AND A.EXT_SECU_ACCT_ID = H.EXT_SECU_ACCT_ID
   AND PEN_SECU.BEG_DATE = H.BEG_DATE
 LEFT JOIN (
   SELECT ACCID,
        ACCID AS CASH_ACCID,
        ACCNAME AS ACCOUNTNAME,
        '业务单元' AS ACCNAME
   FROM TTRD_ACC_CASH
   ) J
    ON PEN_OBJ.SECU_ACCT_ID = J.ACCID
 WHERE PEN_SECU.IS_LEAF = 1
   AND PEN_SECU.PENETRATE_LEVEL < 1
   AND PEN_SECU.IS_HANDING != '1'  /* 排除挂账穿透数据 */
   AND EXISTS (
     /* 活期利息券账户 */
     SELECT 1 FROM TTRD_ACC_CASH WHERE PEN_OBJ.SECU_ACCT_ID = ACCID
   )

UNION ALL

--历史数据 余额表未穿透数据
SELECT A.OBJ_ID,
       A.TSK_ID,
       A.BEG_DATE,
       A.END_DATE,
       A.EXT_SECU_ACCT_ID,
       A.SECU_ACCT_ID,
       A.TRADE_GRP_ID,
       '' AS PEN_I_CODE, -- 穿透路径 i_code
       '' AS PEN_A_TYPE, -- 穿透路径 i_code
       '' AS PEN_M_TYPE, -- 穿透路径 i_code
       '' AS PEN_I_NAME, -- 穿透路径 i_code
       '' AS PEN_PATH, -- 穿透路径
       A.I_CODE,
       A.A_TYPE,
       A.M_TYPE,
       A.SECU_ACCT_ID AS PEN_SECU_ACCT_ID,--底层证券账户
       A.TRADE_ID,
       A.REAL_VOLUME + COALESCE(B.REAL_AMOUNT, 0) AS REAL_VOLUME,
       A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) AS REAL_AMOUNT,
       A.REAL_CP + COALESCE(B.REAL_AMOUNT, 0) AS REAL_CP,
       A.AI,
       A.AI_COST,
       A.CHG_FV,
       A.DUE_AMOUNT,
       CASE WHEN A.SET_DATE = '2100-12-31'
            THEN 0
            ELSE A.DUE_CP END AS DUE_CP,
       CASE WHEN A.SET_DATE = '2100-12-31'
            THEN 0
            ELSE A.DUE_AI END AS DUE_AI,
       A.DUE_FEE,
       A.AMRT_DATE,
       A.AMRT_YTM,
       A.AMRT_IR,
       A.IMPAIR,
       A.PRFT_FV,
       A.PRFT_TRD,
       A.PRFT_IR,
       A.PRFT_FEE,
       A.OPEN_TIME,
       C.I_NAME,
       C.P_CLASS,
       C.P_TYPE,
       C.MTR_DATE,
       D.P_TYPE_NAME,
       E.CASH_ACCID,
       E.ACCOUNTNAME,
       E.ACCNAME,
       AMRT_COST_CP + AMRT_COST_AI AS AMRT_COST,
       A.DUE_FEE + A.REAL_CP
       + CASE WHEN A.SET_DATE = '2100-12-31'
              THEN 0
            ELSE A.DUE_CP END + A.AMRT_IR + A.CHG_FV + A.AI
       + CASE WHEN A.SET_DATE = '2100-12-31'
              THEN 0
            ELSE A.DUE_AI END + COALESCE(B.REAL_AMOUNT, 0) AS ASSET_AMOUNT,
       A.DUE_AMOUNT + A.REAL_AMOUNT + COALESCE(B.REAL_AMOUNT, 0) AS ALL_AMOUNT,
       A.DUE_AI + A.AI AS ALL_AI,
       A.DUE_CP + A.REAL_CP + COALESCE(B.REAL_AMOUNT, 0) AS ALL_CP,
       A.AMRT_COST_CP,
       A.OPEN_YTM,
       '0' AS IS_HANDING, -- 是否是挂账数据
       A.SET_DATE
  FROM TTRD_ACCOUNTING_SECU_OBJ_HIS A
  LEFT JOIN TTRD_ACCOUNTING_CASH_OBJ_HIS B
    ON A.TSK_ID = B.TSK_ID
   AND A.BEG_DATE = B.BEG_DATE
   AND A.EXT_SECU_ACCT_ID = B.EXT_CASH_ACCT_ID
   AND A.SECU_ACCT_ID = B.CASH_ACCT_ID
  LEFT JOIN TTRD_INSTRUMENT C
    ON A.I_CODE = C.I_CODE
   AND A.A_TYPE = C.A_TYPE
   AND A.M_TYPE = C.M_TYPE
  LEFT JOIN TTRD_P_CLASS D
    ON C.P_TYPE = D.P_TYPE
   AND C.A_TYPE = D.A_TYPE
   AND C.P_CLASS = D.P_CLASS
 INNER JOIN
   (SELECT A.ACCID,
           A.CASH_ACCID,
           A.ACCNAME AS ACCOUNTNAME,
           COALESCE(B.ACCNAME, A.ACCNAME) AS ACCNAME
     FROM TTRD_ACC_SECU A
    INNER JOIN TTRD_ACC_SECU B
       ON A.PS2 = B.ACCID
   UNION ALL
   SELECT ACCID,
          ACCID AS CASH_ACCID,
          ACCNAME AS ACCOUNTNAME,
          '业务单元' AS ACCNAME
     FROM TTRD_ACC_CASH
    ) E
    ON A.SECU_ACCT_ID = E.ACCID
 INNER JOIN TTRD_ACC_SECU F
    ON A.SECU_ACCT_ID = F.ACCID
 INNER JOIN TTRD_ACC_CASH H
    ON F.CASH_ACCID = H.ACCID
 INNER JOIN TTRD_WMPS_UNIT I
    ON H.PC1 = I.UNIT_ID
 INNER JOIN TTRD_ACC_SECU_EXT G
   ON A.EXT_SECU_ACCT_ID = G.ACCID
 WHERE A.A_TYPE != 'SPT_NWMPORT'
   AND A.EXTRA_DIM = 'S'
   AND I.UNIT_TYPE NOT IN ('09', '10')
   AND
     (
       D.P_TYPE IS NULL OR G.ACCTYPE = 2  -- 标准券账户
       OR D.P_TYPE NOT IN ('0123', '0150', '0122', '0132','0220')   -- 排除正回购和拆入,在核算余额表内也为S
     )

UNION ALL

--历史数据 上层挂账数据穿透
SELECT A.OBJ_ID,
       A.TSK_ID,
       A.BEG_DATE,
       A.END_DATE,
       A.EXT_SECU_ACCT_ID,
       A.SECU_ACCT_ID,
       A.TRADE_GRP_ID,
       A.I_CODE AS PEN_I_CODE, -- 穿透路径 i_code
       A.A_TYPE AS PEN_A_TYPE, -- 穿透路径 i_code
       A.M_TYPE AS PEN_M_TYPE, -- 穿透路径 i_code
       F.I_NAME AS PEN_I_NAME, -- 穿透路径 i_code
       CASE
         WHEN PEN_SECU.OBJ_ID != PEN_SECU.PENETRATE_OBJ_ID THEN F.I_NAME
           ELSE NULL
       END AS PEN_PATH, -- 穿透路径
       PEN_OBJ.INST_I_CODE, -- 底层 i_code
       PEN_OBJ.INST_A_TYPE, -- 底层 i_code
       PEN_OBJ.INST_M_TYPE, -- 底层 i_code
       PEN_OBJ.INST_INT_ACCT_ID as PEN_SECU_ACCT_ID,--底层证券账户
       A.TRADE_ID,
       PEN_SECU.REAL_VOLUME AS REAL_VOLUME,
       PEN_SECU.REAL_AMOUNT AS REAL_AMOUNT,
       PEN_SECU.REAL_CP AS REAL_CP,
       PEN_SECU.AI,
       A.AI_COST,
       PEN_SECU.CHG_FV,
       PEN_SECU.DUE_AMOUNT,
       PEN_SECU.DUE_CP,
       PEN_SECU.DUE_AI,
       PEN_SECU.DUE_FEE,
       A.AMRT_DATE,
       A.AMRT_YTM,
       A.AMRT_IR,
       A.IMPAIR,
       PEN_SECU.PRFT_FV,
       PEN_SECU.PRFT_TRD,
       PEN_SECU.PRFT_IR,
       PEN_SECU.PRFT_FEE,
       A.OPEN_TIME,
       C.I_NAME,
       C.P_CLASS,
       C.P_TYPE,
       C.MTR_DATE,
       D.P_TYPE_NAME,
       E.CASH_ACCID,
       G.ACCOUNTNAME,
       G.ACCNAME,
       A.AMRT_COST_CP + A.AMRT_COST_AI AS AMRT_COST,
       PEN_SECU.DUE_FEE + PEN_SECU.REAL_CP + PEN_SECU.DUE_CP +
       PEN_SECU.AMRT_IR + PEN_SECU.CHG_FV + PEN_SECU.AI + PEN_SECU.DUE_AI AS ASSET_AMOUNT,
       PEN_SECU.DUE_AMOUNT + PEN_SECU.REAL_AMOUNT AS ALL_AMOUNT,
       PEN_SECU.DUE_AI + PEN_SECU.AI AS ALL_AI,
       PEN_SECU.DUE_CP + PEN_SECU.REAL_CP AS ALL_CP,
       A.AMRT_COST_CP,
       A.OPEN_YTM,
       PEN_SECU.IS_HANDING,    -- 是否是挂账数据
       PEN_SECU.SET_DATE
  FROM TTRD_PENETRATE_SECU_OBJ_HIS PEN_SECU
  INNER JOIN TTRD_ACCOUNTING_SECU_OBJ_HIS A -- 本条余额数据
    ON PEN_SECU.OBJ_ID = A.OBJ_ID
   AND PEN_SECU.BEG_DATE = A.BEG_DATE
  INNER JOIN TTRD_ACCOUNTING_DUE_OBJ_HIS PEN_OBJ -- 底层穿透余额数据
    ON PEN_SECU.PENETRATE_OBJ_ID = PEN_OBJ.OBJ_ID
   AND PEN_SECU.BEG_DATE = PEN_OBJ.BEG_DATE
  LEFT JOIN TTRD_INSTRUMENT C
    ON PEN_OBJ.INST_I_CODE = C.I_CODE
   AND PEN_OBJ.INST_A_TYPE = C.A_TYPE
   AND PEN_OBJ.INST_M_TYPE = C.M_TYPE
  LEFT JOIN TTRD_P_CLASS D
    ON C.P_TYPE = D.P_TYPE
   AND C.A_TYPE = D.A_TYPE
   AND C.P_CLASS = D.P_CLASS
 INNER JOIN (
   SELECT A.ACCID,
          A.CASH_ACCID,
          A.ACCNAME AS ACCOUNTNAME,
          COALESCE(B.ACCNAME, A.ACCNAME) AS ACCNAME
     FROM TTRD_ACC_SECU A
    INNER JOIN TTRD_ACC_SECU B
       ON A.PS2 = B.ACCID
   ) E
    ON A.SECU_ACCT_ID = E.ACCID
  LEFT JOIN TTRD_INSTRUMENT F
    ON A.I_CODE = F.I_CODE
   AND A.A_TYPE = F.A_TYPE
   AND A.M_TYPE = F.M_TYPE
 left join (
   SELECT A.ACCID,
          A.CASH_ACCID,
          A.ACCNAME AS ACCOUNTNAME,
          COALESCE(B.ACCNAME, A.ACCNAME) AS ACCNAME
     FROM TTRD_ACC_SECU A
    INNER JOIN TTRD_ACC_SECU B
       ON A.PS2 = B.ACCID
   ) G
 on PEN_OBJ.inst_int_acct_id = g.accid
 WHERE PEN_SECU.IS_LEAF = 1         -- 叶子节点
   AND PEN_SECU.IS_HANDING = '1' AND PEN_SECU.OBJ_ID != PEN_SECU.PENETRATE_OBJ_ID  -- 上层挂账数据穿透
   AND PEN_SECU.DUE_CP != 0
/

