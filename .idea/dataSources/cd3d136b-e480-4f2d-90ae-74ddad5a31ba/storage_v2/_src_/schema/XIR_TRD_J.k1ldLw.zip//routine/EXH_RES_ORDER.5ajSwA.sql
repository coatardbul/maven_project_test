create PROCEDURE EXH_RES_ORDER(PI_CHANNELNO IN VARCHAR2, -- 通道号
                                          PI_SYSORDID  IN NUMBER,   -- 系统委托号（初次发送委托后填写，后续委托回报不需要填写）
                                          PI_M_TYPE    IN VARCHAR2, -- 市场类型
                                          PI_EXTORDID  IN VARCHAR2, -- 系外部委托号
                                          PI_EXTFLAG1  IN VARCHAR2, -- 外部编号1，中金所OrderSysID
                                          PI_EXTFLAG2  IN VARCHAR2, -- 外部编号2，中金所ExchangeID
                                          PI_ORDSTATUS IN INTEGER,  -- 新委托状态
                                          PI_LS        IN CHAR,     -- 多空标识
                                          PI_IS_CHECK  IN NUMBER,   -- 是否验资验券（0,1）
                                          PI_ERRCODE   IN NUMBER,   -- 错误号
                                          PI_ERRINFO   IN VARCHAR2, -- 错误信息
                                          PO_SYSORDID  OUT NUMBER,  -- 委托回报时返回系统委托号
                                          PO_INSID     OUT VARCHAR2,-- 指令号
                                          PO_BATCHID   OUT NUMBER,  -- 批次号
                                          PO_ERRCODE   OUT NUMBER,  -- 输出错误号
                                          PO_ERRINFO   OUT VARCHAR2 -- 输出错误信息
                                          ) AS

/*
   1） 初次委托，根据系统委托号，填写委托的外部委托号；
   2） 委托回报成功后，根据外部委托号，填写外部编号1和外部编号2；
   3） 处理废单
*/

/*
  错误号定义：（负号表示错误，正号表示警告，0表示正确），委托应答以“12”开头
     +12001 = 委托不存在
     +12002 = 非已报委托
     -12011 = 资金余额不存在
     -12013 = 股份余额不存在
*/

  -- 解冻数
  V_UNFREEZE_CNT       NUMBER;
  V_UNFREEZE_AMT       NUMBER;
  V_UNFREEZE_FEE       NUMBER;

  -- 定义光标集
  CURSOR CUR_ORDER(P_SYSORDID IN NUMBER, P_CHANNEL_NO IN VARCHAR2, P_M_TYPE IN VARCHAR2, P_EXTORDID IN VARCHAR2) IS
     SELECT *
     FROM TTRD_EXH_ORDER
     WHERE (P_SYSORDID > 0 AND SYSORDID = P_SYSORDID) OR
           (P_SYSORDID <= 0 AND EXTORDID = P_EXTORDID AND CHANNEL_NO = P_CHANNEL_NO AND M_TYPE = P_M_TYPE)
     FOR UPDATE;

  -- 定义记录集
  REC_ORDER TTRD_EXH_ORDER%ROWTYPE;

BEGIN
   PO_SYSORDID := 0;
   PO_INSID := '';
   PO_BATCHID := 0;
   PO_ERRCODE := 0;
   PO_ERRINFO := '';

   -- 打开委托游标
   OPEN CUR_ORDER(PI_SYSORDID, PI_CHANNELNO, PI_M_TYPE, PI_EXTORDID);
   FETCH CUR_ORDER INTO REC_ORDER;
   IF CUR_ORDER%NOTFOUND THEN
      PO_ERRCODE := +12001;
      PO_ERRINFO := '委托应答，委托不存在，系统委托号=' || TO_CHAR(PI_SYSORDID) || '，通道号=' || PI_CHANNELNO || '，市场类型=' || PI_M_TYPE || '，外部委托号=' || PI_EXTORDID;
      GOTO LABLE_QUIT;
   END IF;

   -- 输出系统委托号、指令号、批次号
   PO_SYSORDID := REC_ORDER.SYSORDID;
   PO_INSID := REC_ORDER.INSID;
   PO_BATCHID := REC_ORDER.BATCHID;


   IF PI_ORDSTATUS = 5 THEN
      -- 1) 初次委托，根据系统委托号，填写委托的外部委托号
      IF (PI_SYSORDID > 0) AND (REC_ORDER.EXTORDID IS NULL) THEN
         UPDATE TTRD_EXH_ORDER SET EXTORDID = PI_EXTORDID,EXTORDID_UPDTIME = TO_CHAR(LOCALTIMESTAMP,'HH24:MI:SS:FF4') WHERE CURRENT OF CUR_ORDER;
      END IF;

      -- 2) 委托回报成功后，根据外部委托号，填写外部编号1和外部编号2
      IF (PI_EXTFLAG1 IS NOT NULL) AND (PI_EXTFLAG2 IS NOT NULL) THEN
         UPDATE TTRD_EXH_ORDER SET EXTFLAG1 = PI_EXTFLAG1, EXTFLAG2 = PI_EXTFLAG2 WHERE CURRENT OF CUR_ORDER;
      END IF;
   END IF;

   IF PI_ORDSTATUS <> 2 THEN
       GOTO LABLE_QUIT;
   END IF;

   -- 3） 处理废单

   -- 不处理非已报委托，给出警告
   IF REC_ORDER.ORDSTATUS <> 5 THEN
      PO_ERRCODE := +12002;
      PO_ERRINFO := '委托应答，非已报委托，不处理，委托状态=' || TO_CHAR(REC_ORDER.ORDSTATUS);
      GOTO LABLE_QUIT;
   END IF;

   -- 解冻资金股份
   IF PI_IS_CHECK <> 0 THEN
      V_UNFREEZE_AMT := -1 * ABS(REC_ORDER.ORDFROZENAMT);
      V_UNFREEZE_FEE := -1 * ABS(REC_ORDER.ORDFROZENFEE);
      V_UNFREEZE_CNT := 0;
      IF REC_ORDER.OCFLAG = 'C' THEN
         V_UNFREEZE_CNT := -1 * ABS(REC_ORDER.ORDCOUNT - REC_ORDER.DEACOUNT);
      END IF;

      EXH_FREEZE_CASH_SECU(REC_ORDER.CASH_EXT_ACCID, REC_ORDER.SECU_EXT_ACCID, REC_ORDER.I_CODE, REC_ORDER.A_TYPE, REC_ORDER.M_TYPE,
                           PI_LS, V_UNFREEZE_CNT, V_UNFREEZE_AMT, V_UNFREEZE_FEE, 0, PO_ERRCODE, PO_ERRINFO);

      IF PO_ERRCODE < 0 THEN
         PO_ERRCODE := PO_ERRCODE - 2000;
      END IF;

   END IF;

   -- 更新委托状态、外部返回的错误号、错误信息
   UPDATE TTRD_EXH_ORDER
      SET ORDSTATUS    = PI_ORDSTATUS,
          ERRCODE      = PI_ERRCODE,
          ERRINFO      = PI_ERRINFO
   WHERE CURRENT OF CUR_ORDER;

   -- 退出标签
   <<LABLE_QUIT>>

   -- 关闭游标
   IF CUR_ORDER%ISOPEN THEN
      CLOSE CUR_ORDER;
   END IF;

END;
/

