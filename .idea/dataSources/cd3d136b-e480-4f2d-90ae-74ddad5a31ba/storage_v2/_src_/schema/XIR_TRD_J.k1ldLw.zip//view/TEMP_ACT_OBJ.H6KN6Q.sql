create view TEMP_ACT_OBJ as
  (
select o.beg_date,u.unit_code,o.i_code,o.a_type,o.m_type,o.extra_dim,
(o.real_cp + o.ai + o.chg_fv + o.amrt_ir + o.fee + o.due_cp + o.due_ai + o.due_fee + nvl(oc.real_amount,0)) as asset_amount,
(PRFT_TRD + PRFT_IR + PRFT_FEE + PRFT_IR_AMRT_RC) as  prft_1 ,
(PRFT_FV + RECLASS_PRFT_FV) as prft_2,
o.real_volume,o.real_amount,o.real_cp,o.ai,  o.ai_cost,o.amrt_ir,o.chg_fv, o.fee , o.due_cp , o.due_ai , o.due_fee,
PRFT_TRD , PRFT_IR , PRFT_FEE , PRFT_IR_AMRT_RC,
PRFT_FV , RECLASS_PRFT_FV,u.unit_name
 from (select * from ttrd_accounting_secu_obj_his union select * from ttrd_accounting_secu_obj) o
 left join (select * from ttrd_accounting_cash_obj_his union select * from ttrd_accounting_cash_obj) oc
 on o.secu_acct_id=oc.cash_acct_id and o.ext_secu_acct_id=oc.ext_cash_acct_id and o.beg_date = oc.beg_date
left join ttrd_acc_secu tas on o.secu_acct_id = tas.accid
left join ttrd_acc_cash tac on tas.cash_accid = tac.accid
left join ttrd_wmps_unit u on tac.pc1 = u.unit_id  )



/

