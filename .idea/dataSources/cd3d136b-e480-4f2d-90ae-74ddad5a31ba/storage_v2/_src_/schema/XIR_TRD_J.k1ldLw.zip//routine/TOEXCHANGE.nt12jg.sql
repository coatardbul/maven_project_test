create function toexchange(pirce in number,
                                      from_cny in varchar2 :='N',
                                      to_cny  in varchar2  :='N'
                                      )
return number is
  v_dpmid  number;
begin
  if to_cny = 'N' or from_cny = to_cny or pirce is null then
     return pirce;
  end if;
   select nvl((select max(case when f.b_curr = from_cny then t.dp_mid
                         else 1/t.dp_mid
                      end) as dp_mid
              from tfx f
                   inner join tfx_series t on f.i_code = t .i_code and f.a_type = t .a_type and f.m_type = t .m_type
                   inner join ttrd_currdate c on 1 = 1
              where (f.b_curr =to_cny and f.q_curr = from_cny) or (f.b_curr = from_cny and f.q_curr = to_cny)
                    and t.beg_date <= c.curr_date and c.curr_date < t.end_date
                    and t.fx_term = 'SPOT'), 1) dp_mid
           into v_dpmid
      from dual;
     return round(pirce*v_dpmid,4);
end toexchange;
/

