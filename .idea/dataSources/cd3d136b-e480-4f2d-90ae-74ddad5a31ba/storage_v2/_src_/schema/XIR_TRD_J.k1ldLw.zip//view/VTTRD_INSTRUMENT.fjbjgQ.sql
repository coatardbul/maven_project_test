create view VTTRD_INSTRUMENT as
  (
  SELECT
    I_CODE,
    A_TYPE,
    M_TYPE,
    CURRENCY,
    I_NAME,
    P_TYPE,
    P_CLASS,
    MTR_DATE,
    TERM,
    COUPON_TYPE,
    ISSUE_MODE,
    PAYMENT_FREQ,
    SENIORITY,
    PARTY_ID,
    CHINESESPELL,
    PAR_VALUE,
    COUPON,
    ISSUER_ID,
    WARRANTOR_ID,
    ISSUE_VOLUME,
    I_ID
  FROM ttrd_instrument
)
/

