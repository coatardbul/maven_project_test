create view VTRD_CBGS_BOND as
  SELECT B.TXFLOWID AS TXFLOWID , --交易流水标识
    B.INSTR_ID, --中债指令编号
    A.FLAG,--标识1：债券1 ,2：债券2
    A.I_CODE, --债券代码
    A.I_NAME , --债券名称
    A.TRDFV*10000 AS ORDMONEY, --债券面额(DOUBLE)
    A.S_TRDFV     AS ORDMONEY_STR, --债券面额(STRING)
    A.RATE           RATE, --质押比例(DOUBLE)
    A.S_RATE         RATE_STR, --质押比例(STRING)
    B.UPDATETIME--更新时间
FROM TTRD_CBGS_BOND A, --债券结算信息表
    TTRD_CBGS_SETTLEBIZ_DETAIL B -- 查询详情返回表
WHERE A.CID=B.CID




/

