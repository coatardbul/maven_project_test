create view VTRD_XCC_FPML_CASHLB_PRT as
  SELECT '' as P_TYPE,'' as PRT FROM dual
/

